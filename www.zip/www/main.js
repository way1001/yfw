(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/way/Desktop/integrating-marketing/src/main.ts */"zUnb");


/***/ }),

/***/ "4Jqp":
/*!************************************************!*\
  !*** ./src/app/core/_service/toast.service.ts ***!
  \************************************************/
/*! exports provided: ToastService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToastService", function() { return ToastService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "TEn/");



let ToastService = class ToastService {
    constructor(toastController) {
        this.toastController = toastController;
    }
    presentToast(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message,
                duration: 4000
            });
            toast.present();
        });
    }
    presentErrorToast(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message,
                position: 'middle',
                duration: 3000,
                cssClass: 'toast-error'
            });
            toast.present();
        });
    }
};
ToastService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
];
ToastService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
], ToastService);



/***/ }),

/***/ "7T6n":
/*!***************************************************!*\
  !*** ./src/app/core/_service/userInfo.service.ts ***!
  \***************************************************/
/*! exports provided: UserInfoService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserInfoService", function() { return UserInfoService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "tk/3");



let UserInfoService = class UserInfoService {
    constructor(http) {
        this.http = http;
    }
    getUserInfo() {
        return this.http.get(`/mkt/api/mp/userinfo/own`)
            .pipe();
    }
    checkIsReg() {
        return this.http.get(`/mkt/api/mp/userinfo/isreg`)
            .pipe();
    }
};
UserInfoService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
UserInfoService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], UserInfoService);



/***/ }),

/***/ "AytR":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "JPqG":
/*!***********************************************************************!*\
  !*** ./src/app/containers/default-layout/default-layout.component.ts ***!
  \***********************************************************************/
/*! exports provided: DefaultLayoutComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DefaultLayoutComponent", function() { return DefaultLayoutComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_default_layout_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./default-layout.component.html */ "lm8q");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _app_core_service_userInfo_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @app/core/_service/userInfo.service */ "7T6n");




// declare var wx: any;
let DefaultLayoutComponent = class DefaultLayoutComponent {
    constructor(userInfoService) {
        this.userInfoService = userInfoService;
        this.appPages = [
            {
                title: '首页',
                url: '/app/home',
                ionicIcon: 'home-outline'
            },
            {
                title: '发现',
                url: '/app/dl',
                ionicIcon: 'disc-outline'
            },
            {
                title: '周边',
                url: '/app/peripherals',
                ionicIcon: 'map-outline'
                // customIcon: './assets/custom-icons/side-menu/contact-card.svg'
            },
            {
                title: '支持',
                url: '/app/contact-card',
                ionicIcon: 'notifications-outline'
            }
        ];
        this.accountPages = [
            {
                title: '我的点评',
                url: '/dil/own',
                ionicIcon: 'leaf-outline'
            },
        ];
    }
    ngOnInit() {
        this.userInfoService.getUserInfo().subscribe(res => {
            var _a, _b;
            this.currentUserInfo = res.data;
            if (this.currentUserInfo) {
                localStorage.setItem('userRole', (_a = this.currentUserInfo) === null || _a === void 0 ? void 0 : _a.userRole);
                localStorage.setItem('affiliated', (_b = this.currentUserInfo) === null || _b === void 0 ? void 0 : _b.affiliated);
            }
        });
        /* this.code = this.activatedRoute.snapshot.queryParams['code'];
    
        if (!this.code) {
          window.location.href = 'https://open.weixin.qq.com/connect/oauth2/' + '' +
          'authorize?appid=wx5fa87befa423b8cc&redirect_uri=' + encodeURIComponent(window.location.href) + '&response_type=code' +
        '&scope=snsapi_userinfo&state=shared#wechat_redirect';
        } */
        // this.authenticationService.currentUser.subscribe(res => {
        //   this.currentUser = res;
        // });
        // this.formsValidationsService.getCategoryTree().subscribe(
        //   res => {
        //     if (res.ok) {
        //       localStorage.setItem('category', JSON.stringify(res.data));
        //     }
        //   }
        // );
        // this.merchantService.getJsapiSignature(window.location.href).subscribe(
        //   sig => {
        //     if (sig.ok) {
        //       wx.config({
        //         debug: false, // true:是调试模式,调试时候弹窗,会打印出日志
        //         appId: sig.data.appId, // 微信appid
        //         timestamp: sig.data.timestamp, // 时间戳
        //         nonceStr: sig.data.nonceStr, // 随机字符串
        //         signature: sig.data.signature, // 签名
        //         jsApiList: [
        //           // 所有要调用的 API 都要加到这个列表中
        //           'onMenuShareTimeline', // 分享到朋友圈接口
        //           'onMenuShareAppMessage', //  分享到朋友接口
        //           'onMenuShareQQ', // 分享到QQ接口
        //           'onMenuShareWeibo', // 分享到微博接口
        //           'updateTimelineShareData',
        //           'updateAppMessageShareData'
        //         ],
        //         openTagList: [
        //           'wx-open-launch-weapp',
        //         ]
        //       });
        //       wx.checkJsApi({
        //         jsApiList: [
        //           // 所有要调用的 API 都要加到这个列表中
        //           'onMenuShareTimeline', // 分享到朋友圈接口
        //           'onMenuShareAppMessage', //  分享到朋友接口
        //           'onMenuShareQQ', // 分享到QQ接口
        //           'onMenuShareWeibo', // 分享到微博接口
        //           'updateTimelineShareData',
        //           'updateAppMessageShareData'
        //         ],
        //         openTagList: [
        //           'wx-open-launch-weapp',
        //         ],
        //         success: function (ress) {
        //           // alert('checkJsApi:success');
        //         }
        //       });
        //       wx.ready(() => {
        //         // 微信分享的数据
        //         const shareData = {
        //           imgUrl: 'http://img.aiforest.net/logo.jpg', // 分享显示的缩略图地址
        //           link: window.location.href,
        //           desc: '本地买房、装修、建材一站式全行业资讯平台', // 分享描述
        //           title: '天门家园', // 分享标题
        //           success: function () {
        //             // 分享成功可以做相应的数据处理
        //             // alert('分享成功');
        //             // alert('appId:' + res.appId)
        //             // alert('timestamp:' + res.timestamp)
        //             // alert('nonceStr:' + res.nonceStr)
        //             // alert('signature:' + res.signature)
        //           },
        //           fail: function () {
        //             // alert('调用失败');
        //           },
        //           complete: function () {
        //             // alert('调用结束');
        //           }
        //         };
        //         wx.updateTimelineShareData(shareData);
        //         wx.updateAppMessageShareData(shareData);
        //         // wx.onMenuShareTimeline(shareData);
        //         // wx.onMenuShareAppMessage(shareData);
        //         wx.onMenuShareQQ(shareData);
        //         wx.onMenuShareWeibo(shareData);
        //       });
        //       wx.error(function (ress) {
        //         // config信息验证失败会执行error函数，如签名过期导致验证失败，
        //         // 具体错误信息可以打开config的debug模式查看，也可以在返回的res参数中查看，
        //         // 对于SPA可以在这里更新签名。
        //         // console.log(ress);
        //         // alert('分享失败' + JSON.stringify(ress));
        //       });
        //     }
        //   });
        /*  document.body.addEventListener('touchmove', function (event) {
           event.preventDefault();
       }, false); */
    }
};
DefaultLayoutComponent.ctorParameters = () => [
    { type: _app_core_service_userInfo_service__WEBPACK_IMPORTED_MODULE_3__["UserInfoService"] }
];
DefaultLayoutComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'app-layout',
        template: _raw_loader_default_layout_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
    })
], DefaultLayoutComponent);



/***/ }),

/***/ "RK3O":
/*!*********************************************************!*\
  !*** ./src/app/core/_service/authentication.service.ts ***!
  \*********************************************************/
/*! exports provided: AuthenticationService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthenticationService", function() { return AuthenticationService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "qCKp");





let AuthenticationService = class AuthenticationService {
    constructor(http) {
        this.http = http;
        this.currentUserSubject = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](JSON.parse(localStorage.getItem('currentUser')));
        this.currentUser = this.currentUserSubject.asObservable();
    }
    get currentUserValue() {
        return this.currentUserSubject.value;
    }
    login(code) {
        //TODO appid will set global on last version
        return this.http.post('weixin/api/mp/wxuser/login', { appId: 'wxba8fbb58ebb3b73c', code })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])((res) => {
            // login successful if there's a jwt token in the response
            // use thinkjs promise res data return {msg {data}}
            if (res.data && res.data.sessionKey) {
                // store username and jwt token in local storage to keep user logged in between page refreshes
                // give sockjs a usename
                localStorage.setItem('sessionKey', JSON.stringify({ sessionKey: res.data.sessionKey }));
                // localStorage.setItem('currentUser', JSON.stringify(res));
                localStorage.setItem('currentUser', JSON.stringify(res.data));
                localStorage.setItem('isReg', JSON.stringify(res.data.isReg));
                this.currentUserSubject.next(res.data);
                return 'ok';
            }
            else {
                return res;
            }
        }));
    }
};
AuthenticationService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
AuthenticationService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({ providedIn: 'root' })
], AuthenticationService);



/***/ }),

/***/ "Sy1n":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./app.component.html */ "VzVu");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");




let AppComponent = class AppComponent {
    constructor(translate) {
        this.translate = translate;
        this.textDir = 'ltr';
        this.initializeApp();
        // this.setLanguage();
    }
    initializeApp() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // try {
            //   await SplashScreen.hide();
            //  } catch (err) {
            //   console.log('This is normal in a browser', err);
            //  }
        });
    }
    setLanguage() {
        // this language will be used as a fallback when a translation isn't found in the current language
        this.translate.setDefaultLang('en');
        // the lang to use, if the lang isn't available, it will use the current loader to get them
        this.translate.use('en');
        // this is to determine the text direction depending on the selected language
        // for the purpose of this example we determine that only arabic and hebrew are RTL.
        // this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
        //   this.textDir = (event.lang === 'ar' || event.lang === 'iw') ? 'rtl' : 'ltr';
        // });
    }
};
AppComponent.ctorParameters = () => [
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"] }
];
AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
    })
], AppComponent);



/***/ }),

/***/ "TI4s":
/*!********************************************!*\
  !*** ./src/app/core/_guards/auth.guard.ts ***!
  \********************************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _service_authentication_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../_service/authentication.service */ "RK3O");




let AuthGuard = class AuthGuard {
    constructor(router, authenticationService) {
        this.router = router;
        this.authenticationService = authenticationService;
        this.state = '';
    }
    canActivate(route, state) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const currentUser = this.authenticationService.currentUserValue;
            if (currentUser && Object.keys(currentUser).length != 0) {
                // return true;
                // logged in so return true
                // if (currentUser.creation) {
                let currentTime = new Date().getTime();
                if (currentTime < (parseInt(currentUser.creation) + 600 * 3600 * 1000)) {
                    return true;
                }
                // }
            }
            // console.log(state.root.queryParams);
            this.code = state.root.queryParams.code;
            this.state = state.root.queryParams.state;
            if (!this.code) {
                window.location.href = 'https://open.weixin.qq.com/connect/oauth2/' + '' +
                    'authorize?appid=wxba8fbb58ebb3b73c&redirect_uri=' + encodeURIComponent(window.location.href) + '&response_type=code' +
                    '&scope=snsapi_base&state=shared#wechat_redirect';
                return false;
            }
            try {
                const data = yield this.authenticationService.login(this.code).toPromise();
                // alert(JSON.stringify(data));
                // if (data.code === 0 &&  data.ok === true) {
                if (data === 'ok') {
                    // alert('正常获取');
                    return true;
                }
            }
            catch (e) {
                // alert('异常获取');
                return false;
            }
            // not logged in so redirect to login page with the return url
            //   this.router.navigate(['/login'], { queryParams: { returnUrl: state.url }});
            return false;
        });
    }
};
AuthGuard.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _service_authentication_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"] }
];
AuthGuard = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({ providedIn: 'root' })
], AuthGuard);



/***/ }),

/***/ "VdwN":
/*!**************************************************!*\
  !*** ./src/app/core/_helpers/jwt.interceptor.ts ***!
  \**************************************************/
/*! exports provided: JwtInterceptor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JwtInterceptor", function() { return JwtInterceptor; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _service_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../_service/authentication.service */ "RK3O");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "tyNb");




let JwtInterceptor = class JwtInterceptor {
    constructor(authenticationService, router) {
        this.authenticationService = authenticationService;
        this.router = router;
    }
    intercept(request, next) {
        // add authorization header with jwt token if available
        // let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        const currentUser = this.authenticationService.currentUserValue;
        if (currentUser && currentUser.sessionKey) {
            request = request.clone({
                setHeaders: {
                    // Authorization: `Bearer ${currentUser.token}`,
                    'third-session': `${currentUser.sessionKey}` || '',
                }
            });
            if (request.url === '/mkt/api/mp/userinfo/reg') {
                return next.handle(request);
            }
            // if (!JSON.parse(localStorage.getItem('isReg'))) {
            //   this.router.navigate(['auth/signup']);
            // } else {
            const isReg = JSON.parse(localStorage.getItem('isReg'));
            if (isReg === '0') {
                this.router.navigate(['auth/signup']);
            }
            // }
        }
        return next.handle(request);
    }
};
JwtInterceptor.ctorParameters = () => [
    { type: _service_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }
];
JwtInterceptor = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
], JwtInterceptor);



/***/ }),

/***/ "VzVu":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app dir=\"{{textDir}}\">\n  <!-- when=false means that the split pane will never expand automatically -->\n  <!-- For more info check https://ionicframework.com/docs/api/split-pane -->\n    \n    <!-- Main app content get's rendered in this router-outlet -->\n    <ion-router-outlet></ion-router-outlet>\n</ion-app>");

/***/ }),

/***/ "Wf50":
/*!*********************************************!*\
  !*** ./src/app/core/module-import-guard.ts ***!
  \*********************************************/
/*! exports provided: throwIfAlreadyLoaded */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "throwIfAlreadyLoaded", function() { return throwIfAlreadyLoaded; });
function throwIfAlreadyLoaded(parentModule, moduleName) {
    if (parentModule) {
        throw new Error(`${moduleName} has already been loaded. Import Core modules in the AppModule only.`);
    }
}


/***/ }),

/***/ "ZAI4":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: createTranslateLoader, AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createTranslateLoader", function() { return createTranslateLoader; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app-routing.module */ "vY5A");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "Sy1n");
/* harmony import */ var _containers_default_layout_default_layout_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./containers/default-layout/default-layout.component */ "JPqG");
/* harmony import */ var _core_core_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @core/core.module */ "pKmL");
/* harmony import */ var _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngx-translate/http-loader */ "mqiu");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/platform-browser/animations */ "R1ws");
/* harmony import */ var ng_zorro_antd_mobile__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ng-zorro-antd-mobile */ "EZ1+");
/* harmony import */ var ngx_clipboard__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ngx-clipboard */ "Dvla");
















const APP_CONTAINERS = [
    _containers_default_layout_default_layout_component__WEBPACK_IMPORTED_MODULE_8__["DefaultLayoutComponent"]
];
function createTranslateLoader(http) {
    return new _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_10__["TranslateHttpLoader"](http, './assets/i18n/', '.json');
}
let AppModule = class AppModule {
};
AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"], ...APP_CONTAINERS],
        entryComponents: [],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["BrowserModule"],
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["BrowserTransferStateModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"].forRoot(),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_6__["AppRoutingModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClientModule"],
            _core_core_module__WEBPACK_IMPORTED_MODULE_9__["CoreModule"].forRoot(),
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__["TranslateModule"].forRoot({
                loader: {
                    provide: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__["TranslateLoader"],
                    useFactory: (createTranslateLoader),
                    deps: [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]]
                }
            }),
            _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormsModule"],
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__["BrowserAnimationsModule"],
            ng_zorro_antd_mobile__WEBPACK_IMPORTED_MODULE_14__["NgZorroAntdMobileModule"],
            ngx_clipboard__WEBPACK_IMPORTED_MODULE_15__["ClipboardModule"],
        ],
        providers: [{ provide: _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicRouteStrategy"] }],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
    })
], AppModule);



/***/ }),

/***/ "kLfG":
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet.entry.js": [
		"dUtr",
		"common",
		0
	],
	"./ion-alert.entry.js": [
		"Q8AI",
		"common",
		1
	],
	"./ion-app_8.entry.js": [
		"hgI1",
		"common",
		2
	],
	"./ion-avatar_3.entry.js": [
		"CfoV",
		"common",
		3
	],
	"./ion-back-button.entry.js": [
		"Nt02",
		"common",
		4
	],
	"./ion-backdrop.entry.js": [
		"Q2Bp",
		5
	],
	"./ion-button_2.entry.js": [
		"0Pbj",
		"common",
		6
	],
	"./ion-card_5.entry.js": [
		"ydQj",
		"common",
		7
	],
	"./ion-checkbox.entry.js": [
		"4fMi",
		"common",
		8
	],
	"./ion-chip.entry.js": [
		"czK9",
		"common",
		9
	],
	"./ion-col_3.entry.js": [
		"/CAe",
		10
	],
	"./ion-datetime_3.entry.js": [
		"WgF3",
		"common",
		11
	],
	"./ion-fab_3.entry.js": [
		"uQcF",
		"common",
		12
	],
	"./ion-img.entry.js": [
		"wHD8",
		13
	],
	"./ion-infinite-scroll_2.entry.js": [
		"2lz6",
		14
	],
	"./ion-input.entry.js": [
		"ercB",
		"common",
		15
	],
	"./ion-item-option_3.entry.js": [
		"MGMP",
		"common",
		16
	],
	"./ion-item_8.entry.js": [
		"9bur",
		"common",
		17
	],
	"./ion-loading.entry.js": [
		"cABk",
		"common",
		18
	],
	"./ion-menu_3.entry.js": [
		"kyFE",
		"common",
		19
	],
	"./ion-modal.entry.js": [
		"TvZU",
		"common",
		20
	],
	"./ion-nav_2.entry.js": [
		"vnES",
		"common",
		21
	],
	"./ion-popover.entry.js": [
		"qCuA",
		"common",
		22
	],
	"./ion-progress-bar.entry.js": [
		"0tOe",
		"common",
		23
	],
	"./ion-radio_2.entry.js": [
		"h11V",
		"common",
		24
	],
	"./ion-range.entry.js": [
		"XGij",
		"common",
		25
	],
	"./ion-refresher_2.entry.js": [
		"nYbb",
		"common",
		26
	],
	"./ion-reorder_2.entry.js": [
		"smMY",
		"common",
		27
	],
	"./ion-ripple-effect.entry.js": [
		"STjf",
		28
	],
	"./ion-route_4.entry.js": [
		"k5eQ",
		"common",
		29
	],
	"./ion-searchbar.entry.js": [
		"OR5t",
		"common",
		30
	],
	"./ion-segment_2.entry.js": [
		"fSgp",
		"common",
		31
	],
	"./ion-select_3.entry.js": [
		"lfGF",
		"common",
		32
	],
	"./ion-slide_2.entry.js": [
		"5xYT",
		33
	],
	"./ion-spinner.entry.js": [
		"nI0H",
		"common",
		34
	],
	"./ion-split-pane.entry.js": [
		"NAQR",
		35
	],
	"./ion-tab-bar_2.entry.js": [
		"knkW",
		"common",
		36
	],
	"./ion-tab_2.entry.js": [
		"TpdJ",
		"common",
		37
	],
	"./ion-text.entry.js": [
		"ISmu",
		"common",
		38
	],
	"./ion-textarea.entry.js": [
		"U7LX",
		"common",
		39
	],
	"./ion-toast.entry.js": [
		"L3sA",
		"common",
		40
	],
	"./ion-toggle.entry.js": [
		"IUOf",
		"common",
		41
	],
	"./ion-virtual-scroll.entry.js": [
		"8Mb5",
		42
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "kLfG";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "lm8q":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/containers/default-layout/default-layout.component.html ***!
  \***************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-split-pane contentId=\"menu-content\" when=\"false\">\n    <!-- when=false means that the split pane will never expand automatically -->\n    <!-- For more info check https://ionicframework.com/docs/api/split-pane -->\n           \n      <!-- Main app content get's rendered in this router-outlet -->\n      <ion-router-outlet id=\"menu-content\"></ion-router-outlet>\n    </ion-split-pane>");

/***/ }),

/***/ "pKmL":
/*!*************************************!*\
  !*** ./src/app/core/core.module.ts ***!
  \*************************************/
/*! exports provided: CoreModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoreModule", function() { return CoreModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _helpers_jwt_interceptor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./_helpers/jwt.interceptor */ "VdwN");
/* harmony import */ var _helpers_error_interceptor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./_helpers/error.interceptor */ "qQ8K");
/* harmony import */ var _module_import_guard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./module-import-guard */ "Wf50");
/* harmony import */ var _service_toast_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./_service/toast.service */ "4Jqp");
var CoreModule_1;









let CoreModule = CoreModule_1 = class CoreModule {
    constructor(parentModule) {
        // if (parentModule) {
        //   throw new Error(
        //     'CoreModule is already loaded. Import it in the AppModule only');
        // }
        Object(_module_import_guard__WEBPACK_IMPORTED_MODULE_6__["throwIfAlreadyLoaded"])(parentModule, 'CoreModule');
    }
    static forRoot() {
        return {
            ngModule: CoreModule_1,
            providers: [
                { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HTTP_INTERCEPTORS"], useClass: _helpers_jwt_interceptor__WEBPACK_IMPORTED_MODULE_4__["JwtInterceptor"], multi: true },
                { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HTTP_INTERCEPTORS"], useClass: _helpers_error_interceptor__WEBPACK_IMPORTED_MODULE_5__["ErrorInterceptor"], multi: true },
            ],
        };
    }
};
CoreModule.ctorParameters = () => [
    { type: CoreModule, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Optional"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["SkipSelf"] }] }
];
CoreModule = CoreModule_1 = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
        ],
        providers: [_service_toast_service__WEBPACK_IMPORTED_MODULE_7__["ToastService"]],
    })
], CoreModule);



/***/ }),

/***/ "qQ8K":
/*!****************************************************!*\
  !*** ./src/app/core/_helpers/error.interceptor.ts ***!
  \****************************************************/
/*! exports provided: ErrorInterceptor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ErrorInterceptor", function() { return ErrorInterceptor; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _service_authentication_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../_service/authentication.service */ "RK3O");
/* harmony import */ var _service_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../_service/toast.service */ "4Jqp");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");







let ErrorInterceptor = class ErrorInterceptor {
    constructor(authenticationService, toastService, router) {
        this.authenticationService = authenticationService;
        this.toastService = toastService;
        this.router = router;
    }
    intercept(request, next) {
        return next.handle(request).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(err => {
            if (err.status === 401) {
                // auto logout if 401 response returned from api
                this.toastService.presentErrorToast('无效授权.');
                // this.authenticationService.logout();
                // location.reload(true);
            }
            if (err.status === 301) {
                // auto logout if 401 response returned from api
                // this.toastService.presentErrorToast('登陆超时.');
                // this.authenticationService.logout();
                // location.reload(true);
                localStorage.removeItem('currentUser');
                localStorage.removeItem('sessionKey');
                // localStorage.setItem('currentUser', JSON.stringify(res));
                localStorage.removeItem('isReg');
                this.router.navigate(['app/home']);
                return;
            }
            const error = err.error.msg || err.statusText;
            this.toastService.presentErrorToast(error);
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["throwError"])(error);
        }));
    }
};
ErrorInterceptor.ctorParameters = () => [
    { type: _service_authentication_service__WEBPACK_IMPORTED_MODULE_4__["AuthenticationService"] },
    { type: _service_toast_service__WEBPACK_IMPORTED_MODULE_5__["ToastService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] }
];
ErrorInterceptor = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
], ErrorInterceptor);



/***/ }),

/***/ "vY5A":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _containers_default_layout_default_layout_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./containers/default-layout/default-layout.component */ "JPqG");
/* harmony import */ var _core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @core/_guards/auth.guard */ "TI4s");





const routes = [
    { path: '', redirectTo: 'app', pathMatch: 'full' },
    {
        path: '',
        component: _containers_default_layout_default_layout_component__WEBPACK_IMPORTED_MODULE_3__["DefaultLayoutComponent"],
        canActivate: [_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_4__["AuthGuard"]],
        children: [
            {
                path: 'app',
                loadChildren: () => __webpack_require__.e(/*! import() | pages-tabs-tabs-module */ "pages-tabs-tabs-module").then(__webpack_require__.bind(null, /*! ./pages/tabs/tabs.module */ "qiIP")).then(m => m.TabsPageModule)
            },
            {
                path: 'auth/signup',
                loadChildren: () => Promise.all(/*! import() | pages-signup-signup-module */[__webpack_require__.e("default~customers-details-customers-details-module~home-home-module~pages-accompany-accompany-module~5cd901ad"), __webpack_require__.e("common"), __webpack_require__.e("pages-signup-signup-module")]).then(__webpack_require__.bind(null, /*! ./pages/signup/signup.module */ "UUSl")).then(m => m.SignupPageModule)
            },
            {
                path: 'forms-and-validations',
                loadChildren: () => Promise.all(/*! import() | pages-validations-forms-validations-module */[__webpack_require__.e("default~customers-details-customers-details-module~home-home-module~pages-accompany-accompany-module~5cd901ad"), __webpack_require__.e("default~customers-details-customers-details-module~pages-validations-forms-validations-module"), __webpack_require__.e("pages-validations-forms-validations-module")]).then(__webpack_require__.bind(null, /*! ./pages/validations/forms-validations.module */ "7C9d")).then(m => m.FormsValidationsPageModule)
            },
            {
                path: 'forms-and-validations',
                loadChildren: () => Promise.all(/*! import() | pages-validations-forms-validations-module */[__webpack_require__.e("default~customers-details-customers-details-module~home-home-module~pages-accompany-accompany-module~5cd901ad"), __webpack_require__.e("default~customers-details-customers-details-module~pages-validations-forms-validations-module"), __webpack_require__.e("pages-validations-forms-validations-module")]).then(__webpack_require__.bind(null, /*! ./pages/validations/forms-validations.module */ "7C9d")).then(m => m.FormsValidationsPageModule)
            },
            {
                path: 'chambermaid',
                loadChildren: () => Promise.all(/*! import() | pages-chambermaid-chambermaid-module */[__webpack_require__.e("default~customers-details-customers-details-module~home-home-module~pages-accompany-accompany-module~5cd901ad"), __webpack_require__.e("default~customers-customers-module~customers-details-customers-details-module~pages-allocation-alloc~fed75d04"), __webpack_require__.e("common"), __webpack_require__.e("pages-chambermaid-chambermaid-module")]).then(__webpack_require__.bind(null, /*! ./pages/chambermaid/chambermaid.module */ "7eGE")).then(m => m.ChambermaidPageModule)
            },
            // {
            //   path: 'transact',
            //   loadChildren: () => import('./page/listing/real-estate-listing.module').then(m => m.RealEstateListingPageModule)
            // },
            {
                path: 'transact/:instanceId',
                loadChildren: () => Promise.all(/*! import() | pages-transact-details-transact-details-module */[__webpack_require__.e("default~customers-details-customers-details-module~home-home-module~pages-accompany-accompany-module~5cd901ad"), __webpack_require__.e("default~customers-customers-module~customers-details-customers-details-module~pages-allocation-alloc~fed75d04"), __webpack_require__.e("default~pages-allocation-allocation-module~pages-transact-details-transact-details-module"), __webpack_require__.e("pages-transact-details-transact-details-module")]).then(__webpack_require__.bind(null, /*! ./pages/transact/details/transact-details.module */ "uzjn")).then(m => m.TransactDetailsPageModule)
            },
            {
                path: 'complemented/:instanceId',
                loadChildren: () => Promise.all(/*! import() | pages-complemented-complemented-module */[__webpack_require__.e("default~customers-details-customers-details-module~home-home-module~pages-accompany-accompany-module~5cd901ad"), __webpack_require__.e("pages-complemented-complemented-module")]).then(__webpack_require__.bind(null, /*! ./pages/complemented/complemented.module */ "s8HK")).then(m => m.ComplementedModule)
            },
            {
                path: 'allocation/:instanceId',
                loadChildren: () => Promise.all(/*! import() | pages-allocation-allocation-module */[__webpack_require__.e("default~customers-details-customers-details-module~home-home-module~pages-accompany-accompany-module~5cd901ad"), __webpack_require__.e("default~customers-customers-module~customers-details-customers-details-module~pages-allocation-alloc~fed75d04"), __webpack_require__.e("default~pages-allocation-allocation-module~pages-transact-details-transact-details-module"), __webpack_require__.e("common"), __webpack_require__.e("pages-allocation-allocation-module")]).then(__webpack_require__.bind(null, /*! ./pages/allocation/allocation.module */ "+7CR")).then(m => m.AllocationModule)
            },
            {
                path: 'deal/:referralId',
                loadChildren: () => Promise.all(/*! import() | pages-deal-deal-module */[__webpack_require__.e("default~customers-details-customers-details-module~home-home-module~pages-accompany-accompany-module~5cd901ad"), __webpack_require__.e("common"), __webpack_require__.e("pages-deal-deal-module")]).then(__webpack_require__.bind(null, /*! ./pages/deal/deal.module */ "fHT2")).then(m => m.DealModule)
            },
            {
                path: 'docking/:referralId',
                loadChildren: () => Promise.all(/*! import() | pages-docking-docking-module */[__webpack_require__.e("default~customers-details-customers-details-module~home-home-module~pages-accompany-accompany-module~5cd901ad"), __webpack_require__.e("common"), __webpack_require__.e("pages-docking-docking-module")]).then(__webpack_require__.bind(null, /*! ./pages/docking/docking.module */ "RO7i")).then(m => m.DockingModule)
            },
            {
                path: 'accompany/:referralId',
                loadChildren: () => Promise.all(/*! import() | pages-accompany-accompany-module */[__webpack_require__.e("default~customers-details-customers-details-module~home-home-module~pages-accompany-accompany-module~5cd901ad"), __webpack_require__.e("common"), __webpack_require__.e("pages-accompany-accompany-module")]).then(__webpack_require__.bind(null, /*! ./pages/accompany/accompany.module */ "6/yJ")).then(m => m.AccompanyModule)
            }
        ]
    },
    {
        path: 'page-not-found',
        loadChildren: () => Promise.all(/*! import() | pages-page-not-found-page-not-found-module */[__webpack_require__.e("default~customers-details-customers-details-module~home-home-module~pages-accompany-accompany-module~5cd901ad"), __webpack_require__.e("pages-page-not-found-page-not-found-module")]).then(__webpack_require__.bind(null, /*! ./pages/page-not-found/page-not-found.module */ "/Cw/")).then(m => m.PageNotFoundModule)
    },
    { path: '**', redirectTo: 'app' },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "zUnb":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "a3Wg");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "ZAI4");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "AytR");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.log(err));


/***/ }),

/***/ "zn8P":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "zn8P";

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map