(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-tabs-tabs-module"],{

/***/ "1vg1":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tabs/tabs.page.html ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (" <ion-tabs>\n  <ion-tab-bar slot=\"bottom\">\n    <ion-tab-button tab=\"home\" [routerLinkActive]=\"['tab-selected']\" [routerLink]=\"['/app/home']\">\n      <ion-icon name=\"home-outline\"></ion-icon>\n      <ion-label class=\"tab-title\">首页</ion-label>\n    </ion-tab-button>\n    <ion-tab-button tab=\"referrals\" [routerLinkActive]=\"['tab-selected']\" [routerLink]=\"['/app/referrals']\">\n      <ion-icon name=\"people-outline\"></ion-icon>\n      <ion-label class=\"tab-title\">推荐客户</ion-label>\n    </ion-tab-button>\n    <ion-tab-button tab=\"mine\" [routerLinkActive]=\"['tab-selected']\" [routerLink]=\"['/app/mine']\">\n      <ion-icon name=\"person-circle-outline\"></ion-icon>\n      <ion-label class=\"tab-title\">我的</ion-label>\n    </ion-tab-button>\n  </ion-tab-bar>\n</ion-tabs>\n");

/***/ }),

/***/ "30Mf":
/*!**************************************************!*\
  !*** ./src/app/pages/tabs/tabs.router.module.ts ***!
  \**************************************************/
/*! exports provided: TabsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPageRoutingModule", function() { return TabsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./tabs.page */ "TA0h");





const routes = [
    {
        path: '',
        component: _tabs_page__WEBPACK_IMPORTED_MODULE_4__["TabsPage"],
        children: [
            {
                path: '',
                redirectTo: '/app/home',
                pathMatch: 'full',
            },
            {
                path: 'home',
                children: [
                    {
                        path: '',
                        loadChildren: () => Promise.all(/*! import() | home-home-module */[__webpack_require__.e("default~customers-details-customers-details-module~home-home-module~pages-accompany-accompany-module~5cd901ad"), __webpack_require__.e("home-home-module")]).then(__webpack_require__.bind(null, /*! ../home/home.module */ "99Un")).then(m => m.HomePageModule)
                    }
                ]
            },
            {
                path: 'referrals',
                loadChildren: () => Promise.all(/*! import() | customers-customers-module */[__webpack_require__.e("default~customers-customers-module~customers-details-customers-details-module~pages-allocation-alloc~fed75d04"), __webpack_require__.e("common"), __webpack_require__.e("customers-customers-module")]).then(__webpack_require__.bind(null, /*! ../customers/customers.module */ "SUx8")).then(m => m.CustomersPageModule)
            },
            {
                path: 'referrals/:referralId',
                loadChildren: () => Promise.all(/*! import() | customers-details-customers-details-module */[__webpack_require__.e("default~customers-details-customers-details-module~home-home-module~pages-accompany-accompany-module~5cd901ad"), __webpack_require__.e("default~customers-customers-module~customers-details-customers-details-module~pages-allocation-alloc~fed75d04"), __webpack_require__.e("default~customers-details-customers-details-module~pages-validations-forms-validations-module"), __webpack_require__.e("common"), __webpack_require__.e("customers-details-customers-details-module")]).then(__webpack_require__.bind(null, /*! ../customers/details/customers-details.module */ "Pdd+")).then(m => m.CustomersDetailsModule)
            },
            {
                path: 'mine',
                loadChildren: () => Promise.all(/*! import() | profile-user-profile-module */[__webpack_require__.e("default~customers-details-customers-details-module~home-home-module~pages-accompany-accompany-module~5cd901ad"), __webpack_require__.e("common"), __webpack_require__.e("profile-user-profile-module")]).then(__webpack_require__.bind(null, /*! ../profile/user-profile.module */ "hSiX")).then(m => m.UserProfilePageModule)
            }
        ]
    }
];
let TabsPageRoutingModule = class TabsPageRoutingModule {
};
TabsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes), _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClientModule"]],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        providers: []
    })
], TabsPageRoutingModule);



/***/ }),

/***/ "8nZx":
/*!**************************************************!*\
  !*** ./src/app/pages/tabs/styles/tabs.page.scss ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-tab-button {\n  --color: var(--ion-color-medium-shade);\n  --color-selected: var(--ion-color-dark);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3RhYnMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0Usc0NBQUE7RUFDQSx1Q0FBQTtBQUFGIiwiZmlsZSI6InRhYnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTm90ZTogIEFsbCB0aGUgQ1NTIHZhcmlhYmxlcyBkZWZpbmVkIGJlbG93IGFyZSBvdmVycmlkZXMgb2YgSW9uaWMgZWxlbWVudHMgQ1NTIEN1c3RvbSBQcm9wZXJ0aWVzXG5pb24tdGFiLWJ1dHRvbiB7XG4gIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tc2hhZGUpO1xuICAtLWNvbG9yLXNlbGVjdGVkOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XG59XG4iXX0= */");

/***/ }),

/***/ "TA0h":
/*!*****************************************!*\
  !*** ./src/app/pages/tabs/tabs.page.ts ***!
  \*****************************************/
/*! exports provided: TabsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPage", function() { return TabsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_tabs_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./tabs.page.html */ "1vg1");
/* harmony import */ var _styles_tabs_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/tabs.page.scss */ "8nZx");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _app_core_service_userInfo_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @app/core/_service/userInfo.service */ "7T6n");






let TabsPage = class TabsPage {
    // isReg = '0';
    constructor(router, userInfoService) {
        this.router = router;
        this.userInfoService = userInfoService;
    }
    ngOnInit() {
        // if (!JSON.parse(localStorage.getItem('isReg'))) {
        //   // this.userInfoService.checkIsReg().subscribe(res => {
        //   //   if (res.ok) {
        //   //     this.isReg = res.data;
        //   //     localStorage.setItem('isReg', JSON.stringify({isReg: this.isReg}));
        //   //   }
        //   // });
        //   this.userInfoService.checkIsReg().subscribe(res => {
        //     if (res.ok) {
        //       this.isReg = res.data;
        //       localStorage.setItem('isReg', JSON.stringify({ isReg: this.isReg }));
        //       if (this.isReg != true) {
        //         this.router.navigate(['auth/signup']);
        //       }
        //     }
        //   });
        // } else {
        //   this.isReg = JSON.parse(localStorage.getItem('isReg'))
        //   if (this.isReg != true) {
        //     this.router.navigate(['auth/signup']);
        //   }
        // }
        const isReg = JSON.parse(localStorage.getItem('isReg'));
        if (isReg === '0') {
            this.router.navigate(['auth/signup']);
        }
    }
    ionViewWillEnter() {
        // this.menu.enable(true);
    }
};
TabsPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _app_core_service_userInfo_service__WEBPACK_IMPORTED_MODULE_5__["UserInfoService"] }
];
TabsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-tabs',
        template: _raw_loader_tabs_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_styles_tabs_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TabsPage);



/***/ }),

/***/ "qiIP":
/*!*******************************************!*\
  !*** ./src/app/pages/tabs/tabs.module.ts ***!
  \*******************************************/
/*! exports provided: TabsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPageModule", function() { return TabsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _tabs_router_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tabs.router.module */ "30Mf");
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tabs.page */ "TA0h");







let TabsPageModule = class TabsPageModule {
};
TabsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _tabs_router_module__WEBPACK_IMPORTED_MODULE_5__["TabsPageRoutingModule"]
        ],
        declarations: [_tabs_page__WEBPACK_IMPORTED_MODULE_6__["TabsPage"]]
    })
], TabsPageModule);



/***/ })

}]);
//# sourceMappingURL=pages-tabs-tabs-module.js.map