(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-allocation-allocation-module"],{

/***/ "+7CR":
/*!*******************************************************!*\
  !*** ./src/app/pages/allocation/allocation.module.ts ***!
  \*******************************************************/
/*! exports provided: AllocationModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AllocationModule", function() { return AllocationModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _allocation_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./allocation.page */ "XUS0");
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components/components.module */ "j1ZV");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _intention_intention_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../intention/intention.page */ "nj4j");
/* harmony import */ var _transact_listing_listing_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../transact/listing/listing.page */ "KrZc");
/* harmony import */ var _app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @app/pipes/pipes.module */ "iTUp");











let AllocationModule = class AllocationModule {
};
AllocationModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
            _components_components_module__WEBPACK_IMPORTED_MODULE_6__["ComponentsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormsModule"],
            _app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_10__["PipesModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ReactiveFormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{ path: '', component: _allocation_page__WEBPACK_IMPORTED_MODULE_5__["AllocationPage"] }])
        ],
        declarations: [_allocation_page__WEBPACK_IMPORTED_MODULE_5__["AllocationPage"], _intention_intention_page__WEBPACK_IMPORTED_MODULE_8__["IntentionPage"], _transact_listing_listing_page__WEBPACK_IMPORTED_MODULE_9__["ListingPage"]],
        entryComponents: [_intention_intention_page__WEBPACK_IMPORTED_MODULE_8__["IntentionPage"], _transact_listing_listing_page__WEBPACK_IMPORTED_MODULE_9__["ListingPage"]],
    })
], AllocationModule);



/***/ }),

/***/ "RUF9":
/*!************************************************************!*\
  !*** ./src/app/pages/intention/styles/intention.page.scss ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host {\n  --page-margin: var(--app-broad-margin);\n  --page-background: var(--app-background-shade);\n}\n\nion-content {\n  position: absolute;\n  top: 0;\n  border-top: calc(var(--app-header-height) + var(--ion-safe-area-top));\n  border-top-style: solid;\n  border-top-color: var(--ion-color-primary);\n}\n\n.forms-validations-content {\n  --background: var(--page-background);\n}\n\n.forms-validations-content .validations-form {\n  margin-bottom: calc(var(--page-margin) * 2);\n}\n\n.forms-validations-content .validations-form .inputs-list {\n  --ion-item-background: var(--page-background);\n  padding: var(--page-margin) var(--page-margin) calc(var(--page-margin) * 2);\n}\n\n.forms-validations-content .validations-form .inputs-list ion-list-header {\n  padding-inline-start: 0px;\n}\n\n.forms-validations-content .validations-form .inputs-list ion-list-header .header-title {\n  text-transform: uppercase;\n  font-size: 16px;\n  color: var(--ion-color-secondary);\n}\n\n.forms-validations-content .validations-form .inputs-list .input-item {\n  --padding-start: 0px;\n  --padding-end: 0px;\n  --inner-padding-end: 0px;\n}\n\n.forms-validations-content .validations-form .inputs-list .error-container .error-message {\n  margin: calc(var(--page-margin) / 2) 0px;\n  display: flex;\n  align-items: center;\n  color: var(--ion-color-danger);\n  font-size: 14px;\n}\n\n.forms-validations-content .validations-form .inputs-list .error-container .error-message ion-icon {\n  padding-inline-end: calc(var(--page-margin) / 2);\n  flex-shrink: 0;\n}\n\n.forms-validations-content .validations-form .submit-btn {\n  margin: var(--page-margin);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2ludGVudGlvbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDRSxzQ0FBQTtFQUNBLDhDQUFBO0FBREY7O0FBSUE7RUFDRSxrQkFBQTtFQUNBLE1BQUE7RUFDQSxxRUFBQTtFQUNBLHVCQUFBO0VBQ0EsMENBQUE7QUFERjs7QUFLQTtFQUNFLG9DQUFBO0FBRkY7O0FBSUU7RUFDRSwyQ0FBQTtBQUZKOztBQUlJO0VBQ0UsNkNBQUE7RUFFQSwyRUFBQTtBQUhOOztBQUtNO0VBQ0UseUJBQUE7QUFIUjs7QUFLUTtFQUNFLHlCQUFBO0VBQ0YsZUFBQTtFQUNBLGlDQUFBO0FBSFI7O0FBT007RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0Esd0JBQUE7QUFMUjs7QUFTUTtFQUNFLHdDQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7RUFDQSxlQUFBO0FBUFY7O0FBU1U7RUFDRSxnREFBQTtFQUNBLGNBQUE7QUFQWjs7QUFhSTtFQUNFLDBCQUFBO0FBWE4iLCJmaWxlIjoiaW50ZW50aW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIEN1c3RvbSB2YXJpYWJsZXNcbi8vIE5vdGU6ICBUaGVzZSBvbmVzIHdlcmUgYWRkZWQgYnkgdXMgYW5kIGhhdmUgbm90aGluZyB0byBkbyB3aXRoIElvbmljIENTUyBDdXN0b20gUHJvcGVydGllc1xuOmhvc3Qge1xuICAtLXBhZ2UtbWFyZ2luOiB2YXIoLS1hcHAtYnJvYWQtbWFyZ2luKTtcbiAgLS1wYWdlLWJhY2tncm91bmQ6IHZhcigtLWFwcC1iYWNrZ3JvdW5kLXNoYWRlKTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMDtcbiAgYm9yZGVyLXRvcDogY2FsYyh2YXIoLS1hcHAtaGVhZGVyLWhlaWdodCkgKyB2YXIoLS1pb24tc2FmZS1hcmVhLXRvcCkpO1xuICBib3JkZXItdG9wLXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLXRvcC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG4vLyBOb3RlOiAgQWxsIHRoZSBDU1MgdmFyaWFibGVzIGRlZmluZWQgYmVsb3cgYXJlIG92ZXJyaWRlcyBvZiBJb25pYyBlbGVtZW50cyBDU1MgQ3VzdG9tIFByb3BlcnRpZXNcbi5mb3Jtcy12YWxpZGF0aW9ucy1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1wYWdlLWJhY2tncm91bmQpO1xuXG4gIC52YWxpZGF0aW9ucy1mb3JtIHtcbiAgICBtYXJnaW4tYm90dG9tOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAqIDIpO1xuXG4gICAgLmlucHV0cy1saXN0IHtcbiAgICAgIC0taW9uLWl0ZW0tYmFja2dyb3VuZDogdmFyKC0tcGFnZS1iYWNrZ3JvdW5kKTtcblxuICAgICAgcGFkZGluZzogdmFyKC0tcGFnZS1tYXJnaW4pIHZhcigtLXBhZ2UtbWFyZ2luKSBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAqIDIpO1xuXG4gICAgICBpb24tbGlzdC1oZWFkZXIge1xuICAgICAgICBwYWRkaW5nLWlubGluZS1zdGFydDogMHB4O1xuXG4gICAgICAgIC5oZWFkZXItdGl0bGUge1xuICAgICAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gICAgICBcdFx0Zm9udC1zaXplOiAxNnB4O1xuICAgICAgXHRcdGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kYXJ5KTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAuaW5wdXQtaXRlbSB7XG4gICAgICAgIC0tcGFkZGluZy1zdGFydDogMHB4O1xuICAgICAgICAtLXBhZGRpbmctZW5kOiAwcHg7XG4gICAgICAgIC0taW5uZXItcGFkZGluZy1lbmQ6IDBweDtcbiAgICAgIH1cblxuICAgICAgLmVycm9yLWNvbnRhaW5lciB7XG4gICAgICAgIC5lcnJvci1tZXNzYWdlIHtcbiAgICAgICAgICBtYXJnaW46IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMikgMHB4O1xuICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhbmdlcik7XG4gICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuXG4gICAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgICAgcGFkZGluZy1pbmxpbmUtZW5kOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDIpO1xuICAgICAgICAgICAgZmxleC1zaHJpbms6IDA7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgXHR9XG4gICAgfVxuXG4gICAgLnN1Ym1pdC1idG4ge1xuICAgICAgbWFyZ2luOiB2YXIoLS1wYWdlLW1hcmdpbik7XG4gICAgfVxuICB9XG59XG4iXX0= */");

/***/ }),

/***/ "TGrC":
/*!***************************************************************!*\
  !*** ./src/app/pages/allocation/styles/allocation.shell.scss ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("app-image-shell.user-avatar {\n  --image-shell-loading-background: rgba(var(--ion-color-light-rgb), 0.25);\n  --image-shell-border-radius: 50%;\n  --image-shell-spinner-color: var(--ion-color-light);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2FsbG9jYXRpb24uc2hlbGwuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHdFQUFBO0VBQ0EsZ0NBQUE7RUFDQSxtREFBQTtBQUNGIiwiZmlsZSI6ImFsbG9jYXRpb24uc2hlbGwuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImFwcC1pbWFnZS1zaGVsbC51c2VyLWF2YXRhciB7XG4gIC0taW1hZ2Utc2hlbGwtbG9hZGluZy1iYWNrZ3JvdW5kOiByZ2JhKHZhcigtLWlvbi1jb2xvci1saWdodC1yZ2IpLCAwLjI1KTtcbiAgLS1pbWFnZS1zaGVsbC1ib3JkZXItcmFkaXVzOiA1MCU7XG4gIC0taW1hZ2Utc2hlbGwtc3Bpbm5lci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbn1cbiJdfQ== */");

/***/ }),

/***/ "XUS0":
/*!*****************************************************!*\
  !*** ./src/app/pages/allocation/allocation.page.ts ***!
  \*****************************************************/
/*! exports provided: AllocationPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AllocationPage", function() { return AllocationPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_allocation_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./allocation.page.html */ "eh9d");
/* harmony import */ var _styles_allocation_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/allocation.page.scss */ "hVoE");
/* harmony import */ var _styles_allocation_shell_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./styles/allocation.shell.scss */ "TGrC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _app_core_service_toast_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @app/core/_service/toast.service */ "4Jqp");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _intention_intention_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../intention/intention.page */ "nj4j");
/* harmony import */ var _transact_listing_listing_page__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../transact/listing/listing.page */ "KrZc");
/* harmony import */ var _transact_transact_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../transact/transact.service */ "g/Tr");
/* harmony import */ var _allocation_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./allocation.service */ "PqGj");













let AllocationPage = class AllocationPage {
    constructor(route, router, transactService, allocationService, alertController, routerOutlet, modalController, toastService) {
        this.router = router;
        this.transactService = transactService;
        this.allocationService = allocationService;
        this.alertController = alertController;
        this.routerOutlet = routerOutlet;
        this.modalController = modalController;
        this.toastService = toastService;
        this.instanceId = route.snapshot.params['instanceId'];
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.salesmanForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            salesman: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](null, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required)
        });
        this.transactService.getCurrentTransact(this.instanceId, this.currentUser.mktUserId).subscribe(res => {
            if (res.length >= 0 && res[0] != null) {
                this.currentTaskId = res[0].id;
                this.transactService.getCurrentReferrals(this.instanceId).subscribe(data => {
                    var _a, _b;
                    //
                    // this.currentReferral = data.data;
                    if (data.data != null) {
                        const phone = (_a = data.data) === null || _a === void 0 ? void 0 : _a.phone.replace(/(\d{3})(\d{4})(\d{4})/, "$1****$3");
                        this.currentReferral = data.data;
                        this.currentReferral.phone = phone;
                        this.consultingIntention = (_b = this.currentReferral) === null || _b === void 0 ? void 0 : _b.consultingIntention;
                    }
                });
                this.allocationService.getSalesmansList().subscribe(resp => {
                    if (resp.ok) {
                        this.salesmans = resp.data;
                    }
                });
            }
            else {
                this.presentAlertConfirm('无效办理!', '您当前办理的流程已经办理或已完结!!!');
            }
        });
        this.transactService.getTaskCount(this.currentUser.mktUserId).subscribe(resp => {
            //
            if ((resp === null || resp === void 0 ? void 0 : resp.count) > 0) {
                //
                this.onHold = resp === null || resp === void 0 ? void 0 : resp.count;
            }
        });
    }
    presentModal() {
        var _a;
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _intention_intention_page__WEBPACK_IMPORTED_MODULE_9__["IntentionPage"],
                swipeToClose: true,
                presentingElement: this.routerOutlet.nativeEl,
                componentProps: {
                    'referralsId': (_a = this.currentReferral) === null || _a === void 0 ? void 0 : _a.id,
                }
            });
            // return await modal.present();
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (data) {
                // this.f.location.setValue(`${data.point[0]}, ${data.point[1]}`)
                // this.initPoint = [data.point[0], data.point[1]];
                this.consultingIntention = data === null || data === void 0 ? void 0 : data.intention;
            }
        });
    }
    ngOnInit() {
        this.salesmans;
    }
    presentAlertConfirm(header, message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: header,
                message: message,
                backdropDismiss: false,
                buttons: [
                    {
                        text: '关闭页面',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: () => {
                            // console.log('Confirm Cancel: blah');
                            WeixinJSBridge.call('closeWindow');
                        }
                    }, {
                        text: '返回首页',
                        handler: () => {
                            // console.log('Confirm Okay');
                            this.router.navigate(['/app/mine']);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    del(index) {
        var _a, _b;
        if (index && index > ((_a = this.consultingIntention) === null || _a === void 0 ? void 0 : _a.length)) {
            return;
        }
        const tmp = [...this.consultingIntention];
        tmp.splice(index, 1);
        console.log(tmp);
        if (tmp.length <= 0) {
            this.toastService.presentToast('至少保留一个意向！');
            return;
        }
        this.allocationService.updateConsultingIntention((_b = this.currentReferral) === null || _b === void 0 ? void 0 : _b.id, tmp).subscribe(res => {
            if (res.ok) {
                //
                this.consultingIntention = tmp;
            }
        });
    }
    onSubmit() {
        //
        if (this.currentTaskId == null)
            return;
        const agentId = this.salesmanForm.controls.salesman.value;
        if (agentId == null || agentId == '')
            return;
        const params = {
            withVariablesInReturn: true,
            variables: {
                agentId: { value: agentId }
            },
        };
        this.transactService.completeTask(this.currentTaskId, params).subscribe(res => {
            //
            this.presentAlertConfirm('成功办理', '您当前办理流程已经提交完成！');
        });
    }
    presentTransactModal(ins) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _transact_listing_listing_page__WEBPACK_IMPORTED_MODULE_10__["ListingPage"],
                swipeToClose: true,
                presentingElement: this.routerOutlet.nativeEl,
                componentProps: {
                    'assignee': this.currentUser.mktUserId,
                }
            });
            yield modal.present();
        });
    }
};
AllocationPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _transact_transact_service__WEBPACK_IMPORTED_MODULE_11__["TransactService"] },
    { type: _allocation_service__WEBPACK_IMPORTED_MODULE_12__["AllocationService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["IonRouterOutlet"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["ModalController"] },
    { type: _app_core_service_toast_service__WEBPACK_IMPORTED_MODULE_7__["ToastService"] }
];
AllocationPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-contact-card',
        template: _raw_loader_allocation_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_styles_allocation_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"], _styles_allocation_shell_scss__WEBPACK_IMPORTED_MODULE_3__["default"]]
    })
], AllocationPage);



/***/ }),

/***/ "eh9d":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/allocation/allocation.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- <ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header> -->\n\n<ion-content class=\"allocation-details-content\">\n \n  <ion-row class=\"user-preferences-wrapper\">\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">客户：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.customerName}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">电话：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.phone}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">咨询楼盘：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.basicInfo?.projectName}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">客户意向：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.description}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">经纪人：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.brokerName}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">经纪人电话：</h4>\n      <p class=\"preference-value\">\n        <a style=\"text-decoration:underline;\" (href)=\"'tel: ' + currentReferral?.brokerPhone\">{{currentReferral?.brokerPhone}}</a>\n      </p> \n    </ion-col>\n  </ion-row>\n\n  <ion-item-divider>\n    <ion-label>咨询客户意向</ion-label>\n  </ion-item-divider>\n  <div class=\"validations-form\">\n  <ion-item *ngFor=\"let item of consultingIntention;let i = index\">\n    <ion-badge color=\"secondary\">{{item.split('|')[0]}}</ion-badge>\n    <ion-label>{{item.split('|')[1]}}</ion-label>\n    <ion-button class=\"bookmark-button\" expand=\"block\" fill=\"clear\" color=\"medium\" (click)=\"del(i)\">\n      <ion-icon slot=\"icon-only\" name=\"trash\" ></ion-icon>\n    </ion-button>\n  </ion-item>\n\n  <!-- <hr class=\"details-divider\"> -->\n    <ion-button class=\"all-reviews-btn\" color=\"dark\" expand=\"block\" fill=\"clear\" (click)=\"presentModal()\">添加客户意向 ({{ currentReferral?.consultingIntention?.length }})</ion-button>\n    <hr class=\"details-divider\">\n</div>\n\n\n  <ion-item-divider>\n    <ion-label>选择业务员</ion-label>\n  </ion-item-divider>\n  <form [formGroup]=\"salesmanForm\" class=\"validations-form\">\n    <ion-item class=\"input-item item-label-floating\">\n      <ion-label position=\"floating\">业务员</ion-label>\n      <ion-select formControlName=\"salesman\" cancelText=\"Cancel\" okText=\"OK\">\n        <ion-select-option *ngFor=\"let item of salesmans\" [value]=\"item?.id\" >{{ item?.realName }}</ion-select-option>\n      </ion-select>\n    </ion-item>\n\n    <ion-button class=\"submit-btn\" type=\"submit\" expand=\"block\" fill=\"outline\" [disabled]=\"!salesmanForm.valid\" (click)=\"onSubmit()\">提交</ion-button>\n\n  </form>\n\n  <ion-col class=\"user-stats-wrapper\" size=\"6\" *ngIf=\"onHold > 1\">\n    <span class=\"user-stat-value\">您还有{{onHold}}条流程待办理</span>\n    <span class=\"user-stat-name\">\n      <a style=\"text-decoration:underline;\" (click)=\"presentTransactModal()\">点击查看详情</a>\n    </span>\n  </ion-col>\n\n</ion-content>\n");

/***/ }),

/***/ "hVoE":
/*!**************************************************************!*\
  !*** ./src/app/pages/allocation/styles/allocation.page.scss ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host {\n  --page-background: var(--app-background-shade);\n  --page-highlighted-background: #00AFFF;\n  --page-margin: var(--app-fair-margin);\n  --page-tags-gutter: 5px;\n}\n\nion-header ion-toolbar {\n  --background: transparent;\n}\n\nion-content {\n  position: absolute;\n  top: 0;\n  border-top-style: solid;\n  border-top-color: var(--page-highlighted-background);\n}\n\n.allocation-details-content {\n  --background: var(--page-background);\n  transform: translateZ(0);\n}\n\n.allocation-details-content ion-item-divider {\n  --background: var(--page-background);\n  --padding-top: calc(var(--page-margin) / 2);\n  --padding-start: var(--page-margin);\n  --padding-end: var(--page-margin);\n  border: none;\n}\n\n.allocation-details-content .validations-form {\n  --background: var(--page-background);\n  --ion-item-background: var(--app-background-shade);\n  padding: 0 var(--page-margin) calc(var(--page-margin) * 2);\n}\n\n.allocation-details-content .validations-form .details-divider {\n  margin: 0px var(--page-margin) calc(var(--page-margin) * 2);\n  border-top: 2px solid rgba(var(--ion-color-light-shade-rgb), 0.4);\n}\n\n.allocation-details-content .validations-form .all-reviews-btn {\n  margin: 5px 0px;\n}\n\n.allocation-details-content .validations-form .input-item {\n  --padding-start: 0px;\n  --padding-end: 0px;\n  --inner-padding-end: 0px;\n}\n\n.allocation-details-content .validations-form .terms-item {\n  --border-width: 0px;\n  --inner-padding-end: 0px;\n}\n\n.allocation-details-content .validations-form .submit-btn {\n  margin: var(--page-margin);\n}\n\n.allocation-details-content .user-preferences-wrapper {\n  --ion-grid-column-padding: 0px;\n  padding: var(--page-margin);\n}\n\n.allocation-details-content .user-preferences-wrapper .preference-name {\n  margin: 0px 0px 5px;\n  font-size: 16px;\n}\n\n.allocation-details-content .user-preferences-wrapper .preference-value {\n  margin: 0px 0px calc(var(--page-margin) / 2);\n  font-size: 14px;\n  line-height: 1.4;\n  color: var(--ion-color-dark-tint);\n}\n\n.allocation-details-content .radio-tags {\n  padding: 0px calc(var(--page-margin) - var(--page-tags-gutter));\n  background-color: var(--page-background);\n  justify-content: space-between;\n  --radio-tag-color: #000;\n  --radio-tag-background: #FFF;\n  --radio-tag-active-color: #FFF;\n  --radio-tag-active-background: #000;\n}\n\n.allocation-details-content .radio-tags .radio-tag {\n  --padding-start: 0px;\n  --inner-padding-end: 8px;\n  --inner-padding-start: 8px;\n  --min-height: 18px;\n  --border-radius: 8px;\n  --border-width: 1px;\n  --border-style: solid;\n  --border-color: var(--radio-tag-color);\n  --ion-item-background: var(--radio-tag-background);\n  --ion-item-color: var(--radio-tag-color);\n  flex: 1;\n}\n\n.allocation-details-content .radio-tags .radio-tag.item-radio-checked {\n  --ion-item-background: var(--radio-tag-active-background);\n  --ion-item-color: var(--radio-tag-active-color);\n}\n\n.allocation-details-content .radio-tags .radio-tag.item-interactive-disabled {\n  opacity: 0.5;\n}\n\n.allocation-details-content .radio-tags .radio-tag.item-interactive-disabled .tag-label {\n  opacity: 1;\n}\n\n.allocation-details-content .radio-tags .radio-tag .tag-label {\n  margin: 5px;\n  font-size: 12px;\n  font-weight: 500;\n  letter-spacing: 0.2px;\n  text-align: center;\n}\n\n.allocation-details-content .radio-tags .radio-tag ion-radio {\n  margin: 0px;\n  width: 0px;\n  --border-width: 0px;\n  height: 0px;\n  --color-checked: transparent;\n}\n\n.allocation-details-content .radio-tags .radio-tag {\n  --radio-tag-color: var(--ion-color-secondary);\n  --radio-tag-background: var(--ion-color-lightest);\n  --radio-tag-active-color: var(--ion-color-lightest);\n  --radio-tag-active-background: var(--ion-color-secondary);\n  padding: 0px var(--page-tags-gutter);\n  margin: var(--page-tags-gutter) 0px;\n}\n\n.allocation-details-content .submit-btn,\n.allocation-details-content .tip-label {\n  margin: var(--page-margin);\n}\n\n.allocation-details-content .user-stats-wrapper {\n  color: var(--ion-color-tertiary-tint);\n  text-align: center;\n  padding-top: calc(var(--page-margin) / 2);\n}\n\n.allocation-details-content .user-stats-wrapper .user-stat-value {\n  margin-right: 5px;\n  font-weight: 500;\n  font-size: 14px;\n}\n\n.allocation-details-content .user-stats-wrapper .user-stat-name {\n  font-size: 14px;\n  text-decoration: underline;\n}\n\n:host-context(.ios) .radio-tags,\n:host-context(.ios) .checkbox-tags {\n  margin-bottom: calc(var(--page-margin) * 2);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2FsbG9jYXRpb24ucGFnZS5zY3NzIiwiLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vdGhlbWUvbWl4aW5zL2lucHV0cy9yYWRpby10YWcuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHQTtFQUVFLDhDQUFBO0VBRUEsc0NBQUE7RUFHQSxxQ0FBQTtFQUVBLHVCQUFBO0FBUEY7O0FBY0U7RUFDRSx5QkFBQTtBQVhKOztBQWNBO0VBQ0Usa0JBQUE7RUFDQSxNQUFBO0VBRUEsdUJBQUE7RUFDQSxvREFBQTtBQVpGOztBQWVBO0VBQ0Usb0NBQUE7RUFFQSx3QkFBQTtBQWJGOztBQWVFO0VBQ0Esb0NBQUE7RUFFQSwyQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsaUNBQUE7RUFFQSxZQUFBO0FBZkY7O0FBbUJFO0VBQ0Usb0NBQUE7RUFFQSxrREFBQTtFQUVBLDBEQUFBO0FBbkJKOztBQXFCSTtFQUNFLDJEQUFBO0VBQ0EsaUVBQUE7QUFuQk47O0FBc0JJO0VBQ0UsZUFBQTtBQXBCTjs7QUF1Qkk7RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0Esd0JBQUE7QUFyQk47O0FBd0JJO0VBQ0UsbUJBQUE7RUFDQSx3QkFBQTtBQXRCTjs7QUF5Qkk7RUFDRSwwQkFBQTtBQXZCTjs7QUEyQkU7RUFDRSw4QkFBQTtFQUVBLDJCQUFBO0FBMUJKOztBQTRCSTtFQUNFLG1CQUFBO0VBQ0EsZUFBQTtBQTFCTjs7QUE2Qkk7RUFDRSw0Q0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGlDQUFBO0FBM0JOOztBQStCRTtFQUNFLCtEQUFBO0VBQ0Ysd0NBQUE7RUFDRSw4QkFBQTtFQ2xHRix1QkFBQTtFQUNBLDRCQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQ0FBQTtBRHNFRjs7QUNwRUM7RUFFRyxvQkFBQTtFQUNBLHdCQUFBO0VBQ0YsMEJBQUE7RUFDRSxrQkFBQTtFQUVGLG9CQUFBO0VBQ0UsbUJBQUE7RUFDRixxQkFBQTtFQUNBLHNDQUFBO0VBQ0Esa0RBQUE7RUFDQSx3Q0FBQTtFQUVFLE9BQUE7QURtRUo7O0FDakVFO0VBQ0kseURBQUE7RUFDQSwrQ0FBQTtBRG1FTjs7QUNoRUk7RUFDRSxZQUFBO0FEa0VOOztBQ2hFTTtFQUVFLFVBQUE7QURpRVI7O0FDN0RJO0VBQ0QsV0FBQTtFQUNHLGVBQUE7RUFDQSxnQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QUQrRE47O0FDNURFO0VBQ0MsV0FBQTtFQUVBLFVBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7RUFFQSw0QkFBQTtBRDRESDs7QUFQSTtFQUNFLDZDQUFBO0VBQ0EsaURBQUE7RUFDQSxtREFBQTtFQUNBLHlEQUFBO0VBRUEsb0NBQUE7RUFDQSxtQ0FBQTtBQVFOOztBQUpFOztFQUVFLDBCQUFBO0FBTUo7O0FBRkU7RUFDRSxxQ0FBQTtFQUVBLGtCQUFBO0VBQ0EseUNBQUE7QUFHSjs7QUFESTtFQUNFLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBR047O0FBQUk7RUFDRSxlQUFBO0VBQ0EsMEJBQUE7QUFFTjs7QUFJRTs7RUFFRSwyQ0FBQTtBQURKIiwiZmlsZSI6ImFsbG9jYXRpb24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGltcG9ydCBcIi4uLy4uLy4uLy4uL3RoZW1lL21peGlucy9pbnB1dHMvcmFkaW8tdGFnXCI7XG4vLyBDdXN0b20gdmFyaWFibGVzXG4vLyBOb3RlOiAgVGhlc2Ugb25lcyB3ZXJlIGFkZGVkIGJ5IHVzIGFuZCBoYXZlIG5vdGhpbmcgdG8gZG8gd2l0aCBJb25pYyBDU1MgQ3VzdG9tIFByb3BlcnRpZXNcbjpob3N0IHtcbiAgLy8gLS1wYWdlLW1hcmdpbjogdmFyKC0tYXBwLWJyb2FkLW1hcmdpbik7XG4gIC0tcGFnZS1iYWNrZ3JvdW5kOiB2YXIoLS1hcHAtYmFja2dyb3VuZC1zaGFkZSk7XG5cbiAgLS1wYWdlLWhpZ2hsaWdodGVkLWJhY2tncm91bmQ6ICMwMEFGRkY7XG5cblxuICAtLXBhZ2UtbWFyZ2luOiB2YXIoLS1hcHAtZmFpci1tYXJnaW4pO1xuXG4gIC0tcGFnZS10YWdzLWd1dHRlcjogNXB4O1xufVxuXG4vLyBOb3RlOiAgQWxsIHRoZSBDU1MgdmFyaWFibGVzIGRlZmluZWQgYmVsb3cgYXJlIG92ZXJyaWRlcyBvZiBJb25pYyBlbGVtZW50cyBDU1MgQ3VzdG9tIFByb3BlcnRpZXNcblxuLy8gVXNlIGEgY29sb3JlZCBib3JkZXItdG9wIHRvIGZpeCB3ZWlyZCB0cmFuc2l0aW9ucyBiZXR3ZWVuIHRvb2xiYXJzIHRoYXQgaGF2ZSBkaWZmZXJlbnQgYmFja2dyb3VuZCBjb2xvcnNcbmlvbi1oZWFkZXIge1xuICBpb24tdG9vbGJhciB7XG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgfVxufVxuaW9uLWNvbnRlbnQge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMDtcbiAgLy8gYm9yZGVyLXRvcDogY2FsYyh2YXIoLS1hcHAtaGVhZGVyLWhlaWdodCkgKyB2YXIoLS1pb24tc2FmZS1hcmVhLXRvcCkpO1xuICBib3JkZXItdG9wLXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLXRvcC1jb2xvcjogdmFyKC0tcGFnZS1oaWdobGlnaHRlZC1iYWNrZ3JvdW5kKTtcbn1cblxuLmFsbG9jYXRpb24tZGV0YWlscy1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1wYWdlLWJhY2tncm91bmQpO1xuICAvLyBUbyBmaXggaGFsZiBwaXhlbCBsaW5lIGJldHdlZW4gaW9uLWhlYWRlciBhbmQgIGlvbi1jb250ZW50XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWigwKTtcblxuICBpb24taXRlbS1kaXZpZGVyIHtcblx0XHQtLWJhY2tncm91bmQ6IHZhcigtLXBhZ2UtYmFja2dyb3VuZCk7XG5cdFx0Ly8gLS1wYWRkaW5nLWJvdHRvbTogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcblx0XHQtLXBhZGRpbmctdG9wOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDIpO1xuXHRcdC0tcGFkZGluZy1zdGFydDogdmFyKC0tcGFnZS1tYXJnaW4pO1xuXHRcdC0tcGFkZGluZy1lbmQ6IHZhcigtLXBhZ2UtbWFyZ2luKTtcblxuXHRcdGJvcmRlcjogbm9uZTtcblx0fVxuXG4gIFxuICAudmFsaWRhdGlvbnMtZm9ybSB7XG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1wYWdlLWJhY2tncm91bmQpO1xuICAgIFxuICAgIC0taW9uLWl0ZW0tYmFja2dyb3VuZDogdmFyKC0tYXBwLWJhY2tncm91bmQtc2hhZGUpO1xuXG4gICAgcGFkZGluZzogMCB2YXIoLS1wYWdlLW1hcmdpbikgY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgKiAyKTtcblxuICAgIC5kZXRhaWxzLWRpdmlkZXIge1xuICAgICAgbWFyZ2luOiAwcHggdmFyKC0tcGFnZS1tYXJnaW4pIGNhbGModmFyKC0tcGFnZS1tYXJnaW4pICogMik7XG4gICAgICBib3JkZXItdG9wOiAycHggc29saWQgcmdiYSh2YXIoLS1pb24tY29sb3ItbGlnaHQtc2hhZGUtcmdiKSwgLjQpO1xuICAgIH1cblxuICAgIC5hbGwtcmV2aWV3cy1idG4ge1xuICAgICAgbWFyZ2luOiA1cHggMHB4O1xuICAgIH1cblxuICAgIC5pbnB1dC1pdGVtIHtcbiAgICAgIC0tcGFkZGluZy1zdGFydDogMHB4O1xuICAgICAgLS1wYWRkaW5nLWVuZDogMHB4O1xuICAgICAgLS1pbm5lci1wYWRkaW5nLWVuZDogMHB4O1xuICAgIH1cblxuICAgIC50ZXJtcy1pdGVtIHtcbiAgICAgIC0tYm9yZGVyLXdpZHRoOiAwcHg7XG4gICAgICAtLWlubmVyLXBhZGRpbmctZW5kOiAwcHg7XG4gICAgfVxuXG4gICAgLnN1Ym1pdC1idG4ge1xuICAgICAgbWFyZ2luOiB2YXIoLS1wYWdlLW1hcmdpbik7XG4gICAgfVxuICB9XG5cbiAgLnVzZXItcHJlZmVyZW5jZXMtd3JhcHBlciB7XG4gICAgLS1pb24tZ3JpZC1jb2x1bW4tcGFkZGluZzogMHB4O1xuXG4gICAgcGFkZGluZzogdmFyKC0tcGFnZS1tYXJnaW4pO1xuXG4gICAgLnByZWZlcmVuY2UtbmFtZSB7XG4gICAgICBtYXJnaW46IDBweCAwcHggNXB4O1xuICAgICAgZm9udC1zaXplOiAxNnB4O1xuICAgIH1cblxuICAgIC5wcmVmZXJlbmNlLXZhbHVlIHtcbiAgICAgIG1hcmdpbjogMHB4IDBweCBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDIpO1xuICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgbGluZS1oZWlnaHQ6IDEuNDtcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyay10aW50KTtcbiAgICB9XG4gIH1cblxuICAucmFkaW8tdGFncyB7XG4gICAgcGFkZGluZzogMHB4IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC0gdmFyKC0tcGFnZS10YWdzLWd1dHRlcikpO1xuXHRcdGJhY2tncm91bmQtY29sb3I6IHZhcigtLXBhZ2UtYmFja2dyb3VuZCk7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuXG5cdFx0QGluY2x1ZGUgcmFkaW8tdGFnKCk7XG5cbiAgICAvLyBBZGQgYSBkZWVwZXIgc2VsZWN0b3IgdG8gb3ZlcnJpZGUgZGVmYXVsdCBjb2xvcnNcbiAgICAucmFkaW8tdGFnIHtcbiAgICAgIC0tcmFkaW8tdGFnLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kYXJ5KTtcbiAgICAgIC0tcmFkaW8tdGFnLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1saWdodGVzdCk7XG4gICAgICAtLXJhZGlvLXRhZy1hY3RpdmUtY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodGVzdCk7XG4gICAgICAtLXJhZGlvLXRhZy1hY3RpdmUtYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeSk7XG5cbiAgICAgIHBhZGRpbmc6IDBweCB2YXIoLS1wYWdlLXRhZ3MtZ3V0dGVyKTtcbiAgICAgIG1hcmdpbjogdmFyKC0tcGFnZS10YWdzLWd1dHRlcikgMHB4O1xuICAgIH1cblx0fVxuXG4gIC5zdWJtaXQtYnRuLFxuICAudGlwLWxhYmVsIHtcbiAgICBtYXJnaW46IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgfVxuXG5cbiAgLnVzZXItc3RhdHMtd3JhcHBlciB7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeS10aW50KTtcbiAgICBcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgcGFkZGluZy10b3A6IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMik7XG5cbiAgICAudXNlci1zdGF0LXZhbHVlIHtcbiAgICAgIG1hcmdpbi1yaWdodDogNXB4O1xuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICB9XG5cbiAgICAudXNlci1zdGF0LW5hbWUge1xuICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgfVxuICB9XG59XG5cbjpob3N0LWNvbnRleHQoLmlvcykge1xuICAucmFkaW8tdGFncyxcbiAgLmNoZWNrYm94LXRhZ3Mge1xuICAgIG1hcmdpbi1ib3R0b206IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pICogMik7XG4gIH1cbn1cbiIsIkBtaXhpbiByYWRpby10YWcoKSB7XG4gIC8vIERlZmF1bHQgdmFsdWVzXG4gIC0tcmFkaW8tdGFnLWNvbG9yOiAjMDAwO1xuICAtLXJhZGlvLXRhZy1iYWNrZ3JvdW5kOiAjRkZGO1xuICAtLXJhZGlvLXRhZy1hY3RpdmUtY29sb3I6ICNGRkY7XG4gIC0tcmFkaW8tdGFnLWFjdGl2ZS1iYWNrZ3JvdW5kOiAjMDAwO1xuXG5cdC5yYWRpby10YWcge1xuICAgIC8vIFJlc2V0IHZhbHVlcyBmcm9tIElvbmljIChpb24taXRlbSkgc3R5bGVzXG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAwcHg7XG4gICAgLS1pbm5lci1wYWRkaW5nLWVuZDogOHB4O1xuXHRcdC0taW5uZXItcGFkZGluZy1zdGFydDogOHB4O1xuICAgIC0tbWluLWhlaWdodDogMThweDtcblxuXHRcdC0tYm9yZGVyLXJhZGl1czogOHB4O1xuICAgIC0tYm9yZGVyLXdpZHRoOiAxcHg7XG5cdFx0LS1ib3JkZXItc3R5bGU6IHNvbGlkO1xuXHRcdC0tYm9yZGVyLWNvbG9yOiB2YXIoLS1yYWRpby10YWctY29sb3IpO1xuXHRcdC0taW9uLWl0ZW0tYmFja2dyb3VuZDogdmFyKC0tcmFkaW8tdGFnLWJhY2tncm91bmQpO1xuXHRcdC0taW9uLWl0ZW0tY29sb3I6IHZhcigtLXJhZGlvLXRhZy1jb2xvcik7XG5cbiAgICBmbGV4OiAxO1xuXG5cdFx0Ji5pdGVtLXJhZGlvLWNoZWNrZWQge1xuICAgICAgLS1pb24taXRlbS1iYWNrZ3JvdW5kOiB2YXIoLS1yYWRpby10YWctYWN0aXZlLWJhY2tncm91bmQpO1xuICAgICAgLS1pb24taXRlbS1jb2xvcjogdmFyKC0tcmFkaW8tdGFnLWFjdGl2ZS1jb2xvcik7XG5cdFx0fVxuXG4gICAgJi5pdGVtLWludGVyYWN0aXZlLWRpc2FibGVkIHtcbiAgICAgIG9wYWNpdHk6IDAuNTtcblxuICAgICAgLnRhZy1sYWJlbCB7XG4gICAgICAgIC8vIE92ZXJyaWRlIElvbmljIGRlZmF1bHQgc3R5bGVcbiAgICAgICAgb3BhY2l0eTogMTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAudGFnLWxhYmVsIHtcblx0XHRcdG1hcmdpbjogNXB4O1xuICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgIGxldHRlci1zcGFjaW5nOiAwLjJweDtcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcblx0XHR9XG5cblx0XHRpb24tcmFkaW8ge1xuXHRcdFx0bWFyZ2luOiAwcHg7XG5cdFx0XHQvLyBUbyBoaWRlIHRoZSAucmFkaW8taWNvblxuXHRcdFx0d2lkdGg6IDBweDtcblx0XHRcdC0tYm9yZGVyLXdpZHRoOiAwcHg7XG5cdFx0XHRoZWlnaHQ6IDBweDtcblx0XHRcdC8vIFdlIGNhbnQgc2V0IHdpZHRoIGFuZCBoZWlnaHQgZm9yIC5yYWRpby1pY29uIC5yYWRpby1pbm5lciwgc28gbGV0cyBoaWRlIGl0IGNoYW5naW5nIGl0cyBjb2xvclxuXHRcdFx0LS1jb2xvci1jaGVja2VkOiB0cmFuc3BhcmVudDtcblx0XHR9XG5cdH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "nTid":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/intention/intention.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"dismiss()\">关闭</ion-button>\n    </ion-buttons>\n    <ion-title>\n      添加意向\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"forms-validations-content\">\n  <form class=\"validations-form\" [formGroup]=\"validationsForm\" (ngSubmit)=\"onSubmit(validationsForm.value)\">\n    <ion-list class=\"inputs-list\" lines=\"full\">\n      <!-- <ion-list-header>\n        <ion-label class=\"header-title\"></ion-label>\n      </ion-list-header> -->\n\n      <!-- When this bug (https://github.com/ionic-team/ionic-framework/issues/22117) gets fixed, remove .item-label-floating class -->\n      <ion-item class=\"input-item item-label-floating\">\n        <ion-label position=\"floating\">意向标题</ion-label>\n        <ion-input type=\"text\" formControlName=\"title\" clearInput required></ion-input>\n      </ion-item>\n      <div class=\"error-container\">\n        <ng-container *ngFor=\"let validation of validations.title\">\n          <div class=\"error-message\" *ngIf=\"validationsForm.get('title').hasError(validation.type) && (validationsForm.get('title').dirty || validationsForm.get('title').touched)\">\n            <ion-icon name=\"information-circle-outline\"></ion-icon>\n            <span>{{ validation.message }}</span>\n          </div>\n        </ng-container>\n      </div>\n\n      <!-- When this bug (https://github.com/ionic-team/ionic-framework/issues/22117) gets fixed, remove .item-label-floating class -->\n      <ion-item class=\"input-item item-label-floating\">\n        <ion-label position=\"floating\">意向内容</ion-label>\n        <ion-input type=\"text\" formControlName=\"details\" clearInput></ion-input>\n      </ion-item>\n      <div class=\"error-container\">\n        <ng-container *ngFor=\"let validation of validations.details\">\n          <div class=\"error-message\" *ngIf=\"validationsForm.get('details').hasError(validation.type) && (validationsForm.get('details').dirty || validationsForm.get('details').touched)\">\n            <ion-icon name=\"information-circle-outline\"></ion-icon>\n            <span>{{ validation.message }}</span>\n          </div>\n        </ng-container>\n      </div>\n    </ion-list>\n\n    <ion-button class=\"submit-btn\" type=\"submit\" expand=\"block\" fill=\"outline\" [disabled]=\"!validationsForm.valid\">确认添加</ion-button>\n  </form>\n</ion-content>\n");

/***/ }),

/***/ "nj4j":
/*!***************************************************!*\
  !*** ./src/app/pages/intention/intention.page.ts ***!
  \***************************************************/
/*! exports provided: IntentionPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IntentionPage", function() { return IntentionPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_intention_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./intention.page.html */ "nTid");
/* harmony import */ var _styles_intention_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/intention.page.scss */ "RUF9");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _allocation_allocation_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../allocation/allocation.service */ "PqGj");







let IntentionPage = class IntentionPage {
    constructor(modalController, allocationService) {
        this.modalController = modalController;
        this.allocationService = allocationService;
        this.validations = {
            'title': [
                { type: 'required', message: '标题不能为空' }
            ],
            'details': [
                { type: 'required', message: '内容不能为空' }
            ]
        };
    }
    ngOnInit() {
        this.validationsForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
            'title': new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required),
            'details': new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required)
        });
    }
    dismiss() {
        this.modalController.dismiss();
    }
    // passDismiss() {
    //   // using the injected ModalController this page
    //   // can "dismiss" itself and optionally pass back data
    //   this.modalController.dismiss({
    //       'intention': this.intention
    //   });
    // }
    onSubmit(values) {
        if (!this.referralsId) {
            return;
        }
        const intentionTmp = this.validationsForm.controls.title.value + '|' + this.validationsForm.controls.details.value;
        this.allocationService.addIntention(this.referralsId, intentionTmp).subscribe(res => {
            if (res.ok) {
                this.intention = res.data;
                this.modalController.dismiss({
                    'intention': this.intention
                });
            }
        });
    }
};
IntentionPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: _allocation_allocation_service__WEBPACK_IMPORTED_MODULE_6__["AllocationService"] }
];
IntentionPage.propDecorators = {
    referralsId: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
IntentionPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-intention-page',
        template: _raw_loader_intention_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_styles_intention_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], IntentionPage);



/***/ })

}]);
//# sourceMappingURL=pages-allocation-allocation-module.js.map