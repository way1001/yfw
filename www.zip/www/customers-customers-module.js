(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["customers-customers-module"],{

/***/ "1WSO":
/*!*************************************************************!*\
  !*** ./src/app/pages/customers/styles/customers.shell.scss ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("app-image-shell.user-image {\n  --image-shell-border-radius: var(--page-border-radius);\n}\n\n.user-name > app-text-shell {\n  --text-shell-line-height: 16px;\n  max-width: 50%;\n}\n\n.user-name > app-text-shell.text-loaded {\n  max-width: unset;\n}\n\n.user-job > app-text-shell {\n  --text-shell-line-height: 14px;\n  max-width: 70%;\n}\n\n.user-job > app-text-shell.text-loaded {\n  max-width: unset;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2N1c3RvbWVycy5zaGVsbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usc0RBQUE7QUFDRjs7QUFFQTtFQUNFLDhCQUFBO0VBQ0EsY0FBQTtBQUNGOztBQUNFO0VBQ0UsZ0JBQUE7QUFDSjs7QUFHQTtFQUNFLDhCQUFBO0VBQ0EsY0FBQTtBQUFGOztBQUVFO0VBQ0UsZ0JBQUE7QUFBSiIsImZpbGUiOiJjdXN0b21lcnMuc2hlbGwuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImFwcC1pbWFnZS1zaGVsbC51c2VyLWltYWdlIHtcbiAgLS1pbWFnZS1zaGVsbC1ib3JkZXItcmFkaXVzOiB2YXIoLS1wYWdlLWJvcmRlci1yYWRpdXMpO1xufVxuXG4udXNlci1uYW1lID4gYXBwLXRleHQtc2hlbGwge1xuICAtLXRleHQtc2hlbGwtbGluZS1oZWlnaHQ6IDE2cHg7XG4gIG1heC13aWR0aDogNTAlO1xuXG4gICYudGV4dC1sb2FkZWQge1xuICAgIG1heC13aWR0aDogdW5zZXQ7XG4gIH1cbn1cblxuLnVzZXItam9iID4gYXBwLXRleHQtc2hlbGwge1xuICAtLXRleHQtc2hlbGwtbGluZS1oZWlnaHQ6IDE0cHg7XG4gIG1heC13aWR0aDogNzAlO1xuXG4gICYudGV4dC1sb2FkZWQge1xuICAgIG1heC13aWR0aDogdW5zZXQ7XG4gIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "5aaP":
/*!************************************************************!*\
  !*** ./src/app/pages/customers/styles/customers.page.scss ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host {\n  --page-margin: var(--app-narrow-margin);\n  --page-border-radius: var(--app-fair-radius);\n  --page-segment-background: var(--app-background);\n  --page-segment-indicator-height: 2px;\n  --page-color-rgb: 235,187,0;\n}\n\n.user-friends-segment {\n  --background: var(--page-segment-background);\n  position: sticky;\n  top: 0;\n  z-index: 8;\n}\n\n.user-friends-segment ion-segment-button {\n  --padding-end: var(--page-margin);\n  --padding-start: var(--page-margin);\n  --color: rgba(var(--ion-color-dark-rgb), 0.4);\n  --indicator-color: var(--ion-color-dark);\n  text-transform: capitalize;\n  min-height: calc((var(--page-margin) * 3) - var(--page-segment-indicator-height));\n}\n\nion-searchbar.friends-searchbar {\n  padding: calc(var(--page-margin) * 1.5) var(--page-margin);\n}\n\n.friends-list {\n  padding: 0px var(--page-margin);\n  margin-bottom: calc(var(--page-margin) * 3);\n}\n\n.empty-list-message {\n  margin: calc(var(--page-margin) * 3);\n  color: rgba(var(--ion-color-dark-rgb), 0.4);\n  text-align: center;\n}\n\nion-item.friend-item {\n  --inner-padding-start: 0px;\n  --inner-padding-end: 0px;\n  --padding-start: 0px;\n  --padding-end: 0px;\n  --padding-bottom: var(--page-margin);\n  --inner-padding-bottom: var(--page-margin);\n}\n\nion-item.friend-item:last-child {\n  --border-style: none;\n  --padding-bottom: 0px;\n  --inner-padding-bottom: 0px;\n}\n\nion-item.friend-item .user-details-section {\n  --ion-grid-column-padding: 0px;\n  --ion-grid-columns: 10;\n  margin: 0px calc(var(--page-pictures-gutter) * -1);\n  width: 100%;\n  align-items: center;\n}\n\nion-item.friend-item .user-details-section .picture-wrapper {\n  --col-item-width: 2;\n  flex: 0 0 calc(calc(var(--col-item-width) / var(--ion-grid-columns, 12)) * 100%);\n  width: calc(calc(var(--col-item-width) / var(--ion-grid-columns, 12)) * 100%);\n  max-width: calc(calc(var(--col-item-width) / var(--ion-grid-columns, 12)) * 100%);\n  padding: 0px var(--page-pictures-gutter);\n}\n\nion-item.friend-item .user-details-section .picture-wrapper .has-more-pictures {\n  top: 0px;\n  bottom: 0px;\n  left: 0px;\n  right: 0px;\n  margin: 0px var(--page-pictures-gutter);\n  background-color: rgba(var(--page-color-rgb), 0.7);\n  border-radius: var(--app-narrow-radius);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  text-decoration: none;\n  z-index: 2;\n}\n\nion-item.friend-item .user-details-section .picture-wrapper .has-more-pictures .pictures-count {\n  font-size: 32px;\n  color: var(--ion-color-lightest);\n  font-weight: 600;\n}\n\nion-item.friend-item .user-details-section .picture-wrapper .has-more-pictures .pictures-count::before {\n  content: \"\";\n  font-size: 42px;\n  color: var(--ion-color-lightest);\n  font-weight: 600;\n}\n\nion-item.friend-item .user-details-section .user-data-wrapper {\n  padding-left: var(--page-margin);\n  padding-right: calc(var(--page-margin) / 2);\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n}\n\nion-item.friend-item .user-details-section .user-data-wrapper .user-info:not(:last-child) {\n  margin-bottom: calc(var(--page-margin) / 2);\n}\n\nion-item.friend-item .user-details-section .user-data-wrapper .user-info .user-name {\n  margin: 0px;\n  margin-bottom: 4px;\n  font-size: 16px;\n}\n\nion-item.friend-item .user-details-section .user-data-wrapper .user-info .user-job {\n  margin: 0px;\n  color: rgba(var(--ion-color-dark-rgb), 0.4);\n  font-size: 14px;\n}\n\nion-item.friend-item .user-details-section .user-actions-wrapper {\n  font-size: 14px;\n  max-width: 10ex;\n  max-width: 10ch;\n}\n\nion-item.friend-item .user-details-section .user-actions-wrapper .user-action {\n  margin: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2N1c3RvbWVycy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDRSx1Q0FBQTtFQUNBLDRDQUFBO0VBQ0EsZ0RBQUE7RUFDQSxvQ0FBQTtFQUVBLDJCQUFBO0FBRkY7O0FBTUE7RUFDRSw0Q0FBQTtFQUNBLGdCQUFBO0VBQ0EsTUFBQTtFQUNBLFVBQUE7QUFIRjs7QUFLRTtFQUNFLGlDQUFBO0VBQ0EsbUNBQUE7RUFDQSw2Q0FBQTtFQUNBLHdDQUFBO0VBRUEsMEJBQUE7RUFDQSxpRkFBQTtBQUpKOztBQVFBO0VBQ0UsMERBQUE7QUFMRjs7QUFRQTtFQUNFLCtCQUFBO0VBQ0EsMkNBQUE7QUFMRjs7QUFRQTtFQUNFLG9DQUFBO0VBQ0EsMkNBQUE7RUFDQSxrQkFBQTtBQUxGOztBQVFBO0VBQ0UsMEJBQUE7RUFDQSx3QkFBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxvQ0FBQTtFQUNBLDBDQUFBO0FBTEY7O0FBT0U7RUFDRSxvQkFBQTtFQUNBLHFCQUFBO0VBQ0EsMkJBQUE7QUFMSjs7QUFRRTtFQUNFLDhCQUFBO0VBQ0Esc0JBQUE7RUFFQSxrREFBQTtFQUVBLFdBQUE7RUFDQSxtQkFBQTtBQVJKOztBQVVJO0VBQ0UsbUJBQUE7RUFFQSxnRkFBQTtFQUNBLDZFQUFBO0VBQ0EsaUZBQUE7RUFFQSx3Q0FBQTtBQVZOOztBQVlNO0VBRUYsUUFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtFQUVJLHVDQUFBO0VBQ0osa0RBQUE7RUFDSSx1Q0FBQTtFQUNKLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0kscUJBQUE7RUFDQSxVQUFBO0FBWlI7O0FBY0k7RUFDQyxlQUFBO0VBQ0EsZ0NBQUE7RUFDQSxnQkFBQTtBQVpMOztBQWNLO0VBQ0MsV0FBQTtFQUNBLGVBQUE7RUFDQSxnQ0FBQTtFQUNBLGdCQUFBO0FBWk47O0FBa0JJO0VBQ0UsZ0NBQUE7RUFDQSwyQ0FBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0FBaEJOOztBQW1CUTtFQUNFLDJDQUFBO0FBakJWOztBQW9CUTtFQUNFLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUFsQlY7O0FBcUJRO0VBQ0UsV0FBQTtFQUNBLDJDQUFBO0VBQ0EsZUFBQTtBQW5CVjs7QUF3Qkk7RUFDRSxlQUFBO0VBS0EsZUFBQTtFQUNBLGVBQUE7QUExQk47O0FBNEJNO0VBQ0UsV0FBQTtBQTFCUiIsImZpbGUiOiJjdXN0b21lcnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gQ3VzdG9tIHZhcmlhYmxlc1xuLy8gTm90ZTogIFRoZXNlIG9uZXMgd2VyZSBhZGRlZCBieSB1cyBhbmQgaGF2ZSBub3RoaW5nIHRvIGRvIHdpdGggSW9uaWMgQ1NTIEN1c3RvbSBQcm9wZXJ0aWVzXG46aG9zdCB7XG4gIC0tcGFnZS1tYXJnaW46IHZhcigtLWFwcC1uYXJyb3ctbWFyZ2luKTtcbiAgLS1wYWdlLWJvcmRlci1yYWRpdXM6IHZhcigtLWFwcC1mYWlyLXJhZGl1cyk7XG4gIC0tcGFnZS1zZWdtZW50LWJhY2tncm91bmQ6IHZhcigtLWFwcC1iYWNrZ3JvdW5kKTtcbiAgLS1wYWdlLXNlZ21lbnQtaW5kaWNhdG9yLWhlaWdodDogMnB4O1xuXG4gIC0tcGFnZS1jb2xvci1yZ2I6IDIzNSwxODcsMDtcbn1cblxuLy8gTm90ZTogIEFsbCB0aGUgQ1NTIHZhcmlhYmxlcyBkZWZpbmVkIGJlbG93IGFyZSBvdmVycmlkZXMgb2YgSW9uaWMgZWxlbWVudHMgQ1NTIEN1c3RvbSBQcm9wZXJ0aWVzXG4udXNlci1mcmllbmRzLXNlZ21lbnQge1xuICAtLWJhY2tncm91bmQ6IHZhcigtLXBhZ2Utc2VnbWVudC1iYWNrZ3JvdW5kKTtcbiAgcG9zaXRpb246IHN0aWNreTtcbiAgdG9wOiAwO1xuICB6LWluZGV4OiA4O1xuXG4gIGlvbi1zZWdtZW50LWJ1dHRvbiB7XG4gICAgLS1wYWRkaW5nLWVuZDogdmFyKC0tcGFnZS1tYXJnaW4pO1xuICAgIC0tcGFkZGluZy1zdGFydDogdmFyKC0tcGFnZS1tYXJnaW4pO1xuICAgIC0tY29sb3I6IHJnYmEodmFyKC0taW9uLWNvbG9yLWRhcmstcmdiKSwgMC40KTtcbiAgICAtLWluZGljYXRvci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xuXG4gICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG4gICAgbWluLWhlaWdodDogY2FsYygodmFyKC0tcGFnZS1tYXJnaW4pICogMykgLSB2YXIoLS1wYWdlLXNlZ21lbnQtaW5kaWNhdG9yLWhlaWdodCkpO1xuICB9XG59XG5cbmlvbi1zZWFyY2hiYXIuZnJpZW5kcy1zZWFyY2hiYXIge1xuICBwYWRkaW5nOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAqIDEuNSkgdmFyKC0tcGFnZS1tYXJnaW4pO1xufVxuXG4uZnJpZW5kcy1saXN0IHtcbiAgcGFkZGluZzogMHB4IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgbWFyZ2luLWJvdHRvbTogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgKiAzKTtcbn1cblxuLmVtcHR5LWxpc3QtbWVzc2FnZSB7XG4gIG1hcmdpbjogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgKiAzKTtcbiAgY29sb3I6IHJnYmEodmFyKC0taW9uLWNvbG9yLWRhcmstcmdiKSwgMC40KTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG5pb24taXRlbS5mcmllbmQtaXRlbSB7XG4gIC0taW5uZXItcGFkZGluZy1zdGFydDogMHB4O1xuICAtLWlubmVyLXBhZGRpbmctZW5kOiAwcHg7XG4gIC0tcGFkZGluZy1zdGFydDogMHB4O1xuICAtLXBhZGRpbmctZW5kOiAwcHg7XG4gIC0tcGFkZGluZy1ib3R0b206IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgLS1pbm5lci1wYWRkaW5nLWJvdHRvbTogdmFyKC0tcGFnZS1tYXJnaW4pO1xuXG4gICY6bGFzdC1jaGlsZCB7XG4gICAgLS1ib3JkZXItc3R5bGU6IG5vbmU7XG4gICAgLS1wYWRkaW5nLWJvdHRvbTogMHB4O1xuICAgIC0taW5uZXItcGFkZGluZy1ib3R0b206IDBweDtcbiAgfVxuXG4gIC51c2VyLWRldGFpbHMtc2VjdGlvbiB7XG4gICAgLS1pb24tZ3JpZC1jb2x1bW4tcGFkZGluZzogMHB4O1xuICAgIC0taW9uLWdyaWQtY29sdW1uczogMTA7XG5cbiAgICBtYXJnaW46IDBweCBjYWxjKHZhcigtLXBhZ2UtcGljdHVyZXMtZ3V0dGVyKSAqIC0xKTtcblxuICAgIHdpZHRoOiAxMDAlO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cbiAgICAucGljdHVyZS13cmFwcGVyIHtcbiAgICAgIC0tY29sLWl0ZW0td2lkdGg6IDI7XG4gICAgICAvLyBTU1IgZml4OiBPdmVycmlkZSBpb24tY29sIHN0eWxlc1xuICAgICAgZmxleDogMCAwIGNhbGMoY2FsYyh2YXIoLS1jb2wtaXRlbS13aWR0aCkgLyB2YXIoLS1pb24tZ3JpZC1jb2x1bW5zLCAxMikpICogMTAwJSk7XG4gICAgICB3aWR0aDogY2FsYyhjYWxjKHZhcigtLWNvbC1pdGVtLXdpZHRoKSAvIHZhcigtLWlvbi1ncmlkLWNvbHVtbnMsIDEyKSkgKiAxMDAlKTtcbiAgICAgIG1heC13aWR0aDogY2FsYyhjYWxjKHZhcigtLWNvbC1pdGVtLXdpZHRoKSAvIHZhcigtLWlvbi1ncmlkLWNvbHVtbnMsIDEyKSkgKiAxMDAlKTtcblxuICAgICAgcGFkZGluZzogMHB4IHZhcigtLXBhZ2UtcGljdHVyZXMtZ3V0dGVyKTtcblxuICAgICAgLmhhcy1tb3JlLXBpY3R1cmVzIHtcblx0XHRcdFx0Ly8gcG9zaXRpb246IGFic29sdXRlO1xuXHRcdFx0XHR0b3A6IDBweDtcblx0XHRcdFx0Ym90dG9tOiAwcHg7XG5cdFx0XHRcdGxlZnQ6IDBweDtcblx0XHRcdFx0cmlnaHQ6IDBweDtcbiAgICAgICAgLy8gVG8gY29tcGVuc2F0ZSB0aGUgLnBpY3R1cmUtd3JhcHBlciBwYWRkaW5nXG4gICAgICAgIG1hcmdpbjogMHB4IHZhcigtLXBhZ2UtcGljdHVyZXMtZ3V0dGVyKTtcblx0XHRcdFx0YmFja2dyb3VuZC1jb2xvcjogcmdiYSh2YXIoLS1wYWdlLWNvbG9yLXJnYiksIC43MCk7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IHZhcigtLWFwcC1uYXJyb3ctcmFkaXVzKTtcblx0XHRcdFx0ZGlzcGxheTogZmxleDtcblx0XHRcdFx0YWxpZ24taXRlbXM6IGNlbnRlcjtcblx0XHRcdFx0anVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbiAgICAgICAgei1pbmRleDogMjtcblxuXHRcdFx0XHQucGljdHVyZXMtY291bnQge1xuXHRcdFx0XHRcdGZvbnQtc2l6ZTogMzJweDtcblx0XHRcdFx0XHRjb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0ZXN0KTtcblx0XHRcdFx0XHRmb250LXdlaWdodDogNjAwO1xuXG5cdFx0XHRcdFx0Jjo6YmVmb3JlIHtcblx0XHRcdFx0XHRcdGNvbnRlbnQ6ICcnO1xuXHRcdFx0XHRcdFx0Zm9udC1zaXplOiA0MnB4O1xuXHRcdFx0XHRcdFx0Y29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodGVzdCk7XG5cdFx0XHRcdFx0XHRmb250LXdlaWdodDogNjAwO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuICAgIH1cblxuICAgIC51c2VyLWRhdGEtd3JhcHBlciB7XG4gICAgICBwYWRkaW5nLWxlZnQ6IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgICAgIHBhZGRpbmctcmlnaHQ6IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMik7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuXG4gICAgICAudXNlci1pbmZvIHtcbiAgICAgICAgJjpub3QoOmxhc3QtY2hpbGQpIHtcbiAgICAgICAgICBtYXJnaW4tYm90dG9tOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDIpO1xuICAgICAgICB9XG5cbiAgICAgICAgLnVzZXItbmFtZSB7XG4gICAgICAgICAgbWFyZ2luOiAwcHg7XG4gICAgICAgICAgbWFyZ2luLWJvdHRvbTogNHB4O1xuICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgICAgfVxuXG4gICAgICAgIC51c2VyLWpvYiB7XG4gICAgICAgICAgbWFyZ2luOiAwcHg7XG4gICAgICAgICAgY29sb3I6IHJnYmEodmFyKC0taW9uLWNvbG9yLWRhcmstcmdiKSwgMC40KTtcbiAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICAudXNlci1hY3Rpb25zLXdyYXBwZXIge1xuICAgICAgZm9udC1zaXplOiAxNHB4O1xuXG4gICAgICAvLyBNYWtlIHN1cmUgd2UgYWx3YXlzIGhhdmUgc3BhY2UgZm9yIDEwIGNoYXJhY3RlcnNcbiAgICAgIC8vIEFzIGNoICh3aWR0aCBvZiB0aGUgY2hhcmFjdGVyICcwJykgdW5pdCBpcyBub3QgMTAwJSBzdXBwb3J0ZWQsIHdlIHdpbGwgdXNlIGV4IChoZWlnaHQgb2YgdGhlICd4JyBjaGFyYWN0ZXIpIGFzIGEgZmFsbGJhY2tcbiAgICAgIC8vIFNlZTogaHR0cHM6Ly93d3cucXVpcmtzbW9kZS5vcmcvY3NzL3VuaXRzLXZhbHVlcy9cbiAgICAgIG1heC13aWR0aDogMTBleDsgLy8gVGhlICd4JyBjaGFyYWN0ZXIgaXMgc2VtaS1zcXVhcmUgY2hhclxuICAgICAgbWF4LXdpZHRoOiAxMGNoOyAvLyBjaCBpcyB0aGUgb25seSBmb250IHVuaXQgYmFzZWQgb24gdGhlIHdpZHRoIG9mIGNoYXJhY3RlcnNcblxuICAgICAgLnVzZXItYWN0aW9uIHtcbiAgICAgICAgbWFyZ2luOiAwcHg7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iXX0= */");

/***/ }),

/***/ "HLEy":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/customers/customers.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"ion-no-border\">\n  <!-- <ion-toolbar> -->\n    <!-- <ion-buttons slot=\"start\"> -->\n      <!-- <ion-back-button defaultHref=\"app/home\"></ion-back-button> -->\n    <!-- </ion-buttons> -->\n  <!-- </ion-toolbar> -->\n</ion-header>\n\n<ion-content class=\"user-friends-content\">\n  <ion-segment value=\"activating\" class=\"user-friends-segment\" (ionChange)=\"segmentChanged($event)\">\n    <ion-segment-button value=\"activating\">\n      <ion-label>活跃</ion-label>\n    </ion-segment-button>\n    <!-- <ion-segment-button value=\"followers\">\n      <ion-label>Followers</ion-label>\n    </ion-segment-button> -->\n    <ion-segment-button value=\"ending\">\n      <ion-label>到期</ion-label>\n    </ion-segment-button>\n  </ion-segment>\n\n  <ion-searchbar class=\"friends-searchbar\" animated [(ngModel)]=\"searchQuery\" (ionChange)=\"searchList()\" placeholder=\"搜索\"></ion-searchbar>\n\n  <ng-template #customerItem let-item=\"item\">\n    <ion-row class=\"user-details-section\">\n      <ion-col class=\"picture-wrapper\" size=\"2\">\n        <!-- <app-aspect-ratio [ratio]=\"{w:1, h:1}\">\n          <app-image-shell class=\"user-image\" animation=\"spinner\" [src]=\"customer.image\" [alt]=\"'friend'\"></app-image-shell>\n        </app-aspect-ratio> -->\n        <!-- <ion-img class=\"user-image\" animation=\"spinner\" [src]=\"item?.image\" [alt]=\"'customer'\"></ion-img> -->\n        <a class=\"has-more-pictures\" [routerLink]=\"['/app/referrals/', item?.id]\">\n          <span class=\"pictures-count\">{{ item?.customerName[0] }}</span>\n        </a>\n      </ion-col>\n      <ion-col class=\"user-data-wrapper\">\n        <div class=\"user-info\">\n          <h3 class=\"user-name\">{{item?.customerName}}\n            <!-- <app-text-shell [data]=\"customer?.customerName\"></app-text-shell> -->\n            <!-- {{customer.customerName}} -->\n          </h3>\n          <h5 class=\"user-job\">\n            <!-- <app-text-shell [data]=\"customer?.phone\"></app-text-shell> -->\n            {{item?.phone}}\n          </h5>\n        </div>\n      </ion-col>\n      <ion-col class=\"user-actions-wrapper\">\n        <ion-button class=\"user-action\" expand=\"block\" size=\"small\" color=\"primary\" (click)=\"details(item?.id)\">查看详情</ion-button>\n        <!-- <ion-button *ngIf=\"friend.following\" class=\"user-action\" expand=\"block\" size=\"small\" color=\"light\">Following</ion-button> -->\n      </ion-col>\n    </ion-row>\n  </ng-template>\n\n  <section [hidden]=\"segmentValue !== 'activating'\">\n    <ion-list class=\"friends-list\" *ngIf=\"activeList?.length > 0\">\n      <ion-item class=\"friend-item\" *ngFor=\"let item of activeList\">\n        <ng-container *ngTemplateOutlet=\"customerItem; context: { item: item }\"></ng-container>\n      </ion-item>\n    </ion-list>\n    <ng-container *ngIf=\"activeList?.length <= 0\">\n      <h3 class=\"empty-list-message\">无记录</h3>\n    </ng-container>\n  </section>\n\n  <!-- <section [hidden]=\"segmentValue !== 'followers'\">\n    <ion-list class=\"friends-list\" *ngIf=\"customersList?.length > 0\">\n      <ion-item class=\"friend-item\" *ngFor=\"let item of customersList\">\n        <ng-container *ngTemplateOutlet=\"customerItem; context: { item: item }\"></ng-container>\n      </ion-item>\n    </ion-list>\n    <ng-container *ngIf=\"customersList?.length <= 0\">\n      <h3 class=\"empty-list-message\">无记录</h3>\n    </ng-container>\n  </section> -->\n\n  <section [hidden]=\"segmentValue !== 'ending'\">\n    <ion-list class=\"friends-list\" *ngIf=\"endList?.length > 0\">\n      <ion-item class=\"friend-item\" *ngFor=\"let item of endList\">\n        <ng-container *ngTemplateOutlet=\"endList; context: { item: item }\"></ng-container>\n      </ion-item>\n    </ion-list>\n    <ng-container *ngIf=\"endList?.length <= 0\">\n      <h3 class=\"empty-list-message\">无记录</h3>\n    </ng-container>\n  </section>\n\n  <!-- <PullToRefresh\n      [ngStyle]=\"dtPullToRefreshStyle\"\n      [direction]=\"'down'\"\n      [(ngModel)]=\"'down'\"\n      [endReachedRefresh]=\"true\"\n      (onRefresh)=\"pullToRefresh($event)\"\n    >\n    </PullToRefresh>\n\n    <ng-template #loading>\n      <Icon type=\"loading\"></Icon>\n    </ng-template> -->\n</ion-content>\n");

/***/ }),

/***/ "J9ab":
/*!***********************************************************!*\
  !*** ./src/app/pages/customers/styles/customers.ios.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host-context(.ios) .user-friends-segment {\n  --background: var(--page-segment-background);\n  padding: var(--page-margin);\n}\n:host-context(.ios) .user-friends-segment ion-segment-button {\n  --color-checked: var(--ion-color-light);\n}\n:host-context(.ios) ion-searchbar.friends-searchbar {\n  padding-top: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2N1c3RvbWVycy5pb3Muc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLDRDQUFBO0VBQ0EsMkJBQUE7QUFBSjtBQUVJO0VBQ0UsdUNBQUE7QUFBTjtBQUlFO0VBQ0UsZ0JBQUE7QUFGSiIsImZpbGUiOiJjdXN0b21lcnMuaW9zLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdC1jb250ZXh0KC5pb3MpIHtcbiAgLnVzZXItZnJpZW5kcy1zZWdtZW50IHtcbiAgICAtLWJhY2tncm91bmQ6IHZhcigtLXBhZ2Utc2VnbWVudC1iYWNrZ3JvdW5kKTtcbiAgICBwYWRkaW5nOiB2YXIoLS1wYWdlLW1hcmdpbik7XG5cbiAgICBpb24tc2VnbWVudC1idXR0b24ge1xuICAgICAgLS1jb2xvci1jaGVja2VkOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xuICAgIH1cbiAgfVxuXG4gIGlvbi1zZWFyY2hiYXIuZnJpZW5kcy1zZWFyY2hiYXIge1xuICAgIHBhZGRpbmctdG9wOiAwcHg7XG4gIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "SUx8":
/*!*****************************************************!*\
  !*** ./src/app/pages/customers/customers.module.ts ***!
  \*****************************************************/
/*! exports provided: CustomersPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomersPageModule", function() { return CustomersPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _customers_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./customers.page */ "VSNN");
/* harmony import */ var _app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @app/pipes/pipes.module */ "iTUp");









const routes = [
    {
        path: '',
        component: _customers_page__WEBPACK_IMPORTED_MODULE_7__["CustomersPage"],
    }
];
let CustomersPageModule = class CustomersPageModule {
};
CustomersPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__["PipesModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateModule"],
            _app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__["PipesModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_customers_page__WEBPACK_IMPORTED_MODULE_7__["CustomersPage"]],
        providers: []
    })
], CustomersPageModule);



/***/ }),

/***/ "VSNN":
/*!***************************************************!*\
  !*** ./src/app/pages/customers/customers.page.ts ***!
  \***************************************************/
/*! exports provided: CustomersPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomersPage", function() { return CustomersPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_customers_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./customers.page.html */ "HLEy");
/* harmony import */ var _styles_customers_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/customers.page.scss */ "5aaP");
/* harmony import */ var _styles_customers_shell_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./styles/customers.shell.scss */ "1WSO");
/* harmony import */ var _styles_customers_ios_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./styles/customers.ios.scss */ "J9ab");
/* harmony import */ var _styles_customers_md_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./styles/customers.md.scss */ "vaos");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _customers_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./customers.service */ "adrT");









let CustomersPage = class CustomersPage {
    constructor(route, router, customersService) {
        this.route = route;
        this.router = router;
        this.customersService = customersService;
        // Gather all component subscription in one place. Can be one Subscription or multiple (chained using the Subscription.add() method)
        // subscriptions: Subscription;
        // friendsList: Array<any> = [];
        // followersList: Array<any> = [];
        // followingList: Array<any> = [];
        this.searchQuery = '';
        this.showFilters = false;
        this.page = {
            searchCount: false,
            current: 1,
            size: 200,
            ascs: '',
            //升序字段
            descs: 'create_time'
        };
        this.parameter = {};
        this.customersList = [];
        //空值过滤器
        this.segmentValue = 'activating';
        this.state = {
            refreshState: {
                currentState: 'deactivate',
                drag: false
            },
            direction: '',
            endReachedRefresh: false,
            height: 500,
            data: [],
            directionName: 'both up and down'
        };
        this.userRole = localStorage.getItem('userRole');
        this.affiliated = localStorage.getItem('affiliated').split(',');
        const currentUser = JSON.parse(localStorage.getItem('currentUser'));
        const filterForm = (form) => {
            let obj = {};
            Object.keys(form).forEach(ele => {
                if (!this.validatenull(form[ele])) {
                    obj[ele] = form[ele];
                }
            });
            return obj;
        };
        let combination = {};
        if (!this.userRole || this.userRole == '') {
            combination = {
                brokerId: currentUser === null || currentUser === void 0 ? void 0 : currentUser.mktUserId,
            };
        }
        else if (this.userRole === 'access' || this.userRole === 'manager') {
            combination = {
                affiliationId: this.affiliated,
            };
        }
        else if (this.userRole === 'salesman') {
            combination = {
                salesmanId: currentUser === null || currentUser === void 0 ? void 0 : currentUser.mktUserId,
            };
        }
        else if (this.userRole === 'secretary') {
            return;
        }
        // if (!this.userRole || this.userRole != '') {
        this.customersService.getPageByOwn(Object.assign(combination, this.page, filterForm(this.parameter))).subscribe(res => {
            let [...customersList] = res.data.records;
            let tempArr = [], newArr = [];
            for (let i = 0; i < customersList.length; i++) {
                if (tempArr.indexOf(customersList[i].phone) === -1) {
                    // newArr.push({
                    //   id: customersList[i].id,
                    //   list: [customersList[i].list]
                    // })
                    newArr.push(customersList[i]);
                    tempArr.push(customersList[i].phone);
                }
                else {
                    // for (let j = 0; j < newArr.length; j++) {
                    //   if (newArr[j].phone == customersList[i].phone) {
                    //     newArr[j].list.push(customersList[i].list)
                    //   }
                    // }
                }
            }
            this.customersList = [...this.customersList, ...newArr];
            this.searchList();
            if (customersList.length < this.page.size) {
                // this.setData({
                //   loadmore: false
                // })
            }
        });
        // }
    }
    ngOnInit() {
    }
    segmentChanged(ev) {
        this.segmentValue = ev.detail.value;
        // Check if there's any filter and apply it
        this.searchList();
    }
    searchList() {
        const query = (this.searchQuery && this.searchQuery !== null) ? this.searchQuery : '';
        if (this.segmentValue === 'activating') {
            this.activeList = this.filterList(this.customersList, '0', query);
        }
        else if (this.segmentValue === 'ending') {
            this.endList = this.filterList(this.customersList, '1', query);
        }
    }
    filterList(list, status, query) {
        return list.filter(item => item.workflowStatus === status &&
            (item.customerName.toLowerCase().includes(query.toLowerCase()) ||
                item.phone.toLowerCase().includes(query.toLowerCase())));
    }
    // NOTE: Ionic only calls ngOnDestroy if the page was popped (ex: when navigating back)
    // Since ngOnDestroy might not fire when you navigate from the current page, use ionViewWillLeave to cleanup Subscriptions
    ionViewWillLeave() {
        // this.subscriptions.unsubscribe();
    }
    validatenull(val) {
        if (typeof val === 'boolean') {
            return false;
        }
        if (typeof val === 'number') {
            return false;
        }
        if (val instanceof Array) {
            if (val.length == 0)
                return true;
        }
        else if (val instanceof Object) {
            if (JSON.stringify(val) === '{}')
                return true;
        }
        else {
            if (val == 'null' || val == null || val == 'undefined' || val == undefined || val == '')
                return true;
            return false;
        }
        return false;
    }
    // pullToRefresh(event) {
    //   if (event === 'endReachedRefresh') {
    //     if (this.page < 9) {
    //       this.page++;
    //       this.addItems(this.page * this.pageLimit);
    //       this.state.refreshState.currentState = 'release';
    //       setTimeout(() => {
    //         this.state.refreshState.currentState = 'finish';
    //       }, 1000);
    //     }
    //   }
    // }
    details(id) {
        this.router.navigate(['/app/referrals/', id]);
    }
};
CustomersPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] },
    { type: _customers_service__WEBPACK_IMPORTED_MODULE_8__["CustomersService"] }
];
CustomersPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Component"])({
        selector: 'app-user-friends',
        template: _raw_loader_customers_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_styles_customers_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"], _styles_customers_shell_scss__WEBPACK_IMPORTED_MODULE_3__["default"], _styles_customers_ios_scss__WEBPACK_IMPORTED_MODULE_4__["default"], _styles_customers_md_scss__WEBPACK_IMPORTED_MODULE_5__["default"]]
    })
], CustomersPage);



/***/ }),

/***/ "Wgwc":
/*!*****************************************!*\
  !*** ./node_modules/dayjs/dayjs.min.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

!function(t,e){ true?module.exports=e():undefined}(this,(function(){"use strict";var t=1e3,e=6e4,n=36e5,r="millisecond",i="second",s="minute",u="hour",a="day",o="week",f="month",h="quarter",c="year",d="date",$="Invalid Date",l=/^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[^0-9]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/,y=/\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g,M={name:"en",weekdays:"Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),months:"January_February_March_April_May_June_July_August_September_October_November_December".split("_")},m=function(t,e,n){var r=String(t);return!r||r.length>=e?t:""+Array(e+1-r.length).join(n)+t},g={s:m,z:function(t){var e=-t.utcOffset(),n=Math.abs(e),r=Math.floor(n/60),i=n%60;return(e<=0?"+":"-")+m(r,2,"0")+":"+m(i,2,"0")},m:function t(e,n){if(e.date()<n.date())return-t(n,e);var r=12*(n.year()-e.year())+(n.month()-e.month()),i=e.clone().add(r,f),s=n-i<0,u=e.clone().add(r+(s?-1:1),f);return+(-(r+(n-i)/(s?i-u:u-i))||0)},a:function(t){return t<0?Math.ceil(t)||0:Math.floor(t)},p:function(t){return{M:f,y:c,w:o,d:a,D:d,h:u,m:s,s:i,ms:r,Q:h}[t]||String(t||"").toLowerCase().replace(/s$/,"")},u:function(t){return void 0===t}},D="en",v={};v[D]=M;var p=function(t){return t instanceof _},S=function(t,e,n){var r;if(!t)return D;if("string"==typeof t)v[t]&&(r=t),e&&(v[t]=e,r=t);else{var i=t.name;v[i]=t,r=i}return!n&&r&&(D=r),r||!n&&D},w=function(t,e){if(p(t))return t.clone();var n="object"==typeof e?e:{};return n.date=t,n.args=arguments,new _(n)},O=g;O.l=S,O.i=p,O.w=function(t,e){return w(t,{locale:e.$L,utc:e.$u,x:e.$x,$offset:e.$offset})};var _=function(){function M(t){this.$L=S(t.locale,null,!0),this.parse(t)}var m=M.prototype;return m.parse=function(t){this.$d=function(t){var e=t.date,n=t.utc;if(null===e)return new Date(NaN);if(O.u(e))return new Date;if(e instanceof Date)return new Date(e);if("string"==typeof e&&!/Z$/i.test(e)){var r=e.match(l);if(r){var i=r[2]-1||0,s=(r[7]||"0").substring(0,3);return n?new Date(Date.UTC(r[1],i,r[3]||1,r[4]||0,r[5]||0,r[6]||0,s)):new Date(r[1],i,r[3]||1,r[4]||0,r[5]||0,r[6]||0,s)}}return new Date(e)}(t),this.$x=t.x||{},this.init()},m.init=function(){var t=this.$d;this.$y=t.getFullYear(),this.$M=t.getMonth(),this.$D=t.getDate(),this.$W=t.getDay(),this.$H=t.getHours(),this.$m=t.getMinutes(),this.$s=t.getSeconds(),this.$ms=t.getMilliseconds()},m.$utils=function(){return O},m.isValid=function(){return!(this.$d.toString()===$)},m.isSame=function(t,e){var n=w(t);return this.startOf(e)<=n&&n<=this.endOf(e)},m.isAfter=function(t,e){return w(t)<this.startOf(e)},m.isBefore=function(t,e){return this.endOf(e)<w(t)},m.$g=function(t,e,n){return O.u(t)?this[e]:this.set(n,t)},m.unix=function(){return Math.floor(this.valueOf()/1e3)},m.valueOf=function(){return this.$d.getTime()},m.startOf=function(t,e){var n=this,r=!!O.u(e)||e,h=O.p(t),$=function(t,e){var i=O.w(n.$u?Date.UTC(n.$y,e,t):new Date(n.$y,e,t),n);return r?i:i.endOf(a)},l=function(t,e){return O.w(n.toDate()[t].apply(n.toDate("s"),(r?[0,0,0,0]:[23,59,59,999]).slice(e)),n)},y=this.$W,M=this.$M,m=this.$D,g="set"+(this.$u?"UTC":"");switch(h){case c:return r?$(1,0):$(31,11);case f:return r?$(1,M):$(0,M+1);case o:var D=this.$locale().weekStart||0,v=(y<D?y+7:y)-D;return $(r?m-v:m+(6-v),M);case a:case d:return l(g+"Hours",0);case u:return l(g+"Minutes",1);case s:return l(g+"Seconds",2);case i:return l(g+"Milliseconds",3);default:return this.clone()}},m.endOf=function(t){return this.startOf(t,!1)},m.$set=function(t,e){var n,o=O.p(t),h="set"+(this.$u?"UTC":""),$=(n={},n[a]=h+"Date",n[d]=h+"Date",n[f]=h+"Month",n[c]=h+"FullYear",n[u]=h+"Hours",n[s]=h+"Minutes",n[i]=h+"Seconds",n[r]=h+"Milliseconds",n)[o],l=o===a?this.$D+(e-this.$W):e;if(o===f||o===c){var y=this.clone().set(d,1);y.$d[$](l),y.init(),this.$d=y.set(d,Math.min(this.$D,y.daysInMonth())).$d}else $&&this.$d[$](l);return this.init(),this},m.set=function(t,e){return this.clone().$set(t,e)},m.get=function(t){return this[O.p(t)]()},m.add=function(r,h){var d,$=this;r=Number(r);var l=O.p(h),y=function(t){var e=w($);return O.w(e.date(e.date()+Math.round(t*r)),$)};if(l===f)return this.set(f,this.$M+r);if(l===c)return this.set(c,this.$y+r);if(l===a)return y(1);if(l===o)return y(7);var M=(d={},d[s]=e,d[u]=n,d[i]=t,d)[l]||1,m=this.$d.getTime()+r*M;return O.w(m,this)},m.subtract=function(t,e){return this.add(-1*t,e)},m.format=function(t){var e=this;if(!this.isValid())return $;var n=t||"YYYY-MM-DDTHH:mm:ssZ",r=O.z(this),i=this.$locale(),s=this.$H,u=this.$m,a=this.$M,o=i.weekdays,f=i.months,h=function(t,r,i,s){return t&&(t[r]||t(e,n))||i[r].substr(0,s)},c=function(t){return O.s(s%12||12,t,"0")},d=i.meridiem||function(t,e,n){var r=t<12?"AM":"PM";return n?r.toLowerCase():r},l={YY:String(this.$y).slice(-2),YYYY:this.$y,M:a+1,MM:O.s(a+1,2,"0"),MMM:h(i.monthsShort,a,f,3),MMMM:h(f,a),D:this.$D,DD:O.s(this.$D,2,"0"),d:String(this.$W),dd:h(i.weekdaysMin,this.$W,o,2),ddd:h(i.weekdaysShort,this.$W,o,3),dddd:o[this.$W],H:String(s),HH:O.s(s,2,"0"),h:c(1),hh:c(2),a:d(s,u,!0),A:d(s,u,!1),m:String(u),mm:O.s(u,2,"0"),s:String(this.$s),ss:O.s(this.$s,2,"0"),SSS:O.s(this.$ms,3,"0"),Z:r};return n.replace(y,(function(t,e){return e||l[t]||r.replace(":","")}))},m.utcOffset=function(){return 15*-Math.round(this.$d.getTimezoneOffset()/15)},m.diff=function(r,d,$){var l,y=O.p(d),M=w(r),m=(M.utcOffset()-this.utcOffset())*e,g=this-M,D=O.m(this,M);return D=(l={},l[c]=D/12,l[f]=D,l[h]=D/3,l[o]=(g-m)/6048e5,l[a]=(g-m)/864e5,l[u]=g/n,l[s]=g/e,l[i]=g/t,l)[y]||g,$?D:O.a(D)},m.daysInMonth=function(){return this.endOf(f).$D},m.$locale=function(){return v[this.$L]},m.locale=function(t,e){if(!t)return this.$L;var n=this.clone(),r=S(t,e,!0);return r&&(n.$L=r),n},m.clone=function(){return O.w(this.$d,this)},m.toDate=function(){return new Date(this.valueOf())},m.toJSON=function(){return this.isValid()?this.toISOString():null},m.toISOString=function(){return this.$d.toISOString()},m.toString=function(){return this.$d.toUTCString()},M}(),b=_.prototype;return w.prototype=b,[["$ms",r],["$s",i],["$m",s],["$H",u],["$W",a],["$M",f],["$y",c],["$D",d]].forEach((function(t){b[t[1]]=function(e){return this.$g(e,t[0],t[1])}})),w.extend=function(t,e){return t.$i||(t(e,_,w),t.$i=!0),w},w.locale=S,w.isDayjs=p,w.unix=function(t){return w(1e3*t)},w.en=v[D],w.Ls=v,w.p={},w}));

/***/ }),

/***/ "vaos":
/*!**********************************************************!*\
  !*** ./src/app/pages/customers/styles/customers.md.scss ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host-context(.md) .user-details-section .user-actions-wrapper {\n  max-width: 12ex;\n  max-width: 12ch;\n}\n:host-context(.md) .user-friends-segment ion-segment-button {\n  --color-checked: var(--ion-color-dark);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2N1c3RvbWVycy5tZC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVJO0VBQ0UsZUFBQTtFQUNBLGVBQUE7QUFETjtBQUtJO0VBQ0Usc0NBQUE7QUFITiIsImZpbGUiOiJjdXN0b21lcnMubWQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0LWNvbnRleHQoLm1kKSB7XG4gIC51c2VyLWRldGFpbHMtc2VjdGlvbiB7XG4gICAgLnVzZXItYWN0aW9ucy13cmFwcGVyIHtcbiAgICAgIG1heC13aWR0aDogMTJleDtcbiAgICAgIG1heC13aWR0aDogMTJjaDtcbiAgICB9XG4gIH1cbiAgLnVzZXItZnJpZW5kcy1zZWdtZW50IHtcbiAgICBpb24tc2VnbWVudC1idXR0b24ge1xuICAgICAgLS1jb2xvci1jaGVja2VkOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XG4gICAgfVxuICB9XG59XG4iXX0= */");

/***/ })

}]);
//# sourceMappingURL=customers-customers-module.js.map