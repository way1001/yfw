(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-complemented-complemented-module"],{

/***/ "RsMY":
/*!*********************************************************!*\
  !*** ./src/app/pages/complemented/complemented.page.ts ***!
  \*********************************************************/
/*! exports provided: ComplementedPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComplementedPage", function() { return ComplementedPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_complemented_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./complemented.page.html */ "YtG4");
/* harmony import */ var _styles_complemented_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/complemented.page.scss */ "mRq7");
/* harmony import */ var _styles_complemented_shell_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./styles/complemented.shell.scss */ "Vyzo");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _transact_transact_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../transact/transact.service */ "g/Tr");









let ComplementedPage = class ComplementedPage {
    constructor(route, router, transactService, alertController) {
        this.router = router;
        this.transactService = transactService;
        this.alertController = alertController;
        this.verifyFirst = '';
        this.verifyTwo = '';
        this.inputVerify = false;
        this.instanceId = route.snapshot.params['instanceId'];
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.transactService.getCurrentTransact(this.instanceId, this.currentUser.mktUserId).subscribe(res => {
            if (res.length >= 0 && res[0] != null) {
                this.currentTaskId = res[0].id;
                this.transactService.getCurrentReferrals(this.instanceId).subscribe(data => {
                    //
                    if (data.data != null) {
                        this.currentReferral = data.data;
                    }
                });
            }
            else {
                this.presentAlertConfirm('无效办理!', '您当前办理的流程已经办理或已完结!!!');
            }
        });
    }
    ngOnInit() {
        setTimeout(() => {
            this.firstInput.setFocus(); //为输入框设置焦点
            // Keyboard.show()
        }, 50);
    }
    ionViewDidEnter() {
        setTimeout(() => {
            this.firstInput.setFocus(); //为输入框设置焦点
            // Keyboard.show()
        }, 50);
        // const element = this.renderer2.selectRootElement('#firstNum');
        // setTimeout(() => element.focus(), 150);
    }
    presentAlertConfirm(header, message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: header,
                message: message,
                backdropDismiss: false,
                buttons: [
                    {
                        text: '关闭页面',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: () => {
                            // console.log('Confirm Cancel: blah');
                            WeixinJSBridge.call('closeWindow');
                        }
                    }, {
                        text: '返回首页',
                        handler: () => {
                            // console.log('Confirm Okay');
                            this.router.navigate(['/app/mine']);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    onKeyUpEvent(e, num) {
        if (e.key === 'Backspace' && e.keyCode === 8) {
            switch (num) {
                case 2:
                    setTimeout(() => {
                        this.firstInput.setFocus(); //为输入框设置焦点
                        // Keyboard.show()
                    }, 20);
                    break;
                case 3:
                    setTimeout(() => {
                        this.secondInput.setFocus(); //为输入框设置焦点
                    }, 20);
                    break;
                case 1:
                default:
                    break;
            }
        }
    }
    inputEvent(e, num) {
        switch (num) {
            case 1:
                this.verifyFirst = e.target.value;
                if (e.target.value !== '') {
                    setTimeout(() => {
                        this.secondInput.setFocus(); //为输入框设置焦点
                        // Keyboard.show()
                    }, 20);
                }
                break;
            case 2:
                if (e.target.value === '' && this.verifyTwo === '') {
                    setTimeout(() => {
                        this.firstInput.setFocus(); //为输入框设置焦点
                        this.verifyFirst = e.target.value;
                        // Keyboard.show()
                    }, 20);
                }
                else if (e.target.value !== '') {
                    this.verifyTwo = e.target.value;
                    const verifyCode = this.verifyFirst + this.verifyTwo;
                    if (verifyCode.length === 2) {
                        this.inputVerify = true;
                        this.verifyCode = verifyCode;
                    }
                }
                break;
            default:
                return null;
        }
    }
    onSubmit(action) {
        //
        if (this.currentTaskId == null)
            return;
        const agentId = this.verifyCode;
        if (this.verifyCode.length != 2)
            return;
        const params = {
            withVariablesInReturn: true,
            variables: {
                isCompletion: { value: action },
                verifyCode: { value: this.verifyCode }
            },
        };
        this.transactService.completeTask(this.currentTaskId, params).subscribe(res => {
            //
            this.presentAlertConfirm('成功办理', '您当前办理流程已经提交完成！');
        });
    }
};
ComplementedPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _transact_transact_service__WEBPACK_IMPORTED_MODULE_7__["TransactService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] }
];
ComplementedPage.propDecorators = {
    firstInput: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewChild"], args: ['firstNum',] }],
    secondInput: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewChild"], args: ['secondNum',] }]
};
ComplementedPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-contact-card',
        template: _raw_loader_complemented_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_styles_complemented_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"], _styles_complemented_shell_scss__WEBPACK_IMPORTED_MODULE_3__["default"]]
    })
], ComplementedPage);



/***/ }),

/***/ "Vyzo":
/*!*******************************************************************!*\
  !*** ./src/app/pages/complemented/styles/complemented.shell.scss ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("app-image-shell.user-avatar {\n  --image-shell-loading-background: rgba(var(--ion-color-light-rgb), 0.25);\n  --image-shell-border-radius: 50%;\n  --image-shell-spinner-color: var(--ion-color-light);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2NvbXBsZW1lbnRlZC5zaGVsbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usd0VBQUE7RUFDQSxnQ0FBQTtFQUNBLG1EQUFBO0FBQ0YiLCJmaWxlIjoiY29tcGxlbWVudGVkLnNoZWxsLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJhcHAtaW1hZ2Utc2hlbGwudXNlci1hdmF0YXIge1xuICAtLWltYWdlLXNoZWxsLWxvYWRpbmctYmFja2dyb3VuZDogcmdiYSh2YXIoLS1pb24tY29sb3ItbGlnaHQtcmdiKSwgMC4yNSk7XG4gIC0taW1hZ2Utc2hlbGwtYm9yZGVyLXJhZGl1czogNTAlO1xuICAtLWltYWdlLXNoZWxsLXNwaW5uZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodCk7XG59XG4iXX0= */");

/***/ }),

/***/ "YtG4":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/complemented/complemented.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- <ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header> -->\n\n<ion-content class=\"transact-details-content\">\n  <ion-row class=\"user-preferences-wrapper\">\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">客户：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.customerName}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">电话：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.phone}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">咨询楼盘：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.basicInfo?.projectName}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">客户意向：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.description}}\n      </p>\n    </ion-col>\n  </ion-row>\n\n  <ion-item-divider>\n    <ion-label>补全号码</ion-label>\n  </ion-item-divider>\n\n  <ion-row>\n    <ion-col>\n      <ion-item class=\"input-item\">\n        <ion-input #firstNum maxlength=\"1\" type=\"text\" inputmode=\"tel\" (value)=\"verifyFirst\" (ionInput)=\"inputEvent($event, 1)\" (keyup)=\"onKeyUpEvent($event, 1)\"></ion-input>\n      </ion-item>\n    </ion-col>\n    <ion-col>\n      <ion-item class=\"input-item\">\n        <ion-input #secondNum maxlength=\"1\" type=\"text\" inputmode=\"tel\" (value)=\"verifyTwo\" (ionInput)=\"inputEvent($event, 2)\" (keyup)=\"onKeyUpEvent($event, 2)\" [disabled]=\"verifyFirst===''\"></ion-input>\n      </ion-item>\n    </ion-col>\n    <ion-col>\n      <ion-item class=\"input-item\">\n        <ion-input maxlength=\"1\" type=\"text\" inputmode=\"tel\" disabled=\"true\" placeholder=\"*\"></ion-input>\n      </ion-item>\n    </ion-col>\n    <ion-col>\n      <ion-item class=\"input-item\">\n        <ion-input maxlength=\"1\" type=\"text\" inputmode=\"tel\" disabled=\"true\" placeholder=\"*\"></ion-input>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n\n    <ion-button class=\"submit-btn\" type=\"submit\" expand=\"block\" fill=\"outline\" [disabled]=\"!inputVerify\" (click)=\"onSubmit(true)\">提交</ion-button>\n    \n    <ion-button class=\"submit-btn\" size=\"small\" expand=\"block\" color=\"medium\" (click)=\"onSubmit(false)\">结束推荐</ion-button>\n\n\n\n\n</ion-content>\n");

/***/ }),

/***/ "g/Tr":
/*!****************************************************!*\
  !*** ./src/app/pages/transact/transact.service.ts ***!
  \****************************************************/
/*! exports provided: TransactService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TransactService", function() { return TransactService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "tk/3");



let TransactService = class TransactService {
    constructor(http) {
        this.http = http;
    }
    // public getDetailsDataSource(slug: string): Observable<any> {
    //   const rawDataSource = this.http.get<any>('./assets/sample-data/food/details.json')
    //   .pipe(
    //     mergeMap(details => details.items.filter(item => item.slug === slug)),
    //     map(
    //       (data: FoodDetailsModel) => {
    //         // Note: HttpClient cannot know how to instantiate a class for the returned data
    //         // We need to properly cast types from json data
    //         const details = new FoodDetailsModel();
    //         // The Object.assign() method copies all enumerable own properties from one or more source objects to a target object.
    //         // Note: If you have non-enummerable properties, you can try a spread operator instead. details = {...data};
    //         // (see: https://scotch.io/bar-talk/copying-objects-in-javascript#toc-using-spread-elements-)
    //         Object.assign(details, data);
    //         return details;
    //       }
    //     )
    //   );
    //   // This method tapps into the raw data source and stores the resolved data in the TransferState, then when
    //   // transitioning from the server rendered view to the browser, checks if we already loaded the data in the server to prevent
    //   // duplicate http requests.
    //   const cachedDataSource = this.transferStateHelper.checkDataSourceState('food-details-state', rawDataSource);
    //   return cachedDataSource;
    // }
    // public getDetailsStore(dataSource: Observable<FoodDetailsModel>): DataStore<FoodDetailsModel> {
    //   // Initialize the model specifying that it is a shell model
    //   const shellModel: FoodDetailsModel = new FoodDetailsModel();
    //   this.detailsDataStore = new DataStore(shellModel);
    //   // If running in the server, then don't add shell to the Data Store
    //   // If we already loaded the Data Source in the server, then don't show a shell when transitioning back to the broswer from the server
    //   if (isPlatformServer(this.platformId) || dataSource['ssr_state']) {
    //     // Trigger loading mechanism with 0 delay (this will prevent the shell to be shown)
    //     this.detailsDataStore.load(dataSource, 0);
    //   } else { // On browser transitions
    //     // Trigger the loading mechanism (with shell)
    //     this.detailsDataStore.load(dataSource);
    //   }
    //   return this.detailsDataStore;
    // }
    getCurrentTransact(slug, userId) {
        return this.http.post('/mkt/engine-rest/task', { processInstanceId: slug, assignee: userId })
            .pipe();
    }
    getTransactList(userId) {
        return this.http.post('/mkt/engine-rest/task', { "assignee": userId, "sorting": [{ "sortBy": "dueDate",
                    "sortOrder": "asc"
                }] })
            .pipe();
    }
    getCurrentReferrals(slug) {
        return this.http.get(`/mkt/api/mp/referrals/instance/${slug}`)
            .pipe();
    }
    getTaskCount(userId) {
        return this.http.get('/mkt/engine-rest/task/count', { params: { assignee: userId } })
            .pipe();
    }
    completeTask(taskId, params) {
        return this.http.post(`/mkt/engine-rest/task/${taskId}/complete`, params)
            .pipe();
    }
};
TransactService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
TransactService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], TransactService);



/***/ }),

/***/ "mRq7":
/*!******************************************************************!*\
  !*** ./src/app/pages/complemented/styles/complemented.page.scss ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host {\n  --page-background: var(--app-background-shade);\n  --page-highlighted-background: #00AFFF;\n  --page-margin: var(--app-fair-margin);\n  --page-tags-gutter: 5px;\n}\n\nion-header ion-toolbar {\n  --background: transparent;\n}\n\nion-content {\n  position: absolute;\n  top: 0;\n  border-top-style: solid;\n  border-top-color: var(--page-highlighted-background);\n}\n\n.transact-details-content {\n  --background: var(--page-background);\n  transform: translateZ(0);\n  --padding-start: var(--page-margin);\n  --padding-end: var(--page-margin);\n  --padding-top: var(--page-margin);\n  --padding-bottom: var(--page-margin);\n  --ion-item-background: var(--page-background);\n}\n\n.transact-details-content ion-item-divider {\n  --background: var(--page-background);\n  --padding-bottom: calc(var(--page-margin) / 2);\n  --padding-top: calc(var(--page-margin) / 2);\n  --padding-start: var(--page-margin);\n  --padding-end: var(--page-margin);\n  border: none;\n}\n\n.transact-details-content .user-details-wrapper {\n  --ion-grid-column-padding: 0px;\n  padding: 0px var(--page-margin) var(--page-margin);\n  background-color: var(--page-highlighted-background);\n  color: var(--ion-color-light);\n  align-items: center;\n}\n\n.transact-details-content .user-details-wrapper .user-avatar {\n  border: solid 3px var(--ion-color-light);\n}\n\n.transact-details-content .user-details-wrapper .user-info-wrapper {\n  padding-left: calc(var(--page-margin) / 2);\n}\n\n.transact-details-content .user-details-wrapper .user-info-wrapper .user-name {\n  margin: 0px 0px 5px;\n}\n\n.transact-details-content .user-details-wrapper .user-info-wrapper .user-handle {\n  margin: 0px;\n  font-weight: 400;\n}\n\n.transact-details-content .user-details-wrapper .user-stats-wrapper {\n  text-align: center;\n  padding-top: calc(var(--page-margin) / 2);\n}\n\n.transact-details-content .user-details-wrapper .user-stats-wrapper .user-stat-value {\n  margin-right: 5px;\n  font-weight: 500;\n  font-size: 18px;\n}\n\n.transact-details-content .user-details-wrapper .user-stats-wrapper .user-stat-name {\n  font-size: 16px;\n}\n\n.transact-details-content .user-details-wrapper .user-bio {\n  margin: var(--page-margin) 0px 0px;\n  line-height: 1.2;\n  font-size: 14px;\n}\n\n.transact-details-content .user-preferences-wrapper {\n  --ion-grid-column-padding: 0px;\n  padding: var(--page-margin);\n}\n\n.transact-details-content .user-preferences-wrapper .preference-name {\n  margin: 0px 0px 5px;\n  font-size: 16px;\n}\n\n.transact-details-content .user-preferences-wrapper .preference-value {\n  margin: 0px 0px calc(var(--page-margin) / 2);\n  font-size: 14px;\n  line-height: 1.4;\n  color: var(--ion-color-dark-tint);\n}\n\n.transact-details-content .radio-tags {\n  padding: 0px calc(var(--page-margin) - var(--page-tags-gutter));\n  background-color: var(--page-background);\n  justify-content: space-between;\n  --radio-tag-color: #000;\n  --radio-tag-background: #FFF;\n  --radio-tag-active-color: #FFF;\n  --radio-tag-active-background: #000;\n}\n\n.transact-details-content .radio-tags .radio-tag {\n  --padding-start: 0px;\n  --inner-padding-end: 8px;\n  --inner-padding-start: 8px;\n  --min-height: 18px;\n  --border-radius: 8px;\n  --border-width: 1px;\n  --border-style: solid;\n  --border-color: var(--radio-tag-color);\n  --ion-item-background: var(--radio-tag-background);\n  --ion-item-color: var(--radio-tag-color);\n  flex: 1;\n}\n\n.transact-details-content .radio-tags .radio-tag.item-radio-checked {\n  --ion-item-background: var(--radio-tag-active-background);\n  --ion-item-color: var(--radio-tag-active-color);\n}\n\n.transact-details-content .radio-tags .radio-tag.item-interactive-disabled {\n  opacity: 0.5;\n}\n\n.transact-details-content .radio-tags .radio-tag.item-interactive-disabled .tag-label {\n  opacity: 1;\n}\n\n.transact-details-content .radio-tags .radio-tag .tag-label {\n  margin: 5px;\n  font-size: 12px;\n  font-weight: 500;\n  letter-spacing: 0.2px;\n  text-align: center;\n}\n\n.transact-details-content .radio-tags .radio-tag ion-radio {\n  margin: 0px;\n  width: 0px;\n  --border-width: 0px;\n  height: 0px;\n  --color-checked: transparent;\n}\n\n.transact-details-content .radio-tags .radio-tag {\n  --radio-tag-color: var(--ion-color-secondary);\n  --radio-tag-background: var(--ion-color-lightest);\n  --radio-tag-active-color: var(--ion-color-lightest);\n  --radio-tag-active-background: var(--ion-color-secondary);\n  padding: 0px var(--page-tags-gutter);\n  margin: var(--page-tags-gutter) 0px;\n}\n\n.transact-details-content .submit-btn,\n.transact-details-content .tip-label {\n  margin: calc(var(--page-margin) * 2);\n}\n\n.transact-details-content .input-item {\n  --padding-start: 0px;\n  --padding-end: 0px;\n  --inner-padding-end: 0px;\n}\n\n.transact-details-content .input-item ion-input {\n  --padding-start: 0px;\n  --padding-end: 0px;\n  font-size: 30px;\n  text-align: center;\n}\n\n:host-context(.ios) .radio-tags,\n:host-context(.ios) .checkbox-tags {\n  margin-bottom: calc(var(--page-margin) * 2);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2NvbXBsZW1lbnRlZC5wYWdlLnNjc3MiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi90aGVtZS9taXhpbnMvaW5wdXRzL3JhZGlvLXRhZy5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdBO0VBRUUsOENBQUE7RUFFQSxzQ0FBQTtFQUdBLHFDQUFBO0VBRUEsdUJBQUE7QUFQRjs7QUFjRTtFQUNFLHlCQUFBO0FBWEo7O0FBY0E7RUFDRSxrQkFBQTtFQUNBLE1BQUE7RUFFQSx1QkFBQTtFQUNBLG9EQUFBO0FBWkY7O0FBZUE7RUFDRSxvQ0FBQTtFQUVBLHdCQUFBO0VBRUEsbUNBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esb0NBQUE7RUFDQSw2Q0FBQTtBQWRGOztBQWlCRTtFQUNBLG9DQUFBO0VBQ0EsOENBQUE7RUFDQSwyQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsaUNBQUE7RUFFQSxZQUFBO0FBaEJGOztBQW1CRTtFQUNFLDhCQUFBO0VBRUEsa0RBQUE7RUFDQSxvREFBQTtFQUNBLDZCQUFBO0VBQ0EsbUJBQUE7QUFsQko7O0FBb0JJO0VBQ0Usd0NBQUE7QUFsQk47O0FBcUJJO0VBQ0UsMENBQUE7QUFuQk47O0FBcUJNO0VBQ0UsbUJBQUE7QUFuQlI7O0FBc0JNO0VBQ0UsV0FBQTtFQUNBLGdCQUFBO0FBcEJSOztBQXdCSTtFQUNFLGtCQUFBO0VBQ0EseUNBQUE7QUF0Qk47O0FBd0JNO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUF0QlI7O0FBeUJNO0VBQ0UsZUFBQTtBQXZCUjs7QUEyQkk7RUFDRSxrQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQXpCTjs7QUE2QkU7RUFDRSw4QkFBQTtFQUVBLDJCQUFBO0FBNUJKOztBQThCSTtFQUNFLG1CQUFBO0VBQ0EsZUFBQTtBQTVCTjs7QUErQkk7RUFDRSw0Q0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGlDQUFBO0FBN0JOOztBQWlDRTtFQUNFLCtEQUFBO0VBQ0Ysd0NBQUE7RUFDRSw4QkFBQTtFQ3ZIRix1QkFBQTtFQUNBLDRCQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQ0FBQTtBRHlGRjs7QUN2RkM7RUFFRyxvQkFBQTtFQUNBLHdCQUFBO0VBQ0YsMEJBQUE7RUFDRSxrQkFBQTtFQUVGLG9CQUFBO0VBQ0UsbUJBQUE7RUFDRixxQkFBQTtFQUNBLHNDQUFBO0VBQ0Esa0RBQUE7RUFDQSx3Q0FBQTtFQUVFLE9BQUE7QURzRko7O0FDcEZFO0VBQ0kseURBQUE7RUFDQSwrQ0FBQTtBRHNGTjs7QUNuRkk7RUFDRSxZQUFBO0FEcUZOOztBQ25GTTtFQUVFLFVBQUE7QURvRlI7O0FDaEZJO0VBQ0QsV0FBQTtFQUNHLGVBQUE7RUFDQSxnQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QURrRk47O0FDL0VFO0VBQ0MsV0FBQTtFQUVBLFVBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7RUFFQSw0QkFBQTtBRCtFSDs7QUFMSTtFQUNFLDZDQUFBO0VBQ0EsaURBQUE7RUFDQSxtREFBQTtFQUNBLHlEQUFBO0VBRUEsb0NBQUE7RUFDQSxtQ0FBQTtBQU1OOztBQUZFOztFQUVFLG9DQUFBO0FBSUo7O0FBQUU7RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0Esd0JBQUE7QUFFSjs7QUFBSTtFQUNFLG9CQUFBO0VBQ0Esa0JBQUE7RUFJQSxlQUFBO0VBQ0Esa0JBQUE7QUFETjs7QUFPRTs7RUFFRSwyQ0FBQTtBQUpKIiwiZmlsZSI6ImNvbXBsZW1lbnRlZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAaW1wb3J0IFwiLi4vLi4vLi4vLi4vdGhlbWUvbWl4aW5zL2lucHV0cy9yYWRpby10YWdcIjtcbi8vIEN1c3RvbSB2YXJpYWJsZXNcbi8vIE5vdGU6ICBUaGVzZSBvbmVzIHdlcmUgYWRkZWQgYnkgdXMgYW5kIGhhdmUgbm90aGluZyB0byBkbyB3aXRoIElvbmljIENTUyBDdXN0b20gUHJvcGVydGllc1xuOmhvc3Qge1xuICAvLyAtLXBhZ2UtbWFyZ2luOiB2YXIoLS1hcHAtYnJvYWQtbWFyZ2luKTtcbiAgLS1wYWdlLWJhY2tncm91bmQ6IHZhcigtLWFwcC1iYWNrZ3JvdW5kLXNoYWRlKTtcblxuICAtLXBhZ2UtaGlnaGxpZ2h0ZWQtYmFja2dyb3VuZDogIzAwQUZGRjtcblxuXG4gIC0tcGFnZS1tYXJnaW46IHZhcigtLWFwcC1mYWlyLW1hcmdpbik7XG5cbiAgLS1wYWdlLXRhZ3MtZ3V0dGVyOiA1cHg7XG59XG5cbi8vIE5vdGU6ICBBbGwgdGhlIENTUyB2YXJpYWJsZXMgZGVmaW5lZCBiZWxvdyBhcmUgb3ZlcnJpZGVzIG9mIElvbmljIGVsZW1lbnRzIENTUyBDdXN0b20gUHJvcGVydGllc1xuXG4vLyBVc2UgYSBjb2xvcmVkIGJvcmRlci10b3AgdG8gZml4IHdlaXJkIHRyYW5zaXRpb25zIGJldHdlZW4gdG9vbGJhcnMgdGhhdCBoYXZlIGRpZmZlcmVudCBiYWNrZ3JvdW5kIGNvbG9yc1xuaW9uLWhlYWRlciB7XG4gIGlvbi10b29sYmFyIHtcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICB9XG59XG5pb24tY29udGVudCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAwO1xuICAvLyBib3JkZXItdG9wOiBjYWxjKHZhcigtLWFwcC1oZWFkZXItaGVpZ2h0KSArIHZhcigtLWlvbi1zYWZlLWFyZWEtdG9wKSk7XG4gIGJvcmRlci10b3Atc3R5bGU6IHNvbGlkO1xuICBib3JkZXItdG9wLWNvbG9yOiB2YXIoLS1wYWdlLWhpZ2hsaWdodGVkLWJhY2tncm91bmQpO1xufVxuXG4udHJhbnNhY3QtZGV0YWlscy1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1wYWdlLWJhY2tncm91bmQpO1xuICAvLyBUbyBmaXggaGFsZiBwaXhlbCBsaW5lIGJldHdlZW4gaW9uLWhlYWRlciBhbmQgIGlvbi1jb250ZW50XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWigwKTtcblxuICAtLXBhZGRpbmctc3RhcnQ6IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgLS1wYWRkaW5nLWVuZDogdmFyKC0tcGFnZS1tYXJnaW4pO1xuICAtLXBhZGRpbmctdG9wOiB2YXIoLS1wYWdlLW1hcmdpbik7XG4gIC0tcGFkZGluZy1ib3R0b206IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgLS1pb24taXRlbS1iYWNrZ3JvdW5kOiB2YXIoLS1wYWdlLWJhY2tncm91bmQpO1xuXG5cbiAgaW9uLWl0ZW0tZGl2aWRlciB7XG5cdFx0LS1iYWNrZ3JvdW5kOiB2YXIoLS1wYWdlLWJhY2tncm91bmQpO1xuXHRcdC0tcGFkZGluZy1ib3R0b206IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMik7XG5cdFx0LS1wYWRkaW5nLXRvcDogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcblx0XHQtLXBhZGRpbmctc3RhcnQ6IHZhcigtLXBhZ2UtbWFyZ2luKTtcblx0XHQtLXBhZGRpbmctZW5kOiB2YXIoLS1wYWdlLW1hcmdpbik7XG5cblx0XHRib3JkZXI6IG5vbmU7XG5cdH1cblxuICAudXNlci1kZXRhaWxzLXdyYXBwZXIge1xuICAgIC0taW9uLWdyaWQtY29sdW1uLXBhZGRpbmc6IDBweDtcblxuICAgIHBhZGRpbmc6IDBweCB2YXIoLS1wYWdlLW1hcmdpbikgdmFyKC0tcGFnZS1tYXJnaW4pO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLXBhZ2UtaGlnaGxpZ2h0ZWQtYmFja2dyb3VuZCk7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodCk7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgIC51c2VyLWF2YXRhciB7XG4gICAgICBib3JkZXI6IHNvbGlkIDNweCB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xuICAgIH1cblxuICAgIC51c2VyLWluZm8td3JhcHBlciB7XG4gICAgICBwYWRkaW5nLWxlZnQ6IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMik7XG5cbiAgICAgIC51c2VyLW5hbWUge1xuICAgICAgICBtYXJnaW46IDBweCAwcHggNXB4O1xuICAgICAgfVxuXG4gICAgICAudXNlci1oYW5kbGUge1xuICAgICAgICBtYXJnaW46IDBweDtcbiAgICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAudXNlci1zdGF0cy13cmFwcGVyIHtcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgIHBhZGRpbmctdG9wOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDIpO1xuXG4gICAgICAudXNlci1zdGF0LXZhbHVlIHtcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiA1cHg7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgIH1cblxuICAgICAgLnVzZXItc3RhdC1uYW1lIHtcbiAgICAgICAgZm9udC1zaXplOiAxNnB4O1xuICAgICAgfVxuICAgIH1cblxuICAgIC51c2VyLWJpbyB7XG4gICAgICBtYXJnaW46IHZhcigtLXBhZ2UtbWFyZ2luKSAwcHggMHB4O1xuICAgICAgbGluZS1oZWlnaHQ6IDEuMjtcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICB9XG4gIH1cblxuICAudXNlci1wcmVmZXJlbmNlcy13cmFwcGVyIHtcbiAgICAtLWlvbi1ncmlkLWNvbHVtbi1wYWRkaW5nOiAwcHg7XG5cbiAgICBwYWRkaW5nOiB2YXIoLS1wYWdlLW1hcmdpbik7XG5cbiAgICAucHJlZmVyZW5jZS1uYW1lIHtcbiAgICAgIG1hcmdpbjogMHB4IDBweCA1cHg7XG4gICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgfVxuXG4gICAgLnByZWZlcmVuY2UtdmFsdWUge1xuICAgICAgbWFyZ2luOiAwcHggMHB4IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMik7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICBsaW5lLWhlaWdodDogMS40O1xuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrLXRpbnQpO1xuICAgIH1cbiAgfVxuXG4gIC5yYWRpby10YWdzIHtcbiAgICBwYWRkaW5nOiAwcHggY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLSB2YXIoLS1wYWdlLXRhZ3MtZ3V0dGVyKSk7XG5cdFx0YmFja2dyb3VuZC1jb2xvcjogdmFyKC0tcGFnZS1iYWNrZ3JvdW5kKTtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG5cblx0XHRAaW5jbHVkZSByYWRpby10YWcoKTtcblxuICAgIC8vIEFkZCBhIGRlZXBlciBzZWxlY3RvciB0byBvdmVycmlkZSBkZWZhdWx0IGNvbG9yc1xuICAgIC5yYWRpby10YWcge1xuICAgICAgLS1yYWRpby10YWctY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xuICAgICAgLS1yYWRpby10YWctYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWxpZ2h0ZXN0KTtcbiAgICAgIC0tcmFkaW8tdGFnLWFjdGl2ZS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0ZXN0KTtcbiAgICAgIC0tcmFkaW8tdGFnLWFjdGl2ZS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kYXJ5KTtcblxuICAgICAgcGFkZGluZzogMHB4IHZhcigtLXBhZ2UtdGFncy1ndXR0ZXIpO1xuICAgICAgbWFyZ2luOiB2YXIoLS1wYWdlLXRhZ3MtZ3V0dGVyKSAwcHg7XG4gICAgfVxuXHR9XG5cbiAgLnN1Ym1pdC1idG4sXG4gIC50aXAtbGFiZWwge1xuICAgIG1hcmdpbjogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgKiAyKTtcbiAgfVxuXG5cbiAgLmlucHV0LWl0ZW0ge1xuICAgIC0tcGFkZGluZy1zdGFydDogMHB4O1xuICAgIC0tcGFkZGluZy1lbmQ6IDBweDtcbiAgICAtLWlubmVyLXBhZGRpbmctZW5kOiAwcHg7XG5cbiAgICBpb24taW5wdXQge1xuICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAwcHg7XG4gICAgICAtLXBhZGRpbmctZW5kOiAwcHg7XG4gICAgICAvLyBmb250LXNpemU6IDIuMHJlbTtcbiAgICAgIC8vIGhlaWdodDogMS42cmVtO1xuICAgICAgLy8gcGFkZGluZzogMXJlbSAwO1xuICAgICAgZm9udC1zaXplOiAzMHB4O1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIH1cbiAgfVxufVxuXG46aG9zdC1jb250ZXh0KC5pb3MpIHtcbiAgLnJhZGlvLXRhZ3MsXG4gIC5jaGVja2JveC10YWdzIHtcbiAgICBtYXJnaW4tYm90dG9tOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAqIDIpO1xuICB9XG59XG4iLCJAbWl4aW4gcmFkaW8tdGFnKCkge1xuICAvLyBEZWZhdWx0IHZhbHVlc1xuICAtLXJhZGlvLXRhZy1jb2xvcjogIzAwMDtcbiAgLS1yYWRpby10YWctYmFja2dyb3VuZDogI0ZGRjtcbiAgLS1yYWRpby10YWctYWN0aXZlLWNvbG9yOiAjRkZGO1xuICAtLXJhZGlvLXRhZy1hY3RpdmUtYmFja2dyb3VuZDogIzAwMDtcblxuXHQucmFkaW8tdGFnIHtcbiAgICAvLyBSZXNldCB2YWx1ZXMgZnJvbSBJb25pYyAoaW9uLWl0ZW0pIHN0eWxlc1xuICAgIC0tcGFkZGluZy1zdGFydDogMHB4O1xuICAgIC0taW5uZXItcGFkZGluZy1lbmQ6IDhweDtcblx0XHQtLWlubmVyLXBhZGRpbmctc3RhcnQ6IDhweDtcbiAgICAtLW1pbi1oZWlnaHQ6IDE4cHg7XG5cblx0XHQtLWJvcmRlci1yYWRpdXM6IDhweDtcbiAgICAtLWJvcmRlci13aWR0aDogMXB4O1xuXHRcdC0tYm9yZGVyLXN0eWxlOiBzb2xpZDtcblx0XHQtLWJvcmRlci1jb2xvcjogdmFyKC0tcmFkaW8tdGFnLWNvbG9yKTtcblx0XHQtLWlvbi1pdGVtLWJhY2tncm91bmQ6IHZhcigtLXJhZGlvLXRhZy1iYWNrZ3JvdW5kKTtcblx0XHQtLWlvbi1pdGVtLWNvbG9yOiB2YXIoLS1yYWRpby10YWctY29sb3IpO1xuXG4gICAgZmxleDogMTtcblxuXHRcdCYuaXRlbS1yYWRpby1jaGVja2VkIHtcbiAgICAgIC0taW9uLWl0ZW0tYmFja2dyb3VuZDogdmFyKC0tcmFkaW8tdGFnLWFjdGl2ZS1iYWNrZ3JvdW5kKTtcbiAgICAgIC0taW9uLWl0ZW0tY29sb3I6IHZhcigtLXJhZGlvLXRhZy1hY3RpdmUtY29sb3IpO1xuXHRcdH1cblxuICAgICYuaXRlbS1pbnRlcmFjdGl2ZS1kaXNhYmxlZCB7XG4gICAgICBvcGFjaXR5OiAwLjU7XG5cbiAgICAgIC50YWctbGFiZWwge1xuICAgICAgICAvLyBPdmVycmlkZSBJb25pYyBkZWZhdWx0IHN0eWxlXG4gICAgICAgIG9wYWNpdHk6IDE7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLnRhZy1sYWJlbCB7XG5cdFx0XHRtYXJnaW46IDVweDtcbiAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICBsZXR0ZXItc3BhY2luZzogMC4ycHg7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG5cdFx0fVxuXG5cdFx0aW9uLXJhZGlvIHtcblx0XHRcdG1hcmdpbjogMHB4O1xuXHRcdFx0Ly8gVG8gaGlkZSB0aGUgLnJhZGlvLWljb25cblx0XHRcdHdpZHRoOiAwcHg7XG5cdFx0XHQtLWJvcmRlci13aWR0aDogMHB4O1xuXHRcdFx0aGVpZ2h0OiAwcHg7XG5cdFx0XHQvLyBXZSBjYW50IHNldCB3aWR0aCBhbmQgaGVpZ2h0IGZvciAucmFkaW8taWNvbiAucmFkaW8taW5uZXIsIHNvIGxldHMgaGlkZSBpdCBjaGFuZ2luZyBpdHMgY29sb3Jcblx0XHRcdC0tY29sb3ItY2hlY2tlZDogdHJhbnNwYXJlbnQ7XG5cdFx0fVxuXHR9XG59XG4iXX0= */");

/***/ }),

/***/ "s8HK":
/*!***********************************************************!*\
  !*** ./src/app/pages/complemented/complemented.module.ts ***!
  \***********************************************************/
/*! exports provided: ComplementedModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComplementedModule", function() { return ComplementedModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _complemented_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./complemented.page */ "RsMY");
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components/components.module */ "j1ZV");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "3Pt+");








let ComplementedModule = class ComplementedModule {
};
ComplementedModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
            _components_components_module__WEBPACK_IMPORTED_MODULE_6__["ComponentsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ReactiveFormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{ path: '', component: _complemented_page__WEBPACK_IMPORTED_MODULE_5__["ComplementedPage"] }])
        ],
        declarations: [_complemented_page__WEBPACK_IMPORTED_MODULE_5__["ComplementedPage"]]
    })
], ComplementedModule);



/***/ })

}]);
//# sourceMappingURL=pages-complemented-complemented-module.js.map