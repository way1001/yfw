(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-validations-forms-validations-module"],{

/***/ "7C9d":
/*!***************************************************************!*\
  !*** ./src/app/pages/validations/forms-validations.module.ts ***!
  \***************************************************************/
/*! exports provided: FormsValidationsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FormsValidationsPageModule", function() { return FormsValidationsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components/components.module */ "j1ZV");
/* harmony import */ var _forms_validations_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./forms-validations.page */ "iqno");
/* harmony import */ var ng_zorro_antd_mobile__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ng-zorro-antd-mobile */ "EZ1+");









const routes = [
    {
        path: '',
        component: _forms_validations_page__WEBPACK_IMPORTED_MODULE_7__["FormsValidationsPage"]
    }
];
let FormsValidationsPageModule = class FormsValidationsPageModule {
};
FormsValidationsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes),
            _components_components_module__WEBPACK_IMPORTED_MODULE_6__["ComponentsModule"],
            ng_zorro_antd_mobile__WEBPACK_IMPORTED_MODULE_8__["ImagePickerModule"],
        ],
        declarations: [_forms_validations_page__WEBPACK_IMPORTED_MODULE_7__["FormsValidationsPage"]]
    })
], FormsValidationsPageModule);



/***/ }),

/***/ "VQEl":
/*!****************************************************************!*\
  !*** ./src/app/pages/validations/forms-validations.service.ts ***!
  \****************************************************************/
/*! exports provided: FormsValidationsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FormsValidationsService", function() { return FormsValidationsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "tk/3");



let FormsValidationsService = class FormsValidationsService {
    constructor(http) {
        this.http = http;
    }
    getOwnInfo() {
        return this.http.get(`/mkt/api/mp/userinfo/own`)
            .pipe();
    }
    updateInfo(id, realName, nickName, gender, phone, province, city, about, headimgUrl) {
        return this.http.put(`/mkt/api/mp/userinfo`, { id, realName,
            nickName, sex: gender, phone, province, city,
            about, headimgUrl })
            .pipe();
    }
};
FormsValidationsService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
FormsValidationsService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], FormsValidationsService);



/***/ }),

/***/ "aM+c":
/*!**********************************************************************!*\
  !*** ./src/app/pages/validations/styles/forms-validations.page.scss ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host {\n  --page-margin: var(--app-fair-margin);\n  --page-background: var(--app-background-shade);\n  --page-tags-gutter: 5px;\n}\n\n.forms-validations-content {\n  --background: var(--page-background);\n}\n\n.forms-validations-content .validations-form {\n  margin-bottom: calc(var(--page-margin) * 2);\n  /* .tag-container {\n    display: flex;\n    padding-top: 22px;\n    flex-direction: row;\n    flex-wrap: wrap;\n  }\n\n  .tag-container > tag {\n    margin-right: 9px;\n    margin-bottom: 9px;\n  } */\n}\n\n.forms-validations-content .validations-form .inputs-list {\n  --ion-item-background: var(--page-background);\n  padding: var(--page-margin) var(--page-margin) calc(var(--page-margin) * 2);\n}\n\n.forms-validations-content .validations-form .inputs-list ion-list-header {\n  padding-inline-start: 0px;\n}\n\n.forms-validations-content .validations-form .inputs-list ion-list-header .header-title {\n  text-transform: uppercase;\n  font-size: 16px;\n  color: var(--ion-color-secondary);\n}\n\n.forms-validations-content .validations-form .inputs-list .input-item {\n  --padding-start: 0px;\n  --padding-end: 0px;\n  --inner-padding-end: 0px;\n}\n\n.forms-validations-content .validations-form .inputs-list .terms-item {\n  --border-width: 0px;\n  --inner-padding-end: 0px;\n}\n\n.forms-validations-content .validations-form .inputs-list .error-container .error-message {\n  margin: calc(var(--page-margin) / 2) 0px;\n  display: flex;\n  align-items: center;\n  color: var(--ion-color-danger);\n  font-size: 14px;\n}\n\n.forms-validations-content .validations-form .inputs-list .error-container .error-message ion-icon {\n  padding-inline-end: calc(var(--page-margin) / 2);\n  flex-shrink: 0;\n}\n\n.forms-validations-content .validations-form .inputs-list .counter-item app-counter-input {\n  --counter-background: transparent;\n  --counter-color: var(--ion-color-primary);\n  --counter-border-color: var(--ion-color-primary);\n}\n\n.forms-validations-content .validations-form .inputs-list .counter-item .counter-value {\n  text-align: center;\n}\n\n.forms-validations-content .validations-form .submit-btn {\n  margin: var(--page-margin);\n}\n\n.forms-validations-content .validations-form ion-item-divider {\n  --background: var(--page-background);\n  --padding-bottom: calc(var(--page-margin) / 2);\n  --padding-top: calc(var(--page-margin) / 2);\n  --padding-start: var(--page-margin);\n  --padding-end: var(--page-margin);\n  border: none;\n}\n\n.forms-validations-content .validations-form .checkbox-tags {\n  padding: calc(var(--page-margin) / 2) calc(var(--page-margin) - var(--page-tags-gutter));\n  --checkbox-tag-color: #000;\n  --checkbox-tag-background: #FFF;\n  --checkbox-tag-active-color: #FFF;\n  --checkbox-tag-active-background: #000;\n}\n\n.forms-validations-content .validations-form .checkbox-tags .checkbox-tag {\n  --padding-start: 0px;\n  --inner-padding-end: 8px;\n  --inner-padding-start: 8px;\n  --ion-item-background: var(--checkbox-tag-background);\n  --ion-item-color: var(--checkbox-tag-color);\n}\n\n.forms-validations-content .validations-form .checkbox-tags .checkbox-tag.rounded-tag {\n  --border-radius: 2.2rem;\n}\n\n.forms-validations-content .validations-form .checkbox-tags .checkbox-tag.item-checkbox-checked {\n  --ion-item-background: var(--checkbox-tag-active-background);\n  --ion-item-color: var(--checkbox-tag-active-color);\n}\n\n.forms-validations-content .validations-form .checkbox-tags .checkbox-tag.item-interactive-disabled {\n  opacity: 0.5;\n}\n\n.forms-validations-content .validations-form .checkbox-tags .checkbox-tag.item-interactive-disabled .tag-label {\n  opacity: 1;\n}\n\n.forms-validations-content .validations-form .checkbox-tags .checkbox-tag .tag-label {\n  margin: 5px;\n  font-size: 12px;\n  font-weight: 500;\n  letter-spacing: 0.2px;\n  text-align: center;\n}\n\n.forms-validations-content .validations-form .checkbox-tags .checkbox-tag ion-checkbox {\n  margin: 0px;\n  width: 0px;\n  --border-width: 0px;\n  height: 0px;\n  --color-checked: transparent;\n}\n\n.forms-validations-content .validations-form .checkbox-tags .checkbox-tag {\n  padding: 0px var(--page-tags-gutter);\n  margin: var(--page-tags-gutter) 0px;\n}\n\n.forms-validations-content .validations-form .checkbox-tags.square-checkbox-tags {\n  background-color: var(--page-background);\n}\n\n.forms-validations-content .validations-form .checkbox-tags.square-checkbox-tags .checkbox-tag {\n  --checkbox-tag-color: var(--ion-color-medium);\n  --checkbox-tag-background: var(--ion-color-lightest);\n  --checkbox-tag-active-color: var(--ion-color-lightest);\n  --checkbox-tag-active-background: var(--ion-color-secondary);\n}\n\n.forms-validations-content .validations-form .checkbox-tags.rounded-checkbox-tags {\n  background-color: var(--ion-color-lightest);\n}\n\n.forms-validations-content .validations-form .checkbox-tags.rounded-checkbox-tags .checkbox-tag {\n  --checkbox-tag-color: var(--ion-color-lightest);\n  --checkbox-tag-background: var(--ion-color-light-shade);\n  --checkbox-tag-active-color: var(--ion-color-lightest);\n  --checkbox-tag-active-background: var(--ion-color-secondary);\n}\n\n::ng-deep .select-alert {\n  --select-alert-color: #000;\n  --select-alert-background: #FFF;\n  --select-alert-margin: 16px;\n  --select-alert-color: var(--ion-color-lightest);\n  --select-alert-background: var(--ion-color-primary);\n  --select-alert-margin: 16px;\n}\n\n::ng-deep .select-alert .alert-head {\n  padding-top: calc((var(--select-alert-margin) / 4) * 3);\n  padding-bottom: calc((var(--select-alert-margin) / 4) * 3);\n  padding-inline-start: var(--select-alert-margin);\n  padding-inline-end: var(--select-alert-margin);\n}\n\n::ng-deep .select-alert .alert-title {\n  color: var(--select-alert-color);\n}\n\n::ng-deep .select-alert .alert-head,\n::ng-deep .select-alert .alert-message {\n  background-color: var(--select-alert-background);\n}\n\n::ng-deep .select-alert .alert-wrapper.sc-ion-alert-ios .alert-title {\n  margin: 0px;\n}\n\n::ng-deep .select-alert .alert-wrapper.sc-ion-alert-md .alert-title {\n  font-size: 18px;\n  font-weight: 400;\n}\n\n::ng-deep .select-alert .alert-wrapper.sc-ion-alert-md .alert-button {\n  --padding-top: 0;\n  --padding-start: 0.9em;\n  --padding-end: 0.9em;\n  --padding-bottom: 0;\n  height: 2.1em;\n  font-size: 13px;\n}\n\n::ng-deep .select-alert .alert-message {\n  display: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2Zvcm1zLXZhbGlkYXRpb25zLnBhZ2Uuc2NzcyIsIi4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uL3RoZW1lL21peGlucy9pbnB1dHMvY2hlY2tib3gtdGFnLnNjc3MiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi90aGVtZS9taXhpbnMvaW5wdXRzL3NlbGVjdC1hbGVydC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUtBO0VBQ0UscUNBQUE7RUFDQSw4Q0FBQTtFQUVBLHVCQUFBO0FBTEY7O0FBVUE7RUFDRSxvQ0FBQTtBQVBGOztBQVNFO0VBQ0UsMkNBQUE7RUE0REE7Ozs7Ozs7Ozs7S0FBQTtBQXhESjs7QUFGSTtFQUNFLDZDQUFBO0VBRUEsMkVBQUE7QUFHTjs7QUFETTtFQUNFLHlCQUFBO0FBR1I7O0FBRFE7RUFDRSx5QkFBQTtFQUNGLGVBQUE7RUFDQSxpQ0FBQTtBQUdSOztBQUNNO0VBQ0Usb0JBQUE7RUFDQSxrQkFBQTtFQUNBLHdCQUFBO0FBQ1I7O0FBRU07RUFDRSxtQkFBQTtFQUNBLHdCQUFBO0FBQVI7O0FBSVE7RUFDRSx3Q0FBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0VBQ0EsZUFBQTtBQUZWOztBQUlVO0VBQ0UsZ0RBQUE7RUFDQSxjQUFBO0FBRlo7O0FBUVE7RUFDRSxpQ0FBQTtFQUNBLHlDQUFBO0VBQ0EsZ0RBQUE7QUFOVjs7QUFTUTtFQUNFLGtCQUFBO0FBUFY7O0FBWUk7RUFDRSwwQkFBQTtBQVZOOztBQXlCSTtFQUNFLG9DQUFBO0VBQ0EsOENBQUE7RUFDQSwyQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsaUNBQUE7RUFFQSxZQUFBO0FBeEJOOztBQTJCRztFQUNHLHdGQUFBO0VDbkdKLDBCQUFBO0VBQ0EsK0JBQUE7RUFDQSxpQ0FBQTtFQUNBLHNDQUFBO0FEMkVGOztBQ3pFQztFQUdDLG9CQUFBO0VBQ0Usd0JBQUE7RUFDRiwwQkFBQTtFQUNBLHFEQUFBO0VBQ0UsMkNBQUE7QUR5RUo7O0FDdkVJO0VBQ0QsdUJBQUE7QUR5RUg7O0FDdEVFO0VBQ0ksNERBQUE7RUFDQSxrREFBQTtBRHdFTjs7QUNyRUk7RUFDRSxZQUFBO0FEdUVOOztBQ3JFTTtFQUVFLFVBQUE7QURzRVI7O0FDbEVFO0VBQ0MsV0FBQTtFQUNHLGVBQUE7RUFDQSxnQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QURvRU47O0FDakVFO0VBQ0MsV0FBQTtFQUVBLFVBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7RUFFQSw0QkFBQTtBRGlFSDs7QUFUTTtFQUNFLG9DQUFBO0VBQ0EsbUNBQUE7QUFXUjs7QUFQTTtFQUNFLHdDQUFBO0FBU1I7O0FBUFE7RUFDRSw2Q0FBQTtFQUNBLG9EQUFBO0VBQ0Esc0RBQUE7RUFDQSw0REFBQTtBQVNWOztBQUpNO0VBQ0UsMkNBQUE7QUFNUjs7QUFKUTtFQUNFLCtDQUFBO0VBQ0EsdURBQUE7RUFDQSxzREFBQTtFQUNBLDREQUFBO0FBTVY7O0FBR0E7RUV6SUUsMEJBQUE7RUFDQSwrQkFBQTtFQUNBLDJCQUFBO0VGMklBLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSwyQkFBQTtBQUFGOztBRTNJRTtFQUNFLHVEQUFBO0VBQ0EsMERBQUE7RUFDQSxnREFBQTtFQUNBLDhDQUFBO0FGNklKOztBRTFJRTtFQUNFLGdDQUFBO0FGNElKOztBRXpJRTs7RUFFRSxnREFBQTtBRjJJSjs7QUV0SUk7RUFDRSxXQUFBO0FGd0lOOztBRWxJSTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtBRm9JTjs7QUVqSUk7RUFFRSxnQkFBQTtFQUNBLHNCQUFBO0VBQ0Esb0JBQUE7RUFDQSxtQkFBQTtFQUVBLGFBQUE7RUFDQSxlQUFBO0FGaUlOOztBQTFCRTtFQUNFLGFBQUE7QUE0QkoiLCJmaWxlIjoiZm9ybXMtdmFsaWRhdGlvbnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGltcG9ydCBcIi4uLy4uLy4uLy4uL3RoZW1lL21peGlucy9pbnB1dHMvc2VsZWN0LWFsZXJ0XCI7XG5AaW1wb3J0IFwiLi4vLi4vLi4vLi4vdGhlbWUvbWl4aW5zL2lucHV0cy9jaGVja2JveC10YWdcIjtcblxuLy8gQ3VzdG9tIHZhcmlhYmxlc1xuLy8gTm90ZTogIFRoZXNlIG9uZXMgd2VyZSBhZGRlZCBieSB1cyBhbmQgaGF2ZSBub3RoaW5nIHRvIGRvIHdpdGggSW9uaWMgQ1NTIEN1c3RvbSBQcm9wZXJ0aWVzXG46aG9zdCB7XG4gIC0tcGFnZS1tYXJnaW46IHZhcigtLWFwcC1mYWlyLW1hcmdpbik7XG4gIC0tcGFnZS1iYWNrZ3JvdW5kOiB2YXIoLS1hcHAtYmFja2dyb3VuZC1zaGFkZSk7XG5cbiAgLS1wYWdlLXRhZ3MtZ3V0dGVyOiA1cHg7XG5cbn1cblxuLy8gTm90ZTogIEFsbCB0aGUgQ1NTIHZhcmlhYmxlcyBkZWZpbmVkIGJlbG93IGFyZSBvdmVycmlkZXMgb2YgSW9uaWMgZWxlbWVudHMgQ1NTIEN1c3RvbSBQcm9wZXJ0aWVzXG4uZm9ybXMtdmFsaWRhdGlvbnMtY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogdmFyKC0tcGFnZS1iYWNrZ3JvdW5kKTtcblxuICAudmFsaWRhdGlvbnMtZm9ybSB7XG4gICAgbWFyZ2luLWJvdHRvbTogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgKiAyKTtcblxuICAgIC5pbnB1dHMtbGlzdCB7XG4gICAgICAtLWlvbi1pdGVtLWJhY2tncm91bmQ6IHZhcigtLXBhZ2UtYmFja2dyb3VuZCk7XG5cbiAgICAgIHBhZGRpbmc6IHZhcigtLXBhZ2UtbWFyZ2luKSB2YXIoLS1wYWdlLW1hcmdpbikgY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgKiAyKTtcblxuICAgICAgaW9uLWxpc3QtaGVhZGVyIHtcbiAgICAgICAgcGFkZGluZy1pbmxpbmUtc3RhcnQ6IDBweDtcblxuICAgICAgICAuaGVhZGVyLXRpdGxlIHtcbiAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgICAgXHRcdGZvbnQtc2l6ZTogMTZweDtcbiAgICAgIFx0XHRjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeSk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLmlucHV0LWl0ZW0ge1xuICAgICAgICAtLXBhZGRpbmctc3RhcnQ6IDBweDtcbiAgICAgICAgLS1wYWRkaW5nLWVuZDogMHB4O1xuICAgICAgICAtLWlubmVyLXBhZGRpbmctZW5kOiAwcHg7XG4gICAgICB9XG5cbiAgICAgIC50ZXJtcy1pdGVtIHtcbiAgICAgICAgLS1ib3JkZXItd2lkdGg6IDBweDtcbiAgICAgICAgLS1pbm5lci1wYWRkaW5nLWVuZDogMHB4O1xuICAgICAgfVxuXG4gICAgICAuZXJyb3ItY29udGFpbmVyIHtcbiAgICAgICAgLmVycm9yLW1lc3NhZ2Uge1xuICAgICAgICAgIG1hcmdpbjogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKSAwcHg7XG4gICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFuZ2VyKTtcbiAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG5cbiAgICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICBwYWRkaW5nLWlubGluZS1lbmQ6IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMik7XG4gICAgICAgICAgICBmbGV4LXNocmluazogMDtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICBcdH1cblxuICAgICAgLmNvdW50ZXItaXRlbSB7XG4gICAgICAgIGFwcC1jb3VudGVyLWlucHV0IHtcbiAgICAgICAgICAtLWNvdW50ZXItYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgICAgICAgLS1jb3VudGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgICAgICAgLS1jb3VudGVyLWJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICB9XG5cbiAgICAgICAgLmNvdW50ZXItdmFsdWUge1xuICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIC5zdWJtaXQtYnRuIHtcbiAgICAgIG1hcmdpbjogdmFyKC0tcGFnZS1tYXJnaW4pO1xuICAgIH1cblxuICAgIC8qIC50YWctY29udGFpbmVyIHtcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICBwYWRkaW5nLXRvcDogMjJweDtcbiAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gICAgICBmbGV4LXdyYXA6IHdyYXA7XG4gICAgfVxuXG4gICAgLnRhZy1jb250YWluZXIgPiB0YWcge1xuICAgICAgbWFyZ2luLXJpZ2h0OiA5cHg7XG4gICAgICBtYXJnaW4tYm90dG9tOiA5cHg7XG4gICAgfSAqL1xuXG4gICAgaW9uLWl0ZW0tZGl2aWRlciB7XG4gICAgICAtLWJhY2tncm91bmQ6IHZhcigtLXBhZ2UtYmFja2dyb3VuZCk7XG4gICAgICAtLXBhZGRpbmctYm90dG9tOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDIpO1xuICAgICAgLS1wYWRkaW5nLXRvcDogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcbiAgICAgIC0tcGFkZGluZy1zdGFydDogdmFyKC0tcGFnZS1tYXJnaW4pO1xuICAgICAgLS1wYWRkaW5nLWVuZDogdmFyKC0tcGFnZS1tYXJnaW4pO1xuICBcbiAgICAgIGJvcmRlcjogbm9uZTtcbiAgICB9XG4gIFxuICAgLmNoZWNrYm94LXRhZ3MgIHtcbiAgICAgIHBhZGRpbmc6IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMikgY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLSB2YXIoLS1wYWdlLXRhZ3MtZ3V0dGVyKSk7XG4gIFxuICAgICAgQGluY2x1ZGUgY2hlY2tib3gtdGFnKCk7XG4gIFxuICAgICAgLmNoZWNrYm94LXRhZyB7XG4gICAgICAgIHBhZGRpbmc6IDBweCB2YXIoLS1wYWdlLXRhZ3MtZ3V0dGVyKTtcbiAgICAgICAgbWFyZ2luOiB2YXIoLS1wYWdlLXRhZ3MtZ3V0dGVyKSAwcHg7IFxuICAgICAgfVxuICBcbiAgICAgIC8vIEFkZCBhIGRlZXBlciBzZWxlY3RvciB0byBvdmVycmlkZSBkZWZhdWx0IGNvbG9yc1xuICAgICAgJi5zcXVhcmUtY2hlY2tib3gtdGFncyB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLXBhZ2UtYmFja2dyb3VuZCk7XG4gIFxuICAgICAgICAuY2hlY2tib3gtdGFnIHtcbiAgICAgICAgICAtLWNoZWNrYm94LXRhZy1jb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG4gICAgICAgICAgLS1jaGVja2JveC10YWctYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWxpZ2h0ZXN0KTtcbiAgICAgICAgICAtLWNoZWNrYm94LXRhZy1hY3RpdmUtY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodGVzdCk7XG4gICAgICAgICAgLS1jaGVja2JveC10YWctYWN0aXZlLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xuICAgICAgICB9XG4gICAgICB9XG4gIFxuICAgICAgLy8gQWRkIGEgZGVlcGVyIHNlbGVjdG9yIHRvIG92ZXJyaWRlIGRlZmF1bHQgY29sb3JzXG4gICAgICAmLnJvdW5kZWQtY2hlY2tib3gtdGFncyB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodGVzdCk7XG4gIFxuICAgICAgICAuY2hlY2tib3gtdGFnIHtcbiAgICAgICAgICAtLWNoZWNrYm94LXRhZy1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0ZXN0KTtcbiAgICAgICAgICAtLWNoZWNrYm94LXRhZy1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItbGlnaHQtc2hhZGUpO1xuICAgICAgICAgIC0tY2hlY2tib3gtdGFnLWFjdGl2ZS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0ZXN0KTtcbiAgICAgICAgICAtLWNoZWNrYm94LXRhZy1hY3RpdmUtYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuLy8gQWxlcnRzIGFuZCBpbiBnZW5lcmFsIGFsbCBvdmVybGF5cyBhcmUgYXR0YWNoZWQgdG8gdGhlIGJvZHkgb3IgaW9uLWFwcCBkaXJlY3RseVxuLy8gV2UgbmVlZCB0byB1c2UgOjpuZy1kZWVwIHRvIGFjY2VzcyBpdCBmcm9tIGhlcmVcbjo6bmctZGVlcCAuc2VsZWN0LWFsZXJ0IHtcbiAgQGluY2x1ZGUgc2VsZWN0LWFsZXJ0KCk7XG5cbiAgLy8gVmFyaWFibGVzIHNob3VsZCBiZSBpbiBhIGRlZXBlciBzZWxlY3RvciBvciBhZnRlciB0aGUgbWl4aW4gaW5jbHVkZSB0byBvdmVycmlkZSBkZWZhdWx0IHZhbHVlc1xuICAtLXNlbGVjdC1hbGVydC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0ZXN0KTtcbiAgLS1zZWxlY3QtYWxlcnQtYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAtLXNlbGVjdC1hbGVydC1tYXJnaW46IDE2cHg7XG5cbiAgLmFsZXJ0LW1lc3NhZ2Uge1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cbn1cbiIsIkBtaXhpbiBjaGVja2JveC10YWcoKSB7XG4gIC8vIERlZmF1bHQgdmFsdWVzXG4gIC0tY2hlY2tib3gtdGFnLWNvbG9yOiAjMDAwO1xuICAtLWNoZWNrYm94LXRhZy1iYWNrZ3JvdW5kOiAjRkZGO1xuICAtLWNoZWNrYm94LXRhZy1hY3RpdmUtY29sb3I6ICNGRkY7XG4gIC0tY2hlY2tib3gtdGFnLWFjdGl2ZS1iYWNrZ3JvdW5kOiAjMDAwO1xuXG5cdC5jaGVja2JveC10YWcge1xuXG4gICAgLy8gUmVzZXQgdmFsdWVzIGZyb20gSW9uaWMgKGlvbi1pdGVtKSBzdHlsZXNcblx0XHQtLXBhZGRpbmctc3RhcnQ6IDBweDtcbiAgICAtLWlubmVyLXBhZGRpbmctZW5kOiA4cHg7XG5cdFx0LS1pbm5lci1wYWRkaW5nLXN0YXJ0OiA4cHg7XG5cdFx0LS1pb24taXRlbS1iYWNrZ3JvdW5kOiB2YXIoLS1jaGVja2JveC10YWctYmFja2dyb3VuZCk7XG4gICAgLS1pb24taXRlbS1jb2xvcjogdmFyKC0tY2hlY2tib3gtdGFnLWNvbG9yKTtcblxuICAgICYucm91bmRlZC10YWcge1xuXHRcdFx0LS1ib3JkZXItcmFkaXVzOiAyLjJyZW07XG5cdFx0fVxuXG5cdFx0Ji5pdGVtLWNoZWNrYm94LWNoZWNrZWQge1xuICAgICAgLS1pb24taXRlbS1iYWNrZ3JvdW5kOiB2YXIoLS1jaGVja2JveC10YWctYWN0aXZlLWJhY2tncm91bmQpO1xuICAgICAgLS1pb24taXRlbS1jb2xvcjogdmFyKC0tY2hlY2tib3gtdGFnLWFjdGl2ZS1jb2xvcik7XG5cdFx0fVxuXG4gICAgJi5pdGVtLWludGVyYWN0aXZlLWRpc2FibGVkIHtcbiAgICAgIG9wYWNpdHk6IDAuNTtcblxuICAgICAgLnRhZy1sYWJlbCB7XG4gICAgICAgIC8vIE92ZXJyaWRlIElvbmljIGRlZmF1bHQgc3R5bGVcbiAgICAgICAgb3BhY2l0eTogMTtcbiAgICAgIH1cbiAgICB9XG5cblx0XHQudGFnLWxhYmVsIHtcblx0XHRcdG1hcmdpbjogNXB4O1xuICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgIGxldHRlci1zcGFjaW5nOiAwLjJweDtcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcblx0XHR9XG5cblx0XHRpb24tY2hlY2tib3gge1xuXHRcdFx0bWFyZ2luOiAwcHg7XG5cdFx0XHQvLyBUbyBoaWRlIHRoZSAuY2hlY2tib3gtaWNvblxuXHRcdFx0d2lkdGg6IDBweDtcblx0XHRcdC0tYm9yZGVyLXdpZHRoOiAwcHg7XG5cdFx0XHRoZWlnaHQ6IDBweDtcblx0XHRcdC8vIFdlIGNhbnQgc2V0IHdpZHRoIGFuZCBoZWlnaHQgZm9yIC5jaGVja2JveC1pY29uIC5jaGVja2JveC1pbm5lciwgc28gbGV0cyBoaWRlIGl0IGNoYW5naW5nIGl0cyBjb2xvclxuXHRcdFx0LS1jb2xvci1jaGVja2VkOiB0cmFuc3BhcmVudDtcblx0XHR9XG5cdH1cbn1cbiIsIkBtaXhpbiBzZWxlY3QtYWxlcnQoKSB7XG4gIC8vIERlZmF1bHQgdmFsdWVzXG4gIC0tc2VsZWN0LWFsZXJ0LWNvbG9yOiAjMDAwO1xuICAtLXNlbGVjdC1hbGVydC1iYWNrZ3JvdW5kOiAjRkZGO1xuICAtLXNlbGVjdC1hbGVydC1tYXJnaW46IDE2cHg7XG5cbiAgLmFsZXJ0LWhlYWQge1xuICAgIHBhZGRpbmctdG9wOiBjYWxjKCh2YXIoLS1zZWxlY3QtYWxlcnQtbWFyZ2luKSAvIDQpICogMyk7XG4gICAgcGFkZGluZy1ib3R0b206IGNhbGMoKHZhcigtLXNlbGVjdC1hbGVydC1tYXJnaW4pIC8gNCkgKiAzKTtcbiAgICBwYWRkaW5nLWlubGluZS1zdGFydDogdmFyKC0tc2VsZWN0LWFsZXJ0LW1hcmdpbik7XG4gICAgcGFkZGluZy1pbmxpbmUtZW5kOiB2YXIoLS1zZWxlY3QtYWxlcnQtbWFyZ2luKTtcbiAgfVxuXG4gIC5hbGVydC10aXRsZSB7XG4gICAgY29sb3I6IHZhcigtLXNlbGVjdC1hbGVydC1jb2xvcik7XG4gIH1cblxuICAuYWxlcnQtaGVhZCxcbiAgLmFsZXJ0LW1lc3NhZ2Uge1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLXNlbGVjdC1hbGVydC1iYWNrZ3JvdW5kKTtcbiAgfVxuXG4gIC8vIGlPUyBzdHlsZXNcbiAgLmFsZXJ0LXdyYXBwZXIuc2MtaW9uLWFsZXJ0LWlvcyB7XG4gICAgLmFsZXJ0LXRpdGxlIHtcbiAgICAgIG1hcmdpbjogMHB4O1xuICAgIH1cbiAgfVxuXG4gIC8vIE1hdGVyaWFsIHN0eWxlc1xuICAuYWxlcnQtd3JhcHBlci5zYy1pb24tYWxlcnQtbWQge1xuICAgIC5hbGVydC10aXRsZSB7XG4gICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICBmb250LXdlaWdodDogNDAwO1xuICAgIH1cblxuICAgIC5hbGVydC1idXR0b24ge1xuICAgICAgLy8gVmFsdWVzIHRha2VuIGZyb20gSW9uaWMgc21hbGwgYnV0dG9uIHByZXNldFxuICAgICAgLS1wYWRkaW5nLXRvcDogMDtcbiAgICAgIC0tcGFkZGluZy1zdGFydDogMC45ZW07XG4gICAgICAtLXBhZGRpbmctZW5kOiAwLjllbTtcbiAgICAgIC0tcGFkZGluZy1ib3R0b206IDA7XG5cbiAgICAgIGhlaWdodDogMi4xZW07XG4gICAgICBmb250LXNpemU6IDEzcHg7XG4gICAgfVxuICB9XG59XG4iXX0= */");

/***/ }),

/***/ "cWN7":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/validations/forms-validations.page.html ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>完善用户信息</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"forms-validations-content\">\n  <form class=\"validations-form\" [formGroup]=\"validationsForm\">\n    \n    <!-- <div> -->\n    <!-- <ImagePicker -->\n      <!-- [files]=\"files\" -->\n      <!-- [multiple]=\"multiple\" -->\n      <!-- [selectable]=\"files.length < 9\" -->\n      <!-- [accept]=\"'image/gif,image/jpeg,image/jpg,image/png'\" -->\n      <!-- (onChange)=\"fileChange($event)\" -->\n      <!-- (onImageClick)=\"imageClick($event)\" -->\n      <!-- (onImageChange)=\"ImageChange($event)\" -->\n    <!-- ></ImagePicker> -->\n    <!-- </div> -->\n\n    <ion-list class=\"inputs-list\" lines=\"full\">\n      <ion-list-header>\n        <ion-label class=\"header-title\">用户信息</ion-label>\n      </ion-list-header>\n\n      <ion-item class=\"input-item\">\n        <ion-label position=\"floating\">名称</ion-label>\n        <ion-input type=\"text\" formControlName=\"real_name\" clearInput required></ion-input>\n      </ion-item>\n      <div class=\"error-container\">\n        <ng-container *ngFor=\"let validation of validations.real_name\">\n          <div class=\"error-message\" *ngIf=\"validationsForm.get('real_name').hasError(validation.type) && (validationsForm.get('real_name').dirty || validationsForm.get('real_name').touched)\">\n            <ion-icon name=\"information-circle-outline\"></ion-icon>\n            <span>{{ validation.message }}</span>\n          </div>\n        </ng-container>\n      </div>\n\n      <ion-item class=\"input-item\">\n        <ion-label position=\"floating\">昵称</ion-label>\n        <ion-input type=\"text\" formControlName=\"nick_name\" clearInput></ion-input>\n      </ion-item>\n\n\n      <ion-item class=\"input-item item-label-floating\">\n        <ion-label position=\"floating\">性别</ion-label>\n        <ion-select formControlName=\"gender\" cancelText=\"Cancel\" okText=\"OK\">\n          <ion-select-option *ngFor=\"let gender of genders\" [value]=\"gender\" >{{ gender }}</ion-select-option>\n        </ion-select>\n      </ion-item>\n\n      <ion-item class=\"input-item\">\n        <ion-label position=\"floating\">绑定电话</ion-label>\n        <ion-input clearInput placeholder=\"+86\" type=\"text\" formControlName=\"phone\"></ion-input>\n        <ion-button size=\"small\" *ngIf=\"currentUser?.phone === f.phone.value && currentUser?.phone !== ''\">换绑</ion-button>\n      </ion-item>\n\n    </ion-list>\n\n\n    <ion-list class=\"inputs-list\" lines=\"full\">\n      <ion-list-header>\n        <ion-label class=\"header-title\">地区</ion-label>\n      </ion-list-header>\n\n      <ion-item class=\"input-item\">\n        <ion-label position=\"floating\">省份</ion-label>\n        <ion-input type=\"text\" formControlName=\"province\" clearInput></ion-input>\n      </ion-item>\n\n      <ion-item class=\"input-item\">\n        <ion-label position=\"floating\">城市</ion-label>\n        <ion-input type=\"text\" formControlName=\"city\" clearInput></ion-input>\n      </ion-item>\n       \n    </ion-list>\n\n\n    <ion-list class=\"inputs-list\" lines=\"full\">\n      <ion-list-header>\n        <ion-label class=\"header-title\">用户图像</ion-label>\n      </ion-list-header>\n\n      <!-- <ion-item class=\"input-item\"> -->\n        <!-- <ion-label position=\"floating\">商户图标</ion-label> -->\n        <div slot=\"end\">\n          <ImagePicker\n            [files]=\"f.headimg_url.value\"\n            [multiple]=\"multiple\"\n            [length]=\"1\"\n            [selectable]=\"f.headimg_url.value.length < 1\"\n            [accept]=\"'image/gif,image/jpeg,image/jpg,image/png'\"\n            (onChange)=\"fileChange($event)\"\n            (onImageClick)=\"imageClick($event)\"\n            (onImageChange)=\"ImageChange($event)\">\n          </ImagePicker>\n        </div>\n\n      <!-- Textarea with custom number of rows and cols -->\n      <ion-item class=\"input-item\">\n        <ion-label position=\"floating\">用户简介</ion-label>\n        <ion-textarea formControlName=\"about\" rows=\"6\" cols=\"20\" clearOnEdit=\"true\" placeholder=\"请填写简介内容...\"></ion-textarea>\n      </ion-item>\n\n    </ion-list>\n\n    <ion-button class=\"submit-btn\" type=\"submit\" expand=\"block\" fill=\"outline\" [disabled]=\"!validationsForm.valid || (!ownInfo.headimgUrl && !f.headimg_url.value[0]?.link)\" (click)=\"onSubmit()\">提交</ion-button>\n  </form>\n</ion-content>\n");

/***/ }),

/***/ "iqno":
/*!*************************************************************!*\
  !*** ./src/app/pages/validations/forms-validations.page.ts ***!
  \*************************************************************/
/*! exports provided: FormsValidationsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FormsValidationsPage", function() { return FormsValidationsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_forms_validations_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./forms-validations.page.html */ "cWN7");
/* harmony import */ var _styles_forms_validations_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/forms-validations.page.scss */ "aM+c");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _forms_validations_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./forms-validations.service */ "VQEl");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _app_core_service_uploader_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @app/core/_service/uploader.service */ "0Fbw");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var compressorjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! compressorjs */ "fI17");
/* harmony import */ var compressorjs__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(compressorjs__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ "tyNb");













// const data = [
//   {
//     url: 'https://zos.alipayobjects.com/rmsportal/PZUUCKTRIHWiZSY.jpeg'
//   },
//   {
//     url: 'https://zos.alipayobjects.com/rmsportal/hqQWgTXdrlmVVYi.jpeg'
//   }
// ];
let FormsValidationsPage = class FormsValidationsPage {
    constructor(formsValidationsService, modalController, uploadService, router) {
        this.formsValidationsService = formsValidationsService;
        this.modalController = modalController;
        this.uploadService = uploadService;
        this.router = router;
        this.validations = {
            'real_name': [
                { type: 'required', message: '名称不能为空.' },
            ],
            // 'lastname': [
            //   { type: 'required', message: 'Last name is required.' }
            // ],
            // 'email': [
            //   { type: 'required', message: 'Email is required.' },
            //   { type: 'pattern', message: 'Enter a valid email.' }
            // ],
            'phone': [
                { type: 'required', message: 'Phone is required.' },
            ],
        };
        // files = data.slice(0);
        this.multiple = false;
        this.generas = [];
        this.subclasses = [];
        this.tags = [];
        this.generaIndex = [];
        this.subclassIndex = [];
        this.imgChange1 = false;
        this.imgChange2 = false;
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.category = JSON.parse(localStorage.getItem('category'));
    }
    ngOnInit() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.genders = [
                '其它',
                '先生',
                '女士'
            ];
            this.validationsForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
                'real_name': new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required),
                'nick_name': new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](''),
                'gender': new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required),
                'phone': new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]({ value: '', disabled: true }),
                'province': new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](''),
                'city': new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](''),
                'about': new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](''),
                'headimg_url': new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]([]),
            });
            this.formsValidationsService.getOwnInfo().subscribe(res => {
                if (res.ok) {
                    this.ownInfo = res.data;
                    this.s(this.ownInfo);
                    console.log(this.ownInfo);
                }
            });
        });
    }
    get f() { return this.validationsForm.controls; }
    s(mb) {
        if (mb.phone) {
            this.f.real_name.setValue(mb.realName);
            this.f.nick_name.setValue(mb.nickName);
            this.f.gender.setValue(this.genders[mb.sex]);
            this.f.about.setValue(mb.about);
            this.f.phone.setValue(mb.phone);
            this.f.province.setValue(mb.province);
            this.f.city.setValue(mb.city);
            mb.headimgUrl ? this.f.headimg_url.setValue([{ url: `${mb.headimgUrl}` }]) : null;
        }
    }
    onSubmit() {
        let headimgUrl = this.imgChange === false ? this.ownInfo.headimgUrl : (this.f.headimg_url.value[0] ? (this.f.headimg_url.value[0].link ? this.f.headimg_url.value[0].link : '') : '');
        this.formsValidationsService.updateInfo(this.ownInfo.id, this.f.real_name.value, this.f.nick_name.value, this.genders.indexOf(this.f.gender.value) || 0, this.f.phone.value, this.f.province.value, this.f.city.value, this.f.about.value, headimgUrl).subscribe(res => {
            if (res.ok) {
                this.router.navigate(['/app/home']);
            }
        });
    }
    ImageChange(params) {
        const { files, type, index } = params;
        // this.files = files;
    }
    fileChange(params) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const { files, operationType, index } = params;
            /*  const pu = (fd)=>{
               this.files.push({ data: fd, inProgress: false, progress: 0});
               this.files.forEach(file => {
                 this.uploadFile(file);
               });
             }; */
            switch (operationType) {
                case 'add':
                    if (files) {
                        // collect promises from the compression function
                        const compressPromises = [];
                        for (const file of files) {
                            compressPromises.push(this.compressImage(this.dataURItoBlob(file.url)));
                        }
                        // wait until these properties are resolved and loop through the result
                        Promise.all(compressPromises).then((compressedFiles) => {
                            for (const file of compressedFiles) {
                                const formData = new FormData();
                                formData.append('file', file);
                                formData.append('dir', '');
                                formData.append('fileType', 'image');
                                this.uploadFile({ data: formData, inProgress: false, progress: 0 });
                                // do whatever you need to do with these files - upload to server or whatever
                            }
                        }).catch((error) => console.log('ooops :(', error));
                        /* for (let i = 0; i < files.length; i++) {
                          const file = files[i];
                          //console.log("图片大小：" + file.url.length / 1024  + "KB");//打印计算出来的图片大小
                          //const prop = Math.sqrt( file.url.length / 102400 / 1.3);
                          // 若图片>100kb，即压缩比例>1，压缩图片
                          //if (prop > 1) {
                          //  this.compressedImg(file.url, prop);//使用canvas压缩图片
                          //} else {//否则，可以直接使用该图片
                          //  console.log(file.url);
                          //}
                         new Compressor(this.dataURItoBlob(file.url), {
                            quality: 0.6,
                            convertSize: 500000,
                            success(result) {
                              // console.log(result);
                              const formData = new FormData();
              
                              formData.append('file', result);
                              formData.append('dir', 'merchant');
                              formData.append('fileType', 'image');
              
                              pu(formData);
              
                            },
                            error(err) {
                              console.log(err.message);
                            },
                          });
                          // this.files.push({ data: file, inProgress: false, progress: 0});
                        }
                        //TODO 压缩以后异步方式问题
                        // this.files.forEach(file => {
                        //   this.uploadFile(file);
                        // }); */
                    }
                    break;
                case 'remove':
                    //TODO not delete 7niu
                    break;
                default:
                    break;
            }
        });
    }
    /* //使用canvas压缩图片
    compressedImg = function(path, prop){
      var img = new Image();
      img.src = path;
      img.onload = function () {
          var that = this;
          // 按压缩比例进行压缩
          var w = that.width/prop,
              h = that.height/prop;
          // console.log(w);
          // console.log(h);
          var quality = 1;  // 默认图片质量为1
          //生成canvas
          var canvas = document.createElement('canvas');
          var ctx = canvas.getContext('2d');
          // 创建属性节点
          var anw = document.createAttribute("width");
          anw.nodeValue = w;
          var anh = document.createAttribute("height");
          anh.nodeValue = h;
          canvas.setAttributeNode(anw);
          canvas.setAttributeNode(anh);
          ctx.drawImage(that, 0, 0, w, h);
          // quality值越小，所绘制出的图像越模糊
          var imgUrl = canvas.toDataURL('image/jpeg', quality);//压缩后的图片base64码
          console.log(imgUrl);//打印压缩后的图片base64码
          console.log("压缩后：" + imgUrl.length / 1024 + "KB");
      }
    }; */
    compressImage(file) {
        return new Promise((resolve, reject) => {
            new compressorjs__WEBPACK_IMPORTED_MODULE_11___default.a(file, {
                quality: 0.6,
                convertSize: 500000,
                success: (result) => {
                    resolve(new File([result], file.name ? file.name : '', { type: result.type }));
                },
                error: (error) => reject(error)
            });
        });
    }
    uploadFile(file) {
        // const formData = new FormData(); 
        // console.log(this.dataURItoBlob(file.data.url));
        // formData.append('file', this.dataURItoBlob(file.data.url));  
        // formData.append('dir', 'merchant');
        // formData.append('fileType', 'image');
        file.inProgress = true;
        this.uploadService.upload(file.data).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["map"])(event => {
            switch (event.type) {
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpEventType"].UploadProgress:
                    file.progress = Math.round(event.loaded * 100 / event.total);
                    break;
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpEventType"].Response:
                    this.f.headimg_url.value[0].link = event.body.link;
                    return event;
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["catchError"])((error) => {
            file.inProgress = false;
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_10__["of"])(`${file.data.name} upload failed.`);
        })).subscribe((event) => {
            if (typeof (event) === 'object') {
                console.log(event.body);
            }
        });
    }
    dataURItoBlob(dataURI) {
        // convert base64/URLEncoded data component to raw binary data held in a string
        let byteString;
        if (dataURI.split(',')[0].indexOf('base64') >= 0) {
            byteString = atob(dataURI.split(',')[1]);
        }
        else {
            byteString = unescape(dataURI.split(',')[1]);
        }
        // separate out the mime component
        const mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
        // write the bytes of the string to a typed array
        const ia = new Uint8Array(byteString.length);
        for (let i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }
        return new Blob([ia], { type: mimeString });
    }
    imageClick(params) {
        console.log(params);
    }
};
FormsValidationsPage.ctorParameters = () => [
    { type: _forms_validations_service__WEBPACK_IMPORTED_MODULE_5__["FormsValidationsService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"] },
    { type: _app_core_service_uploader_service__WEBPACK_IMPORTED_MODULE_7__["UploadService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_12__["Router"] }
];
FormsValidationsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'forms-validations-page',
        template: _raw_loader_forms_validations_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_styles_forms_validations_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], FormsValidationsPage);



/***/ })

}]);
//# sourceMappingURL=pages-validations-forms-validations-module.js.map