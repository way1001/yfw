(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-signup-signup-module"],{

/***/ "+Apk":
/*!**********************************************************************!*\
  !*** ./src/app/pages/sms-of-service/styles/sms-of-service.page.scss ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host {\n  --page-margin: var(--app-broad-margin);\n  --page-background: var(--app-background-shade);\n}\n\n.legal-content {\n  --background: var(--page-background);\n  --padding-start: var(--page-margin);\n  --padding-end: var(--page-margin);\n  --padding-top: var(--page-margin);\n  --padding-bottom: var(--page-margin);\n  --ion-item-background: var(--page-background);\n}\n\n.legal-content .legal-title {\n  color: var(--ion-color-secondary);\n  margin: var(--page-margin) 0px calc(var(--page-margin) / 2);\n}\n\n.legal-content .legal-text {\n  color: var(--ion-color-medium);\n  margin: calc(var(--page-margin) / 2) 0px var(--page-margin);\n  font-size: 14px;\n  line-height: 20px;\n  text-align: justify;\n}\n\n.legal-content .input-item {\n  --padding-start: 0px;\n  --padding-end: 0px;\n  --inner-padding-end: 0px;\n}\n\n.legal-content .input-item ion-input {\n  --padding-start: 0px;\n  --padding-end: 0px;\n  font-size: 30px;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Ntcy1vZi1zZXJ2aWNlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQTtFQUNFLHNDQUFBO0VBQ0EsOENBQUE7QUFERjs7QUFLQTtFQUNFLG9DQUFBO0VBQ0EsbUNBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esb0NBQUE7RUFDQSw2Q0FBQTtBQUZGOztBQUtFO0VBQ0UsaUNBQUE7RUFDQSwyREFBQTtBQUhKOztBQU1FO0VBQ0UsOEJBQUE7RUFDQSwyREFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0FBSko7O0FBT0U7RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0Esd0JBQUE7QUFMSjs7QUFPSTtFQUNFLG9CQUFBO0VBQ0Esa0JBQUE7RUFJQSxlQUFBO0VBQ0Esa0JBQUE7QUFSTiIsImZpbGUiOiJzbXMtb2Ytc2VydmljZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDdXN0b20gdmFyaWFibGVzXG4vLyBOb3RlOiAgVGhlc2Ugb25lcyB3ZXJlIGFkZGVkIGJ5IHVzIGFuZCBoYXZlIG5vdGhpbmcgdG8gZG8gd2l0aCBJb25pYyBDU1MgQ3VzdG9tIFByb3BlcnRpZXNcbjpob3N0IHtcbiAgLS1wYWdlLW1hcmdpbjogdmFyKC0tYXBwLWJyb2FkLW1hcmdpbik7XG4gIC0tcGFnZS1iYWNrZ3JvdW5kOiB2YXIoLS1hcHAtYmFja2dyb3VuZC1zaGFkZSk7XG59XG5cbi8vIE5vdGU6ICBBbGwgdGhlIENTUyB2YXJpYWJsZXMgZGVmaW5lZCBiZWxvdyBhcmUgb3ZlcnJpZGVzIG9mIElvbmljIGVsZW1lbnRzIENTUyBDdXN0b20gUHJvcGVydGllc1xuLmxlZ2FsLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHZhcigtLXBhZ2UtYmFja2dyb3VuZCk7XG4gIC0tcGFkZGluZy1zdGFydDogdmFyKC0tcGFnZS1tYXJnaW4pO1xuICAtLXBhZGRpbmctZW5kOiB2YXIoLS1wYWdlLW1hcmdpbik7XG4gIC0tcGFkZGluZy10b3A6IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgLS1wYWRkaW5nLWJvdHRvbTogdmFyKC0tcGFnZS1tYXJnaW4pO1xuICAtLWlvbi1pdGVtLWJhY2tncm91bmQ6IHZhcigtLXBhZ2UtYmFja2dyb3VuZCk7XG5cblxuICAubGVnYWwtdGl0bGUge1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kYXJ5KTtcbiAgICBtYXJnaW46IHZhcigtLXBhZ2UtbWFyZ2luKSAwcHggY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcbiAgfVxuXG4gIC5sZWdhbC10ZXh0IHtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG4gICAgbWFyZ2luOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDIpIDBweCB2YXIoLS1wYWdlLW1hcmdpbik7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIGxpbmUtaGVpZ2h0OiAyMHB4O1xuICAgIHRleHQtYWxpZ246IGp1c3RpZnk7XG4gIH1cblxuICAuaW5wdXQtaXRlbSB7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAwcHg7XG4gICAgLS1wYWRkaW5nLWVuZDogMHB4O1xuICAgIC0taW5uZXItcGFkZGluZy1lbmQ6IDBweDtcblxuICAgIGlvbi1pbnB1dCB7XG4gICAgICAtLXBhZGRpbmctc3RhcnQ6IDBweDtcbiAgICAgIC0tcGFkZGluZy1lbmQ6IDBweDtcbiAgICAgIC8vIGZvbnQtc2l6ZTogMi4wcmVtO1xuICAgICAgLy8gaGVpZ2h0OiAxLjZyZW07XG4gICAgICAvLyBwYWRkaW5nOiAxcmVtIDA7XG4gICAgICBmb250LXNpemU6IDMwcHg7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgfVxuICB9XG5cbiAgXG59XG4iXX0= */");

/***/ }),

/***/ "4p4y":
/*!******************************************************!*\
  !*** ./src/app/pages/signup/styles/signup.page.scss ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host {\n  --page-margin: var(--app-broad-margin);\n  --page-background: var(--app-background-shade);\n}\n\n.signup-content {\n  --background: var(--page-background);\n  --padding-start: var(--page-margin);\n  --padding-end: var(--page-margin);\n  --padding-top: var(--page-margin);\n  --padding-bottom: var(--page-margin);\n}\n\n.signup-content .auth-title {\n  color: var(--ion-color-dark);\n  font-weight: bold;\n  margin-top: calc(var(--page-margin) / 2);\n  margin-bottom: calc(var(--page-margin) * (3/2));\n  letter-spacing: 0.6px;\n}\n\n.signup-content .inputs-list {\n  --ion-item-background: var(--page-background);\n}\n\n.signup-content .inputs-list .input-item {\n  --padding-start: 0px;\n  --padding-end: 0px;\n  --inner-padding-end: 0px;\n}\n\n.signup-content .inputs-list .error-container .error-message {\n  margin: calc(var(--page-margin) / 2) 0px;\n  display: flex;\n  align-items: center;\n  color: var(--ion-color-danger);\n  font-size: 14px;\n}\n\n.signup-content .inputs-list .error-container .error-message ion-icon {\n  padding-inline-end: calc(var(--page-margin) / 2);\n}\n\n.signup-content .signup-btn {\n  margin: calc(var(--page-margin) / 2) 0px;\n}\n\n.signup-content .other-auth-options-row {\n  justify-content: flex-end;\n  align-items: center;\n}\n\n.signup-content .other-auth-options-row .login-btn {\n  --color: var(--ion-color-secondary);\n  margin: 0px;\n}\n\n.signup-content .other-auth-options-row .login-btn:focus {\n  outline: none;\n}\n\n.signup-content .social-auth-options .options-divider {\n  color: var(--ion-color-medium);\n  margin: var(--page-margin) 0px;\n  text-align: center;\n}\n\n.signup-content .social-auth-options .social-auth-btn {\n  margin: 0px;\n}\n\n.signup-content .social-auth-options .social-auth-btn:not(:first-child) {\n  margin-top: var(--page-margin);\n}\n\n.signup-content .legal-stuff {\n  text-align: center;\n  font-size: 10px;\n  margin: var(--page-margin) 0px;\n  color: var(--ion-color-medium);\n}\n\n.signup-content .legal-stuff .legal-action {\n  font-weight: 500;\n  color: var(--ion-color-secondary);\n  cursor: pointer;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NpZ251cC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDRSxzQ0FBQTtFQUNBLDhDQUFBO0FBREY7O0FBS0E7RUFDRSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLG9DQUFBO0FBRkY7O0FBSUU7RUFDRSw0QkFBQTtFQUNBLGlCQUFBO0VBQ0Esd0NBQUE7RUFDQSwrQ0FBQTtFQUNBLHFCQUFBO0FBRko7O0FBTUU7RUFDRSw2Q0FBQTtBQUpKOztBQU1JO0VBQ0Usb0JBQUE7RUFDQSxrQkFBQTtFQUNBLHdCQUFBO0FBSk47O0FBUU07RUFDRSx3Q0FBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0VBQ0EsZUFBQTtBQU5SOztBQVFRO0VBQ0UsZ0RBQUE7QUFOVjs7QUFZRTtFQUNFLHdDQUFBO0FBVko7O0FBYUU7RUFDRSx5QkFBQTtFQUNBLG1CQUFBO0FBWEo7O0FBYUk7RUFDRSxtQ0FBQTtFQUNBLFdBQUE7QUFYTjs7QUFhTTtFQUNFLGFBQUE7QUFYUjs7QUFpQkk7RUFDRSw4QkFBQTtFQUNGLDhCQUFBO0VBQ0Esa0JBQUE7QUFmSjs7QUFrQkk7RUFDRSxXQUFBO0FBaEJOOztBQWtCTTtFQUNFLDhCQUFBO0FBaEJSOztBQXFCQztFQUNDLGtCQUFBO0VBQ0UsZUFBQTtFQUNBLDhCQUFBO0VBQ0EsOEJBQUE7QUFuQko7O0FBcUJFO0VBQ0MsZ0JBQUE7RUFDQSxpQ0FBQTtFQUNHLGVBQUE7QUFuQk4iLCJmaWxlIjoic2lnbnVwLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIEN1c3RvbSB2YXJpYWJsZXNcbi8vIE5vdGU6ICBUaGVzZSBvbmVzIHdlcmUgYWRkZWQgYnkgdXMgYW5kIGhhdmUgbm90aGluZyB0byBkbyB3aXRoIElvbmljIENTUyBDdXN0b20gUHJvcGVydGllc1xuOmhvc3Qge1xuICAtLXBhZ2UtbWFyZ2luOiB2YXIoLS1hcHAtYnJvYWQtbWFyZ2luKTtcbiAgLS1wYWdlLWJhY2tncm91bmQ6IHZhcigtLWFwcC1iYWNrZ3JvdW5kLXNoYWRlKTtcbn1cblxuLy8gTm90ZTogIEFsbCB0aGUgQ1NTIHZhcmlhYmxlcyBkZWZpbmVkIGJlbG93IGFyZSBvdmVycmlkZXMgb2YgSW9uaWMgZWxlbWVudHMgQ1NTIEN1c3RvbSBQcm9wZXJ0aWVzXG4uc2lnbnVwLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHZhcigtLXBhZ2UtYmFja2dyb3VuZCk7XG4gIC0tcGFkZGluZy1zdGFydDogdmFyKC0tcGFnZS1tYXJnaW4pO1xuICAtLXBhZGRpbmctZW5kOiB2YXIoLS1wYWdlLW1hcmdpbik7XG4gIC0tcGFkZGluZy10b3A6IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgLS1wYWRkaW5nLWJvdHRvbTogdmFyKC0tcGFnZS1tYXJnaW4pO1xuXG4gIC5hdXRoLXRpdGxlIHtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIG1hcmdpbi10b3A6IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMik7XG4gICAgbWFyZ2luLWJvdHRvbTogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgKiAoMy8yKSk7XG4gICAgbGV0dGVyLXNwYWNpbmc6IDAuNnB4O1xuICB9XG5cblxuICAuaW5wdXRzLWxpc3Qge1xuICAgIC0taW9uLWl0ZW0tYmFja2dyb3VuZDogdmFyKC0tcGFnZS1iYWNrZ3JvdW5kKTtcblxuICAgIC5pbnB1dC1pdGVtIHtcbiAgICAgIC0tcGFkZGluZy1zdGFydDogMHB4O1xuICAgICAgLS1wYWRkaW5nLWVuZDogMHB4O1xuICAgICAgLS1pbm5lci1wYWRkaW5nLWVuZDogMHB4O1xuICAgIH1cblxuICAgIC5lcnJvci1jb250YWluZXIge1xuICAgICAgLmVycm9yLW1lc3NhZ2Uge1xuICAgICAgICBtYXJnaW46IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMikgMHB4O1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhbmdlcik7XG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcblxuICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgcGFkZGluZy1pbmxpbmUtZW5kOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDIpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLnNpZ251cC1idG4ge1xuICAgIG1hcmdpbjogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKSAwcHg7XG4gIH1cblxuICAub3RoZXItYXV0aC1vcHRpb25zLXJvdyB7XG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuXG4gICAgLmxvZ2luLWJ0biB7XG4gICAgICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kYXJ5KTtcbiAgICAgIG1hcmdpbjogMHB4O1xuXG4gICAgICAmOmZvY3VzIHtcbiAgICAgICAgb3V0bGluZTogbm9uZTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAuc29jaWFsLWF1dGgtb3B0aW9ucyB7XG4gICAgLm9wdGlvbnMtZGl2aWRlciB7XG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG4gIFx0XHRtYXJnaW46IHZhcigtLXBhZ2UtbWFyZ2luKSAwcHg7XG4gIFx0XHR0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgfVxuXG4gICAgLnNvY2lhbC1hdXRoLWJ0biB7XG4gICAgICBtYXJnaW46IDBweDtcblxuICAgICAgJjpub3QoOmZpcnN0LWNoaWxkKSB7XG4gICAgICAgIG1hcmdpbi10b3A6IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuXHQubGVnYWwtc3R1ZmYge1xuXHRcdHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXNpemU6IDEwcHg7XG4gICAgbWFyZ2luOiB2YXIoLS1wYWdlLW1hcmdpbikgMHB4O1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcblxuXHRcdC5sZWdhbC1hY3Rpb24ge1xuXHRcdFx0Zm9udC13ZWlnaHQ6IDUwMDtcblx0XHRcdGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kYXJ5KTtcbiAgICAgIGN1cnNvcjogcG9pbnRlcjtcblx0XHR9XG5cdH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "5oUh":
/*!*****************************************************************!*\
  !*** ./src/app/pages/terms-of-service/terms-of-service.page.ts ***!
  \*****************************************************************/
/*! exports provided: TermsOfServicePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TermsOfServicePage", function() { return TermsOfServicePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_terms_of_service_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./terms-of-service.page.html */ "FCju");
/* harmony import */ var _styles_terms_of_service_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/terms-of-service.page.scss */ "fPoY");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");





let TermsOfServicePage = class TermsOfServicePage {
    constructor(modalController) {
        this.modalController = modalController;
    }
    dismiss() {
        this.modalController.dismiss();
    }
};
TermsOfServicePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] }
];
TermsOfServicePage.propDecorators = {
    registrationProtocol: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
TermsOfServicePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-terms-of-service-page',
        template: _raw_loader_terms_of_service_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_styles_terms_of_service_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TermsOfServicePage);



/***/ }),

/***/ "DqXH":
/*!*************************************************************!*\
  !*** ./src/app/pages/sms-of-service/sms-of-service.page.ts ***!
  \*************************************************************/
/*! exports provided: SmsOfServicePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SmsOfServicePage", function() { return SmsOfServicePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_sms_of_service_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./sms-of-service.page.html */ "Hziz");
/* harmony import */ var _styles_sms_of_service_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/sms-of-service.page.scss */ "+Apk");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _app_core_service_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @app/core/_service/toast.service */ "4Jqp");
/* harmony import */ var _signup_singup_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../signup/singup.service */ "nr5d");
/* harmony import */ var _app_core_service_authentication_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @app/core/_service/authentication.service */ "RK3O");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "tyNb");









// import { Keyboard } from 'ionic-native';
let SmsOfServicePage = class SmsOfServicePage {
    constructor(modalController, renderer2, toastService, singupService, authenticationService, router) {
        this.modalController = modalController;
        this.renderer2 = renderer2;
        this.toastService = toastService;
        this.singupService = singupService;
        this.authenticationService = authenticationService;
        this.router = router;
        this.verifyFirst = '';
        this.verifyTwo = '';
        this.verifyThree = '';
        this.verifyFour = '';
        this.captcha = '';
    }
    ngOnInit() {
        // throw new Error("Method not implemented.");
        this.singupService.getRegCode(this.phone).subscribe(res => {
            this.captcha = res.data;
        });
    }
    dismiss() {
        this.modalController.dismiss();
    }
    ionViewDidEnter() {
        setTimeout(() => {
            this.firstInput.setFocus(); //为输入框设置焦点
            // Keyboard.show()
        }, 50);
        // const element = this.renderer2.selectRootElement('#firstNum');
        // setTimeout(() => element.focus(), 150);
    }
    inputEvent(e, num) {
        switch (num) {
            case 1:
                this.verifyFirst = e.target.value;
                if (e.target.value !== '') {
                    setTimeout(() => {
                        this.secondInput.setFocus(); //为输入框设置焦点
                        // Keyboard.show()
                    }, 20);
                }
                break;
            case 2:
                if (e.target.value === '' && this.verifyTwo === '') {
                    setTimeout(() => {
                        this.firstInput.setFocus(); //为输入框设置焦点
                        this.verifyFirst = e.target.value;
                        // Keyboard.show()
                    }, 20);
                }
                else if (e.target.value !== '') {
                    setTimeout(() => {
                        this.thirdInput.setFocus(); //为输入框设置焦点
                        this.verifyTwo = e.target.value;
                        // Keyboard.show()
                    }, 20);
                }
                break;
            case 3:
                if (e.target.value === '' && this.verifyThree === '') {
                    setTimeout(() => {
                        this.secondInput.setFocus(); //为输入框设置焦点
                        this.verifyTwo = e.target.value;
                        // Keyboard.show()
                    }, 20);
                }
                else if (e.target.value !== '') {
                    setTimeout(() => {
                        this.fourthInput.setFocus(); //为输入框设置焦点
                        this.verifyThree = e.target.value;
                        // Keyboard.show()
                    }, 20);
                }
                break;
            case 4:
                if (e.target.value === '' && this.verifyFour === '') {
                    setTimeout(() => {
                        this.thirdInput.setFocus(); //为输入框设置焦点
                        this.verifyThree = e.target.value;
                        // Keyboard.show()
                    }, 20);
                }
                else if (e.target.value !== '') {
                    this.verifyFour = e.target.value;
                    const verifyCode = this.verifyFirst + this.verifyTwo + this.verifyThree + this.verifyFour;
                    if (verifyCode.length === 4) {
                        // const code = JSON.parse(localStorage.getItem('laze'));
                        if (verifyCode === this.captcha) {
                            /* localStorage.setItem('passed', JSON.stringify(true));
                            this.router.navigate([this.returnUrl]); */
                            this.singupService.initUserInfo(this.phone).subscribe(res => {
                                if (res.ok) {
                                    // this.authenticationService.currentUserSubject.next(res.data);
                                    // localStorage.setItem('isReg', JSON.stringify({ isReg: true }));
                                    localStorage.setItem('isReg', '1');
                                }
                                else {
                                    this.toastService.presentErrorToast(res.msg);
                                }
                                this.modalController.dismiss();
                                this.router.navigate(['/forms-and-validations']);
                                //TODO  not pass merchant id
                            });
                        }
                        else {
                            // this.toastService.warning('验码错误，请重新输入');
                            this.toastService.presentErrorToast('无效验证码!请重新输入');
                            this.firstInput.value = '';
                            this.secondInput.value = '';
                            this.thirdInput.value = '';
                            setTimeout(() => {
                                this.firstInput.setFocus(); //为输入框设置焦点
                                // Keyboard.show()
                                this.fourthInput.value = '';
                            }, 50);
                        }
                    }
                }
                break;
            default:
                return null;
        }
    }
    onKeyUpEvent(e, num) {
        // if (e.key === )
        if (e.key === 'Backspace' && e.keyCode === 8) {
            switch (num) {
                case 2:
                    setTimeout(() => {
                        this.firstInput.setFocus(); //为输入框设置焦点
                        // Keyboard.show()
                    }, 20);
                    break;
                case 3:
                    setTimeout(() => {
                        this.secondInput.setFocus(); //为输入框设置焦点
                    }, 20);
                    break;
                case 4:
                    setTimeout(() => {
                        this.thirdInput.setFocus(); //为输入框设置焦点
                    }, 20);
                    break;
                case 1:
                default:
                    break;
            }
        }
    }
};
SmsOfServicePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Renderer2"] },
    { type: _app_core_service_toast_service__WEBPACK_IMPORTED_MODULE_5__["ToastService"] },
    { type: _signup_singup_service__WEBPACK_IMPORTED_MODULE_6__["SingupService"] },
    { type: _app_core_service_authentication_service__WEBPACK_IMPORTED_MODULE_7__["AuthenticationService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"] }
];
SmsOfServicePage.propDecorators = {
    phone: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    firstInput: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['firstNum',] }],
    secondInput: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['secondNum',] }],
    thirdInput: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['thirdNum',] }],
    fourthInput: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['fourthNum',] }]
};
SmsOfServicePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-sms-of-service-page',
        template: _raw_loader_sms_of_service_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_styles_sms_of_service_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SmsOfServicePage);



/***/ }),

/***/ "FCju":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/terms-of-service/terms-of-service.page.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"dismiss()\">关闭</ion-button>\n    </ion-buttons>\n    <ion-title>\n      详情\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"legal-content\">\n  <h3 class=\"legal-title\">平台用户服务协议</h3>\n  <p class=\"legal-text\">\n    {{registrationProtocol}}\n  </p>\n  <!-- <h3 class=\"legal-title\">Using our services</h3>\n  <p class=\"legal-text\">\n    It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n  </p>\n  <h3 class=\"legal-title\">About these terms</h3>\n  <p class=\"legal-text\">\n    There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.\n  </p> -->\n</ion-content>\n");

/***/ }),

/***/ "Hziz":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/sms-of-service/sms-of-service.page.html ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"dismiss()\">关闭</ion-button>\n    </ion-buttons>\n    <!-- <ion-title> -->\n      <!-- 详情 -->\n    <!-- </ion-title> -->\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"legal-content\">\n  <h3 class=\"legal-title\">输入验证码</h3>\n  <p class=\"legal-text\">\n    验证码已发送至 +86 {{phone}}\n  </p>\n\n  <ion-row>\n    <ion-col>\n      <ion-item class=\"input-item\">\n        <ion-input #firstNum maxlength=\"1\" type=\"text\" inputmode=\"tel\" (value)=\"verifyFirst\" (ionInput)=\"inputEvent($event, 1)\" (keyup)=\"onKeyUpEvent($event, 1)\"></ion-input>\n      </ion-item>\n    </ion-col>\n    <ion-col>\n      <ion-item class=\"input-item\">\n        <ion-input #secondNum maxlength=\"1\" type=\"text\" inputmode=\"tel\" (value)=\"verifyTwo\" (ionInput)=\"inputEvent($event, 2)\" (keyup)=\"onKeyUpEvent($event, 2)\" [disabled]=\"verifyFirst===''\"></ion-input>\n      </ion-item>\n    </ion-col>\n    <ion-col>\n      <ion-item class=\"input-item\">\n        <ion-input #thirdNum maxlength=\"1\" type=\"text\" inputmode=\"tel\" (value)=\"verifyThree\" (ionInput)=\"inputEvent($event, 3)\" (keyup)=\"onKeyUpEvent($event, 3)\" [disabled]=\"verifyFirst===''\"></ion-input>\n      </ion-item>\n    </ion-col>\n    <ion-col>\n      <ion-item class=\"input-item\">\n        <ion-input #fourthNum maxlength=\"1\" type=\"text\" inputmode=\"tel\" (value)=\"verifyFour\" (ionInput)=\"inputEvent($event, 4)\" (keyup)=\"onKeyUpEvent($event, 4)\" [disabled]=\"verifyFirst===''\"></ion-input>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  \n</ion-content>\n");

/***/ }),

/***/ "UUSl":
/*!***********************************************!*\
  !*** ./src/app/pages/signup/signup.module.ts ***!
  \***********************************************/
/*! exports provided: SignupPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignupPageModule", function() { return SignupPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _app_components_components_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @app/components/components.module */ "j1ZV");
/* harmony import */ var _signup_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./signup.page */ "XHxw");
/* harmony import */ var _terms_of_service_terms_of_service_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../terms-of-service/terms-of-service.page */ "5oUh");
/* harmony import */ var _privacy_policy_privacy_policy_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../privacy-policy/privacy-policy.page */ "m7nN");
/* harmony import */ var _sms_of_service_sms_of_service_page__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../sms-of-service/sms-of-service.page */ "DqXH");
/* harmony import */ var _app_core_service_toast_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @app/core/_service/toast.service */ "4Jqp");












const routes = [
    {
        path: '',
        component: _signup_page__WEBPACK_IMPORTED_MODULE_7__["SignupPage"]
    }
];
let SignupPageModule = class SignupPageModule {
};
SignupPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes),
            _app_components_components_module__WEBPACK_IMPORTED_MODULE_6__["ComponentsModule"]
        ],
        providers: [_app_core_service_toast_service__WEBPACK_IMPORTED_MODULE_11__["ToastService"]],
        entryComponents: [_terms_of_service_terms_of_service_page__WEBPACK_IMPORTED_MODULE_8__["TermsOfServicePage"], _privacy_policy_privacy_policy_page__WEBPACK_IMPORTED_MODULE_9__["PrivacyPolicyPage"], _sms_of_service_sms_of_service_page__WEBPACK_IMPORTED_MODULE_10__["SmsOfServicePage"]],
        declarations: [_signup_page__WEBPACK_IMPORTED_MODULE_7__["SignupPage"], _terms_of_service_terms_of_service_page__WEBPACK_IMPORTED_MODULE_8__["TermsOfServicePage"], _privacy_policy_privacy_policy_page__WEBPACK_IMPORTED_MODULE_9__["PrivacyPolicyPage"], _sms_of_service_sms_of_service_page__WEBPACK_IMPORTED_MODULE_10__["SmsOfServicePage"]]
    })
], SignupPageModule);



/***/ }),

/***/ "XHxw":
/*!*********************************************!*\
  !*** ./src/app/pages/signup/signup.page.ts ***!
  \*********************************************/
/*! exports provided: SignupPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignupPage", function() { return SignupPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_signup_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./signup.page.html */ "vfPX");
/* harmony import */ var _styles_signup_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/signup.page.scss */ "4p4y");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _terms_of_service_terms_of_service_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../terms-of-service/terms-of-service.page */ "5oUh");
/* harmony import */ var _privacy_policy_privacy_policy_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../privacy-policy/privacy-policy.page */ "m7nN");
/* harmony import */ var _sms_of_service_sms_of_service_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../sms-of-service/sms-of-service.page */ "DqXH");
/* harmony import */ var _singup_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./singup.service */ "nr5d");
/* harmony import */ var _app_core_service_toast_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @app/core/_service/toast.service */ "4Jqp");












let SignupPage = class SignupPage {
    constructor(router, modalController, menu, routerOutlet, singupService, toastService) {
        /* this.matching_passwords_group = new FormGroup({
          'password': new FormControl('', Validators.compose([
            Validators.minLength(5),
            Validators.required
          ])),
          'confirm_password': new FormControl('', Validators.required)
        }, (formGroup: FormGroup) => {
          return PasswordValidator.areNotEqual(formGroup);
        }); */
        this.router = router;
        this.modalController = modalController;
        this.menu = menu;
        this.routerOutlet = routerOutlet;
        this.singupService = singupService;
        this.toastService = toastService;
        this.validation_messages = {
            /* 'email': [
              { type: 'required', message: 'Email is required.' },
              { type: 'pattern', message: 'Enter a valid email.' }
            ], */
            'phone': [
                { type: 'required', message: '需输入完整号码.' },
            ],
            'password': [
                { type: 'required', message: 'Password is required.' },
                { type: 'minlength', message: 'Password must be at least 5 characters long.' }
            ],
            'confirm_password': [
                { type: 'required', message: 'Confirm password is required' }
            ],
            'matching_passwords': [
                { type: 'areNotEqual', message: 'Password mismatch' }
            ]
        };
        this.signupForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
            /* 'email': new FormControl('test@test.com', Validators.compose([
              Validators.required,
              Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
            ])), */
            'phone': new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required,
                // Validators.pattern('^(13[0-9]|14[5|7|9]|15[0|1|2|3|5|6|7|8|9]|16[6]|17[0|1|2|3|5|6|7|8]|18[0-9]|19[8|9])\d{8}$')
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].pattern("^(13[0-9]|14[5|7|9]|15[012356789]|16[6]|17[03678]|18[0-9]|19[8|9])[0-9]{8}$")
            ])),
        });
        this.singupService.getPlatformInfo().subscribe(res => {
            this.platformInfo = res.data;
        });
    }
    get f() { return this.signupForm.controls; }
    // Disable side menu for this page
    ionViewDidEnter() {
        this.menu.enable(false);
    }
    // Restore to default when leaving this page
    ionViewDidLeave() {
        this.menu.enable(true);
    }
    showTermsModal() {
        var _a;
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _terms_of_service_terms_of_service_page__WEBPACK_IMPORTED_MODULE_7__["TermsOfServicePage"],
                swipeToClose: true,
                presentingElement: this.routerOutlet.nativeEl,
                componentProps: {
                    'registrationProtocol': (_a = this.platformInfo) === null || _a === void 0 ? void 0 : _a.registrationProtocol,
                }
            });
            return yield modal.present();
        });
    }
    showPrivacyModal() {
        var _a;
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _privacy_policy_privacy_policy_page__WEBPACK_IMPORTED_MODULE_8__["PrivacyPolicyPage"],
                swipeToClose: true,
                presentingElement: this.routerOutlet.nativeEl,
                componentProps: {
                    'disclaimer': (_a = this.platformInfo) === null || _a === void 0 ? void 0 : _a.disclaimer,
                }
            });
            return yield modal.present();
        });
    }
    showSmsModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.singupService.getRegistrationMessage(this.f.phone.value).subscribe((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                if (res.ok) {
                    const modal = yield this.modalController.create({
                        component: _sms_of_service_sms_of_service_page__WEBPACK_IMPORTED_MODULE_9__["SmsOfServicePage"],
                        swipeToClose: true,
                        presentingElement: this.routerOutlet.nativeEl,
                        componentProps: {
                            'phone': this.f.phone.value
                        }
                    });
                    return yield modal.present();
                }
                else {
                    this.toastService.presentErrorToast(res.msg);
                }
            }));
        });
    }
    doSignup() {
        console.log('do sign up');
        // this.router.navigate(['/app/home']);
    }
};
SignupPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["MenuController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonRouterOutlet"] },
    { type: _singup_service__WEBPACK_IMPORTED_MODULE_10__["SingupService"] },
    { type: _app_core_service_toast_service__WEBPACK_IMPORTED_MODULE_11__["ToastService"] }
];
SignupPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-signup',
        template: _raw_loader_signup_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_styles_signup_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SignupPage);



/***/ }),

/***/ "fPoY":
/*!**************************************************************************!*\
  !*** ./src/app/pages/terms-of-service/styles/terms-of-service.page.scss ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host {\n  --page-margin: var(--app-broad-margin);\n  --page-background: var(--app-background-shade);\n}\n\n.legal-content {\n  --background: var(--page-background);\n  --padding-start: var(--page-margin);\n  --padding-end: var(--page-margin);\n  --padding-top: var(--page-margin);\n  --padding-bottom: var(--page-margin);\n}\n\n.legal-content .legal-title {\n  color: var(--ion-color-secondary);\n  margin: var(--page-margin) 0px calc(var(--page-margin) / 2);\n}\n\n.legal-content .legal-text {\n  color: var(--ion-color-medium);\n  margin: calc(var(--page-margin) / 2) 0px var(--page-margin);\n  font-size: 14px;\n  line-height: 20px;\n  text-align: justify;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Rlcm1zLW9mLXNlcnZpY2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0Usc0NBQUE7RUFDQSw4Q0FBQTtBQURGOztBQUtBO0VBQ0Usb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsaUNBQUE7RUFDQSxvQ0FBQTtBQUZGOztBQUlFO0VBQ0UsaUNBQUE7RUFDQSwyREFBQTtBQUZKOztBQUtFO0VBQ0UsOEJBQUE7RUFDQSwyREFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0FBSEoiLCJmaWxlIjoidGVybXMtb2Ytc2VydmljZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDdXN0b20gdmFyaWFibGVzXG4vLyBOb3RlOiAgVGhlc2Ugb25lcyB3ZXJlIGFkZGVkIGJ5IHVzIGFuZCBoYXZlIG5vdGhpbmcgdG8gZG8gd2l0aCBJb25pYyBDU1MgQ3VzdG9tIFByb3BlcnRpZXNcbjpob3N0IHtcbiAgLS1wYWdlLW1hcmdpbjogdmFyKC0tYXBwLWJyb2FkLW1hcmdpbik7XG4gIC0tcGFnZS1iYWNrZ3JvdW5kOiB2YXIoLS1hcHAtYmFja2dyb3VuZC1zaGFkZSk7XG59XG5cbi8vIE5vdGU6ICBBbGwgdGhlIENTUyB2YXJpYWJsZXMgZGVmaW5lZCBiZWxvdyBhcmUgb3ZlcnJpZGVzIG9mIElvbmljIGVsZW1lbnRzIENTUyBDdXN0b20gUHJvcGVydGllc1xuLmxlZ2FsLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHZhcigtLXBhZ2UtYmFja2dyb3VuZCk7XG4gIC0tcGFkZGluZy1zdGFydDogdmFyKC0tcGFnZS1tYXJnaW4pO1xuICAtLXBhZGRpbmctZW5kOiB2YXIoLS1wYWdlLW1hcmdpbik7XG4gIC0tcGFkZGluZy10b3A6IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgLS1wYWRkaW5nLWJvdHRvbTogdmFyKC0tcGFnZS1tYXJnaW4pO1xuXG4gIC5sZWdhbC10aXRsZSB7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xuICAgIG1hcmdpbjogdmFyKC0tcGFnZS1tYXJnaW4pIDBweCBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDIpO1xuICB9XG5cbiAgLmxlZ2FsLXRleHQge1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbiAgICBtYXJnaW46IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMikgMHB4IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgbGluZS1oZWlnaHQ6IDIwcHg7XG4gICAgdGV4dC1hbGlnbjoganVzdGlmeTtcbiAgfVxufVxuIl19 */");

/***/ }),

/***/ "vfPX":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/signup/signup.page.html ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <!-- <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons> -->\n    <ion-title>用户注册</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"signup-content\">\n  <h2 class=\"auth-title\">\n    欢迎注册\n  </h2>\n  <form [formGroup]=\"signupForm\" (ngSubmit)=\"doSignup()\">\n    <ion-list class=\"inputs-list\" lines=\"full\">\n      <!-- <ion-item class=\"input-item\"> -->\n        <!-- <ion-input type=\"email\" placeholder=\"Email\" formControlName=\"email\" clearInput autocapitalize=\"off\" inputmode=\"numeric\"></ion-input> -->\n      <!-- </ion-item> -->\n      <!-- <div class=\"error-container\"> -->\n        <!-- <ng-container *ngFor=\"let validation of validation_messages.email\"> -->\n          <!-- <div class=\"error-message\" *ngIf=\"signupForm.get('email').hasError(validation.type) && (signupForm.get('email').dirty || signupForm.get('email').touched)\"> -->\n            <!-- <ion-icon name=\"information-circle-outline\"></ion-icon> -->\n            <!-- <span>{{ validation.message }}</span> -->\n          <!-- </div> -->\n        <!-- </ng-container> -->\n      <!-- </div> -->\n\n      <ion-item class=\"input-item\">\n        <!-- <ion-label position=\"floating\">Phone</ion-label> -->\n        <ion-input clearInput maxlength=\"11\" placeholder=\"+86\" type=\"text\" formControlName=\"phone\" autocapitalize=\"off\" inputmode=\"tel\"></ion-input>\n      </ion-item>\n      <div class=\"error-container\">\n        <ng-container *ngFor=\"let validation of validation_messages.phone\">\n          <div class=\"error-message\" *ngIf=\"signupForm.get('phone').hasError(validation.type) && (signupForm.get('phone').dirty || signupForm.get('phone').touched)\">\n            <ion-icon name=\"information-circle-outline\"></ion-icon>\n            <span>{{ validation.message }}</span>\n          </div>\n        </ng-container>\n      </div>\n\n      <!-- <div formGroupName=\"matching_passwords\"> -->\n        <!-- <ion-item class=\"input-item\"> -->\n          <!-- <app-show-hide-password> -->\n            <!-- <ion-input type=\"password\" placeholder=\"Password\" formControlName=\"password\"></ion-input> -->\n          <!-- </app-show-hide-password> -->\n        <!-- </ion-item> -->\n        <!-- <div class=\"error-container\"> -->\n          <!-- <ng-container *ngFor=\"let validation of validation_messages.password\"> -->\n            <!-- <div class=\"error-message\" *ngIf=\"signupForm.get('matching_passwords').get('password').hasError(validation.type) && (signupForm.get('matching_passwords').get('password').dirty || signupForm.get('matching_passwords').get('password').touched)\"> -->\n              <!-- <ion-icon name=\"information-circle-outline\"></ion-icon> -->\n              <!-- <span>{{ validation.message }}</span> -->\n            <!-- </div> -->\n          <!-- </ng-container> -->\n        <!-- </div> -->\n<!--  -->\n        <!-- <ion-item class=\"input-item\"> -->\n          <!-- <app-show-hide-password> -->\n            <!-- <ion-input type=\"password\" placeholder=\"Confirm Password\" formControlName=\"confirm_password\"></ion-input> -->\n          <!-- </app-show-hide-password> -->\n        <!-- </ion-item> -->\n        <!-- <div class=\"error-container\"> -->\n          <!-- <ng-container *ngFor=\"let validation of validation_messages.confirm_password\"> -->\n            <!-- <div class=\"error-message\" *ngIf=\"signupForm.get('matching_passwords').get('confirm_password').hasError(validation.type) && (signupForm.get('matching_passwords').get('confirm_password').dirty || signupForm.get('matching_passwords').get('confirm_password').touched)\"> -->\n              <!-- <ion-icon name=\"information-circle-outline\"></ion-icon> -->\n              <!-- <span>{{ validation.message }}</span> -->\n            <!-- </div> -->\n          <!-- </ng-container> -->\n        <!-- </div> -->\n      <!-- </div> -->\n      <!-- <div class=\"error-container\"> -->\n        <!-- <ng-container *ngFor=\"let validation of validation_messages.matching_passwords\"> -->\n          <!-- <div class=\"error-message\" *ngIf=\"signupForm.get('matching_passwords').hasError(validation.type) && (signupForm.get('matching_passwords').get('confirm_password').dirty || signupForm.get('matching_passwords').get('confirm_password').touched)\"> -->\n            <!-- <ion-icon name=\"information-circle-outline\"></ion-icon> -->\n            <!-- <span>{{ validation.message }}</span> -->\n          <!-- </div> -->\n        <!-- </ng-container> -->\n      <!-- </div> -->\n    </ion-list>\n\n    <ion-button class=\"signup-btn\" type=\"submit\" expand=\"block\" [disabled]=\"!signupForm.valid\" (click)=\"showSmsModal()\">获取短信验证</ion-button>\n    <!-- <ion-row class=\"other-auth-options-row\"> -->\n      <!-- <ion-button class=\"login-btn\" fill=\"clear\" [routerLink]=\"['/auth/login']\"> -->\n        <!-- Already have an account? -->\n      <!-- </ion-button> -->\n    <!-- </ion-row> -->\n  </form>\n\n  <!-- <div class=\"social-auth-options\"> -->\n    <!-- <p class=\"options-divider\">Or</p> -->\n    <!-- <ion-button class=\"social-auth-btn facebook-auth-btn\" expand=\"block\" color=\"facebook\" (click)=\"doFacebookSignup()\">Sign Up with Facebook</ion-button> -->\n    <!-- <ion-button class=\"social-auth-btn google-auth-btn\" expand=\"block\" color=\"google\" (click)=\"doGoogleSignup()\">Sign Up with Google</ion-button> -->\n    <!-- <ion-button class=\"social-auth-btn twitter-auth-btn\" expand=\"block\" color=\"twitter\" (click)=\"doTwitterSignup()\">Sign Up with Twitter</ion-button> -->\n  <!-- </div> -->\n\n  <div class=\"legal-stuff\">\n    创建代表同意昭鸿地产<a class=\"legal-action\" (click)=\"showTermsModal()\">用户协议</a> 、 <a class=\"legal-action\" (click)=\"showPrivacyModal()\">隐私政策</a>.\n  </div>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=pages-signup-signup-module.js.map