(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~pages-allocation-allocation-module~pages-transact-details-transact-details-module"],{

/***/ "KrZc":
/*!********************************************************!*\
  !*** ./src/app/pages/transact/listing/listing.page.ts ***!
  \********************************************************/
/*! exports provided: ListingPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListingPage", function() { return ListingPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_listing_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./listing.page.html */ "mjNH");
/* harmony import */ var _styles_listing_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/listing.page.scss */ "UOlA");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _transact_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../transact.service */ "g/Tr");







let ListingPage = class ListingPage {
    constructor(modalController, transactService, router) {
        this.modalController = modalController;
        this.transactService = transactService;
        this.router = router;
    }
    ngOnInit() {
        if (!this.assignee) {
            return;
        }
        this.transactService.getTransactList(this.assignee).subscribe(res => {
            this.transactList = res;
        });
    }
    dismiss() {
        this.modalController.dismiss();
    }
    onSubmit(values) {
        if (!this.assignee) {
            return;
        }
    }
    toTransact(tr) {
        if (tr) {
            if ((tr === null || tr === void 0 ? void 0 : tr.name) === '楼盘判客') {
                this.router.navigate(['/transact/', tr === null || tr === void 0 ? void 0 : tr.processInstanceId]);
            }
            else if ((tr === null || tr === void 0 ? void 0 : tr.name) === '客服分配') {
                this.router.navigate(['/allocation/', tr === null || tr === void 0 ? void 0 : tr.processInstanceId]);
            }
        }
        this.modalController.dismiss();
    }
};
ListingPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: _transact_service__WEBPACK_IMPORTED_MODULE_6__["TransactService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
];
ListingPage.propDecorators = {
    assignee: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
ListingPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-listing-page',
        template: _raw_loader_listing_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_styles_listing_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ListingPage);



/***/ }),

/***/ "UOlA":
/*!*****************************************************************!*\
  !*** ./src/app/pages/transact/listing/styles/listing.page.scss ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host {\n  --page-margin: var(--app-broad-margin);\n  --page-background: var(--app-background-shade);\n  --page-color: #d9453a;\n}\n\nion-content {\n  position: absolute;\n  top: 0;\n  border-top: calc(var(--app-header-height) + var(--ion-safe-area-top));\n  border-top-style: solid;\n  border-top-color: var(--ion-color-primary);\n}\n\n.open-hours-wrapper {\n  padding: 0px var(--page-margin) var(--page-margin);\n}\n\n.open-hours-wrapper .schedules-list {\n  list-style: none;\n  margin: 0px;\n  padding: 0px;\n}\n\n.open-hours-wrapper .schedules-list .open-hour-item {\n  font-size: 14px;\n  color: var(--ion-color-medium-tint);\n}\n\n.open-hours-wrapper .schedules-list .open-hour-item + .open-hour-item {\n  margin-top: calc(var(--page-margin) / 2);\n}\n\n.open-hours-wrapper .schedules-list .open-hour-item .schedule-outer {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  width: 75%;\n}\n\n.open-hours-wrapper .schedules-list .open-hour-item .schedule-outer .schedule-day {\n  display: block;\n  padding-right: var(--page-margin);\n  width: 40%;\n  font-size: 14px;\n}\n\n.open-hours-wrapper .schedules-list .open-hour-item .schedule-outer .schedule-hours {\n  flex: 1;\n  display: flex;\n  justify-content: flex-end;\n  align-items: center;\n}\n\n.open-hours-wrapper .schedules-list .open-hour-item .schedule-outer .schedule-hours .schedule-separator {\n  margin: 0px var(--page-margin);\n  line-height: 1;\n}\n\n.open-hours-wrapper .schedules-list .open-hour-item .schedule-outer .schedule-hours .schedule-value {\n  font-weight: 500;\n}\n\n.open-hours-wrapper .schedules-list .open-hour-item .schedule-outer .schedule-hours .schedule-value:first-child {\n  text-align: start;\n}\n\n.open-hours-wrapper .schedules-list .open-hour-item .schedule-outer .schedule-hours .schedule-value:last-child {\n  text-align: end;\n}\n\n.open-hours-wrapper .schedules-list .open-hour-item .schedule-outer .schedule-hours .schedule-closed {\n  text-transform: uppercase;\n  font-size: 12px;\n}\n\n.availability-wrapper {\n  padding: calc(var(--page-margin) / 2) var(--page-margin) var(--page-margin);\n}\n\n.availability-wrapper .availability-row {\n  --ion-grid-column-padding: 0px;\n  border-bottom: 2px dashed rgba(var(--ion-color-dark-rgb), 0.1);\n  justify-content: space-between;\n  align-items: center;\n}\n\n.availability-wrapper .availability-row .availability-description,\n.availability-wrapper .availability-row .availability-value {\n  font-size: 14px;\n  color: var(--ion-color-medium-tint);\n  display: block;\n  flex: 1;\n  display: flex;\n}\n\n.availability-wrapper .availability-row .availability-description {\n  color: var(--ion-color-medium-tint);\n  justify-content: flex-start;\n}\n\n.availability-wrapper .availability-row .availability-value {\n  color: var(--page-color);\n  justify-content: flex-end;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL2xpc3RpbmcucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0Usc0NBQUE7RUFDQSw4Q0FBQTtFQUVBLHFCQUFBO0FBRkY7O0FBS0E7RUFDRSxrQkFBQTtFQUNBLE1BQUE7RUFDQSxxRUFBQTtFQUNBLHVCQUFBO0VBQ0EsMENBQUE7QUFGRjs7QUFNQTtFQUNFLGtEQUFBO0FBSEY7O0FBS0U7RUFDRSxnQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBSEo7O0FBS0k7RUFDRSxlQUFBO0VBQ0EsbUNBQUE7QUFITjs7QUFLTTtFQUNFLHdDQUFBO0FBSFI7O0FBTU07RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSw4QkFBQTtFQUNBLFVBQUE7QUFKUjs7QUFNUTtFQUNFLGNBQUE7RUFDQSxpQ0FBQTtFQUNBLFVBQUE7RUFDQSxlQUFBO0FBSlY7O0FBT1E7RUFDRSxPQUFBO0VBQ0EsYUFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7QUFMVjs7QUFPVTtFQUNFLDhCQUFBO0VBQ0EsY0FBQTtBQUxaOztBQVFVO0VBQ0UsZ0JBQUE7QUFOWjs7QUFRWTtFQUNFLGlCQUFBO0FBTmQ7O0FBUVk7RUFDRSxlQUFBO0FBTmQ7O0FBVVU7RUFDRSx5QkFBQTtFQUNBLGVBQUE7QUFSWjs7QUFnQkE7RUFDRSwyRUFBQTtBQWJGOztBQWVFO0VBQ0UsOEJBQUE7RUFHQSw4REFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7QUFmSjs7QUFpQkk7O0VBRUUsZUFBQTtFQUNBLG1DQUFBO0VBQ0EsY0FBQTtFQUNBLE9BQUE7RUFDQSxhQUFBO0FBZk47O0FBa0JJO0VBQ0UsbUNBQUE7RUFDQSwyQkFBQTtBQWhCTjs7QUFtQkk7RUFDRSx3QkFBQTtFQUNBLHlCQUFBO0FBakJOIiwiZmlsZSI6Imxpc3RpbmcucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gQ3VzdG9tIHZhcmlhYmxlc1xuLy8gTm90ZTogIFRoZXNlIG9uZXMgd2VyZSBhZGRlZCBieSB1cyBhbmQgaGF2ZSBub3RoaW5nIHRvIGRvIHdpdGggSW9uaWMgQ1NTIEN1c3RvbSBQcm9wZXJ0aWVzXG46aG9zdCB7XG4gIC0tcGFnZS1tYXJnaW46IHZhcigtLWFwcC1icm9hZC1tYXJnaW4pO1xuICAtLXBhZ2UtYmFja2dyb3VuZDogdmFyKC0tYXBwLWJhY2tncm91bmQtc2hhZGUpO1xuXG4gIC0tcGFnZS1jb2xvcjogI2Q5NDUzYTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMDtcbiAgYm9yZGVyLXRvcDogY2FsYyh2YXIoLS1hcHAtaGVhZGVyLWhlaWdodCkgKyB2YXIoLS1pb24tc2FmZS1hcmVhLXRvcCkpO1xuICBib3JkZXItdG9wLXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLXRvcC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG4vLyBOb3RlOiAgQWxsIHRoZSBDU1MgdmFyaWFibGVzIGRlZmluZWQgYmVsb3cgYXJlIG92ZXJyaWRlcyBvZiBJb25pYyBlbGVtZW50cyBDU1MgQ3VzdG9tIFByb3BlcnRpZXNcbi5vcGVuLWhvdXJzLXdyYXBwZXIge1xuICBwYWRkaW5nOiAwcHggdmFyKC0tcGFnZS1tYXJnaW4pIHZhcigtLXBhZ2UtbWFyZ2luKTtcblxuICAuc2NoZWR1bGVzLWxpc3Qge1xuICAgIGxpc3Qtc3R5bGU6IG5vbmU7XG4gICAgbWFyZ2luOiAwcHg7XG4gICAgcGFkZGluZzogMHB4O1xuXG4gICAgLm9wZW4taG91ci1pdGVtIHtcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtLXRpbnQpO1xuXG4gICAgICAmICsgLm9wZW4taG91ci1pdGVtIHtcbiAgICAgICAgbWFyZ2luLXRvcDogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcbiAgICAgIH1cblxuICAgICAgLnNjaGVkdWxlLW91dGVyIHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgICAgICB3aWR0aDogNzUlO1xuXG4gICAgICAgIC5zY2hlZHVsZS1kYXkge1xuICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICAgIHBhZGRpbmctcmlnaHQ6IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgICAgICAgICB3aWR0aDogNDAlO1xuICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5zY2hlZHVsZS1ob3VycyB7XG4gICAgICAgICAgZmxleDogMTtcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgICAgICAgIC5zY2hlZHVsZS1zZXBhcmF0b3Ige1xuICAgICAgICAgICAgbWFyZ2luOiAwcHggdmFyKC0tcGFnZS1tYXJnaW4pO1xuICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDE7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLnNjaGVkdWxlLXZhbHVlIHtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG5cbiAgICAgICAgICAgICY6Zmlyc3QtY2hpbGQge1xuICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBzdGFydDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgICY6bGFzdC1jaGlsZCB7XG4gICAgICAgICAgICAgIHRleHQtYWxpZ246IGVuZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICAuc2NoZWR1bGUtY2xvc2VkIHtcbiAgICAgICAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gICAgICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbi5hdmFpbGFiaWxpdHktd3JhcHBlciB7XG4gIHBhZGRpbmc6IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMikgdmFyKC0tcGFnZS1tYXJnaW4pIHZhcigtLXBhZ2UtbWFyZ2luKTtcblxuICAuYXZhaWxhYmlsaXR5LXJvdyB7XG4gICAgLS1pb24tZ3JpZC1jb2x1bW4tcGFkZGluZzogMHB4O1xuXG5cbiAgICBib3JkZXItYm90dG9tOiAycHggZGFzaGVkIHJnYmEodmFyKC0taW9uLWNvbG9yLWRhcmstcmdiKSwgLjEpO1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuXG4gICAgLmF2YWlsYWJpbGl0eS1kZXNjcmlwdGlvbixcbiAgICAuYXZhaWxhYmlsaXR5LXZhbHVlIHtcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtLXRpbnQpO1xuICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICBmbGV4OiAxO1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICB9XG5cbiAgICAuYXZhaWxhYmlsaXR5LWRlc2NyaXB0aW9uIHtcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtLXRpbnQpO1xuICAgICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICAgIH1cblxuICAgIC5hdmFpbGFiaWxpdHktdmFsdWUge1xuICAgICAgY29sb3I6IHZhcigtLXBhZ2UtY29sb3IpO1xuICAgICAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbiAgICB9XG4gIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "g/Tr":
/*!****************************************************!*\
  !*** ./src/app/pages/transact/transact.service.ts ***!
  \****************************************************/
/*! exports provided: TransactService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TransactService", function() { return TransactService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "tk/3");



let TransactService = class TransactService {
    constructor(http) {
        this.http = http;
    }
    // public getDetailsDataSource(slug: string): Observable<any> {
    //   const rawDataSource = this.http.get<any>('./assets/sample-data/food/details.json')
    //   .pipe(
    //     mergeMap(details => details.items.filter(item => item.slug === slug)),
    //     map(
    //       (data: FoodDetailsModel) => {
    //         // Note: HttpClient cannot know how to instantiate a class for the returned data
    //         // We need to properly cast types from json data
    //         const details = new FoodDetailsModel();
    //         // The Object.assign() method copies all enumerable own properties from one or more source objects to a target object.
    //         // Note: If you have non-enummerable properties, you can try a spread operator instead. details = {...data};
    //         // (see: https://scotch.io/bar-talk/copying-objects-in-javascript#toc-using-spread-elements-)
    //         Object.assign(details, data);
    //         return details;
    //       }
    //     )
    //   );
    //   // This method tapps into the raw data source and stores the resolved data in the TransferState, then when
    //   // transitioning from the server rendered view to the browser, checks if we already loaded the data in the server to prevent
    //   // duplicate http requests.
    //   const cachedDataSource = this.transferStateHelper.checkDataSourceState('food-details-state', rawDataSource);
    //   return cachedDataSource;
    // }
    // public getDetailsStore(dataSource: Observable<FoodDetailsModel>): DataStore<FoodDetailsModel> {
    //   // Initialize the model specifying that it is a shell model
    //   const shellModel: FoodDetailsModel = new FoodDetailsModel();
    //   this.detailsDataStore = new DataStore(shellModel);
    //   // If running in the server, then don't add shell to the Data Store
    //   // If we already loaded the Data Source in the server, then don't show a shell when transitioning back to the broswer from the server
    //   if (isPlatformServer(this.platformId) || dataSource['ssr_state']) {
    //     // Trigger loading mechanism with 0 delay (this will prevent the shell to be shown)
    //     this.detailsDataStore.load(dataSource, 0);
    //   } else { // On browser transitions
    //     // Trigger the loading mechanism (with shell)
    //     this.detailsDataStore.load(dataSource);
    //   }
    //   return this.detailsDataStore;
    // }
    getCurrentTransact(slug, userId) {
        return this.http.post('/mkt/engine-rest/task', { processInstanceId: slug, assignee: userId })
            .pipe();
    }
    getTransactList(userId) {
        return this.http.post('/mkt/engine-rest/task', { "assignee": userId, "sorting": [{ "sortBy": "dueDate",
                    "sortOrder": "asc"
                }] })
            .pipe();
    }
    getCurrentReferrals(slug) {
        return this.http.get(`/mkt/api/mp/referrals/instance/${slug}`)
            .pipe();
    }
    getTaskCount(userId) {
        return this.http.get('/mkt/engine-rest/task/count', { params: { assignee: userId } })
            .pipe();
    }
    completeTask(taskId, params) {
        return this.http.post(`/mkt/engine-rest/task/${taskId}/complete`, params)
            .pipe();
    }
};
TransactService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
TransactService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], TransactService);



/***/ }),

/***/ "mjNH":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/transact/listing/listing.page.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"dismiss()\">关闭</ion-button>\n    </ion-buttons>\n    <ion-title>\n      办理列表\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"forms-validations-content\">\n\n  <!-- <div class=\"open-hours-wrapper\">\n    <h3 class=\"detail-title\"></h3>\n    <ul class=\"schedules-list\" *ngIf=\"transactList && transactList?.length > 0\">\n      <li class=\"open-hour-item\" *ngFor=\"let tr of transactList\">\n        <div class=\"schedule-outer\">\n          <span class=\"schedule-day\">\n            <app-text-shell [data]=\"tr.name\"></app-text-shell>\n          </span>\n          <div class=\"schedule-hours\">\n              <span class=\"schedule-value\">{{tr.created | appTimeMMDay}}\n              </span>\n              <ion-badge class=\"schedule-closed\" color=\"medium\">closed</ion-badge>\n          </div>\n        </div>\n      </li>\n    </ul>\n  </div> -->\n\n  <div class=\"availability-wrapper\" *ngIf=\"transactList && transactList?.length > 0\">\n    <h3 class=\"detail-title\"></h3>\n    <ion-row class=\"availability-row\" *ngFor=\"let tr of transactList\">\n      <span class=\"availability-description\">\n        <app-text-shell [data]=\"tr.created | appTimeMMDay\"></app-text-shell>\n      </span>\n      <span class=\"availability-value\">\n        <app-text-shell [data]=\"tr.name\"></app-text-shell>\n      </span>\n      <ion-button size=\"small\" class=\"book-now-btn\" color=\"dark\" fill=\"outline\" (click)=\"toTransact(tr)\">立即办理</ion-button>\n    </ion-row>\n  </div>\n  \n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=default~pages-allocation-allocation-module~pages-transact-details-transact-details-module.js.map