(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["customers-details-customers-details-module"],{

/***/ "6g0+":
/*!*********************************************************************************************!*\
  !*** ./node_modules/ngx-ionic-image-viewer/__ivy_ngcc__/fesm2015/ngx-ionic-image-viewer.js ***!
  \*********************************************************************************************/
/*! exports provided: NgxIonicImageViewerComponent, NgxIonicImageViewerDirective, NgxIonicImageViewerModule, NgxIonicImageViewerService, ViewerModalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgxIonicImageViewerComponent", function() { return NgxIonicImageViewerComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgxIonicImageViewerDirective", function() { return NgxIonicImageViewerDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgxIonicImageViewerModule", function() { return NgxIonicImageViewerModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgxIonicImageViewerService", function() { return NgxIonicImageViewerService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewerModalComponent", function() { return ViewerModalComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ "O1h7");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");





/**
 * @fileoverview added by tsickle
 * Generated from: lib/ngx-ionic-image-viewer.service.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */




const _c0 = ["sliderRef"];
const _c1 = function (a0) { return { "no-title": a0 }; };
const _c2 = function (a0) { return { "no-text": a0 }; };
class NgxIonicImageViewerService {
    constructor() { }
}
NgxIonicImageViewerService.ɵfac = function NgxIonicImageViewerService_Factory(t) { return new (t || NgxIonicImageViewerService)(); };
NgxIonicImageViewerService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: NgxIonicImageViewerService, factory: NgxIonicImageViewerService.ɵfac, providedIn: 'root' });
/** @nocollapse */
NgxIonicImageViewerService.ctorParameters = () => [];
/** @nocollapse */ NgxIonicImageViewerService.ngInjectableDef = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"])({ factory: function NgxIonicImageViewerService_Factory() { return new NgxIonicImageViewerService(); }, token: NgxIonicImageViewerService, providedIn: "root" });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgxIonicImageViewerService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], function () { return []; }, null); })();

/**
 * @fileoverview added by tsickle
 * Generated from: lib/viewer-modal/viewer-modal.component.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class ViewerModalComponent {
    /**
     * @param {?} modalController
     */
    constructor(modalController) {
        this.modalController = modalController;
        // tslint:disable: no-inferrable-types
        this.alt = '';
        this.scheme = 'auto';
        this.slideOptions = {};
        this.srcFallback = '';
        this.srcHighRes = '';
        this.swipeToClose = true;
        this.text = '';
        this.title = '';
        this.titleSize = '';
        // tslint:enable: no-inferrable-types
        this.defaultSlideOptions = {
            centeredSlides: true,
            passiveListeners: false,
            zoom: {
                enabled: true,
            },
        };
        this.options = {};
        this.swipeState = {
            phase: 'init',
            direction: 'none',
            swipeType: 'none',
            startX: 0,
            startY: 0,
            distance: 0,
            distanceX: 0,
            distanceY: 0,
            threshold: 150,
            // required min distance traveled to be considered swipe
            restraint: 100,
            // maximum distance allowed at the same time in perpendicular direction
            allowedTime: 500,
            // maximum time allowed to travel that distance
            elapsedTime: 0,
            startTime: 0,
        };
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_1__["__awaiter"])(this, void 0, void 0, function* () {
            this.options = Object.assign({}, this.defaultSlideOptions, this.slideOptions);
            this.src = this.srcHighRes || this.src;
            this.setStyle();
            this.setScheme(this.scheme);
            this.initSwipeToClose(this.swipeToClose);
            /**
             * Current Workaround
             * See reported bug: https://github.com/ionic-team/ionic/issues/19638#issuecomment-584828315
             * Hint: Comment in '<ion-slide>' in component
             * @type {?}
             */
            const swiper = yield this.slides.getSwiper();
            swiper.appendSlide(`<ion-slide><img alt="${this.alt}" src="${this.src}" onerror="this.src='${this.srcFallback}'"/></ion-slide>`);
        });
    }
    /**
     * @return {?}
     */
    setStyle() {
        /** @type {?} */
        const el = document.querySelector('.ion-img-viewer');
        el.style.setProperty('--height', '100%');
        el.style.setProperty('--width', '100%');
        el.style.setProperty('--border-radius', '0');
    }
    /**
     * @param {?} scheme
     * @return {?}
     */
    setScheme(scheme) {
        if (scheme === 'auto') {
            return;
        }
        /** @type {?} */
        const el = document.querySelector('.ion-img-viewer');
        if (this.scheme === 'light') {
            el.style.setProperty('--ion-background-color', '#ffffff');
            el.style.setProperty('--ion-background-color-rgb', '255, 255, 255');
            el.style.setProperty('--ion-text-color', '#000');
            el.style.setProperty('--ion-text-color-rgb', '0,0,0');
        }
        if (this.scheme === 'dark') {
            if (el.classList.contains('ios')) {
                el.style.setProperty('--ion-background-color', '#000000');
                el.style.setProperty('--ion-background-color-rgb', '0, 0, 0');
            }
            else {
                el.style.setProperty('--ion-background-color', '#121212');
                el.style.setProperty('--ion-background-color-rgb', '18,18,18');
            }
            el.style.setProperty('--ion-text-color', '#ffffff');
            el.style.setProperty('--ion-text-color-rgb', '255,255,255');
        }
    }
    /**
     * @see http://www.javascriptkit.com/javatutors/touchevents3.shtml
     * @param {?=} isActive
     * @return {?}
     */
    initSwipeToClose(isActive = true) {
        if (!isActive) {
            return;
        }
        /** @type {?} */
        const el = document.querySelector('ion-modal');
        el.addEventListener('mousedown', (/**
         * @param {?} event
         * @return {?}
         */
        (event) => this.swipeStart(event)), true);
        el.addEventListener('mousemove', (/**
         * @param {?} event
         * @return {?}
         */
        (event) => this.swipeMove(event)), true);
        el.addEventListener('mouseup', (/**
         * @param {?} event
         * @return {?}
         */
        (event) => this.swipeEnd(event)), true);
        el.addEventListener('touchstart', (/**
         * @param {?} event
         * @return {?}
         */
        (event) => this.swipeStart(event)), true);
        el.addEventListener('touchmove', (/**
         * @param {?} event
         * @return {?}
         */
        (event) => this.swipeMove(event)), true);
        el.addEventListener('touchend', (/**
         * @param {?} event
         * @return {?}
         */
        (event) => this.swipeEnd(event)), true);
        this.modalController.getTop().then((/**
         * @param {?} modal
         * @return {?}
         */
        (modal) => {
            modal.onWillDismiss().then((/**
             * @return {?}
             */
            () => {
                document.removeEventListener('mousedown', this.swipeStart, true);
                document.removeEventListener('mousemove', this.swipeMove, true);
                document.removeEventListener('mouseup', this.swipeMove, true);
                document.removeEventListener('touchstart', this.swipeStart, true);
                document.removeEventListener('touchmove', this.swipeMove, true);
                document.removeEventListener('touchend', this.swipeMove, true);
            }));
        }));
    }
    /**
     * @param {?} event
     * @return {?}
     */
    swipeStart(event) {
        const { pageX, pageY } = event.type === 'touchstart' ? event.changedTouches[0] : event;
        this.swipeState = Object.assign({}, this.swipeState, { phase: 'start', direction: 'none', distance: 0, startX: pageX, startY: pageY, startTime: new Date().getTime() });
    }
    /**
     * @param {?} event
     * @return {?}
     */
    swipeMove(event) {
        if (this.swipeState.phase === 'none') {
            return;
        }
        const { pageX, pageY } = event.type === 'touchmove' ? event.changedTouches[0] : event;
        // get horizontal dist traveled by finger while in contact with surface
        /** @type {?} */
        const distanceX = pageX - this.swipeState.startX;
        // get vertical dist traveled by finger while in contact with surface
        /** @type {?} */
        const distanceY = pageY - this.swipeState.startY;
        /** @type {?} */
        let direction;
        /** @type {?} */
        let distance;
        if (Math.abs(distanceX) > Math.abs(distanceY)) {
            // if distance traveled horizontally is greater than vertically, consider this a horizontal swipe
            direction = distanceX < 0 ? 'left' : 'right';
            distance = distanceX;
        }
        else {
            // else consider this a vertical swipe
            direction = distanceY < 0 ? 'up' : 'down';
            distance = distanceY;
        }
        this.swipeState = Object.assign({}, this.swipeState, { phase: 'move', direction,
            distance,
            distanceX,
            distanceY });
        event.preventDefault();
    }
    /**
     * @param {?} event
     * @return {?}
     */
    swipeEnd(event) {
        if (this.swipeState.phase === 'none') {
            return;
        }
        const { allowedTime, direction, restraint, startTime, threshold, distanceX, distanceY } = this.swipeState;
        /** @type {?} */
        let swipeType;
        /** @type {?} */
        const elapsedTime = new Date().getTime() - startTime;
        if (elapsedTime <= allowedTime) {
            // first condition for a swipe met
            if (Math.abs(distanceX) >= threshold && Math.abs(distanceY) <= restraint) {
                // 2nd condition for horizontal swipe met
                swipeType = direction; // set swipeType to either "left" or "right"
            }
            else if (Math.abs(distanceY) >= threshold && Math.abs(distanceX) <= restraint) {
                // 2nd condition for vertical swipe met
                swipeType = direction; // set swipeType to either "top" or "down"
            }
        }
        this.swipeState = Object.assign({}, this.swipeState, { phase: 'end', swipeType });
        if (swipeType === 'down') {
            return this.closeModal();
        }
    }
    /**
     * @return {?}
     */
    closeModal() {
        this.modalController.dismiss();
    }
}
ViewerModalComponent.ɵfac = function ViewerModalComponent_Factory(t) { return new (t || ViewerModalComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"])); };
ViewerModalComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ViewerModalComponent, selectors: [["ion-viewer-modal"]], viewQuery: function ViewerModalComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c0, 3);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.slides = _t.first);
    } }, inputs: { alt: "alt", scheme: "scheme", slideOptions: "slideOptions", srcFallback: "srcFallback", srcHighRes: "srcHighRes", swipeToClose: "swipeToClose", text: "text", title: "title", titleSize: "titleSize", src: "src" }, decls: 14, vars: 11, consts: [[3, "ngClass"], ["slot", "primary"], [3, "click"], ["slot", "icon-only", "name", "close"], [3, "size"], [3, "forceOverscroll"], [3, "options"], ["sliderRef", ""], [1, "ion-text-center"]], template: function ViewerModalComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-header", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "ion-toolbar");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "ion-buttons", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "ion-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ViewerModalComponent_Template_ion_button_click_3_listener() { return ctx.closeModal(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "ion-icon", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "ion-title", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "ion-content", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "ion-slides", 6, 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "ion-footer", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "ion-toolbar", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "ion-text");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](7, _c1, ctx.title.length <= 0));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("size", ctx.titleSize);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.title);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("forceOverscroll", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("options", ctx.options);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](9, _c2, ctx.text.length <= 0));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.text);
    } }, directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonHeader"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgClass"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonToolbar"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonButtons"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonButton"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonIcon"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonTitle"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonContent"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonSlides"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonFooter"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonText"]], styles: ["ion-slides[_ngcontent-%COMP%]{--height:100%;height:100%}ion-toolbar[_ngcontent-%COMP%]{--border-style:none;--background:rgba(var(--ion-background-color-rgb, (255, 255, 255)), 0.6);background:rgba(var(--ion-background-color-rgb,255,255,255),.6)}ion-header[_ngcontent-%COMP%]{opacity:1;position:absolute}ion-header.no-title[_ngcontent-%COMP%]:after{content:none}ion-header.no-title[_ngcontent-%COMP%]   ion-toolbar[_ngcontent-%COMP%]{--background:rgba(0, 0, 0, 0);background:rgba(0,0,0,0)}ion-footer[_ngcontent-%COMP%]{position:absolute;bottom:0}ion-footer.no-text[_ngcontent-%COMP%]:before{content:none}ion-footer.no-text[_ngcontent-%COMP%]   ion-toolbar[_ngcontent-%COMP%]{--background:rgba(0, 0, 0, 0);background:rgba(0,0,0,0)}"] });
/** @nocollapse */
ViewerModalComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
];
ViewerModalComponent.propDecorators = {
    alt: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    scheme: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    slideOptions: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    src: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    srcFallback: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    srcHighRes: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    swipeToClose: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    text: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    titleSize: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"], args: ['sliderRef', { static: true },] }]
};
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ViewerModalComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'ion-viewer-modal',
                template: "<ion-header [ngClass]=\"{ 'no-title': title.length <= 0 }\">\n  <ion-toolbar>\n    <ion-buttons slot=\"primary\">\n      <ion-button (click)=\"closeModal()\">\n        <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title [size]=\"titleSize\">{{ title }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [forceOverscroll]=\"false\">\n  <ion-slides [options]=\"options\" #sliderRef>\n    <!-- <ion-slide>\n      <div class=\"swiper-zoom-container\">\n        <img [alt]=\"this.alt\" [src]=\"this.src\" (error)=\"onError($event)\" />\n      </div>\n    </ion-slide> -->\n  </ion-slides>\n</ion-content>\n\n<ion-footer [ngClass]=\"{ 'no-text': text.length <= 0 }\">\n  <ion-toolbar class=\"ion-text-center\">\n    <ion-text>{{ text }}</ion-text>\n  </ion-toolbar>\n</ion-footer>\n",
                styles: ["ion-slides{--height:100%;height:100%}ion-toolbar{--border-style:none;--background:rgba(var(--ion-background-color-rgb, (255, 255, 255)), 0.6);background:rgba(var(--ion-background-color-rgb,255,255,255),.6)}ion-header{opacity:1;position:absolute}ion-header.no-title:after{content:none}ion-header.no-title ion-toolbar{--background:rgba(0, 0, 0, 0);background:rgba(0,0,0,0)}ion-footer{position:absolute;bottom:0}ion-footer.no-text:before{content:none}ion-footer.no-text ion-toolbar{--background:rgba(0, 0, 0, 0);background:rgba(0,0,0,0)}"]
            }]
    }], function () { return [{ type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }]; }, { alt: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], scheme: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], slideOptions: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], srcFallback: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], srcHighRes: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], swipeToClose: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], text: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], title: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], titleSize: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], src: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], slides: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
            args: ['sliderRef', { static: true }]
        }] }); })();
if (false) {}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/ngx-ionic-image-viewer.component.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgxIonicImageViewerComponent {
    /**
     * @param {?} modalController
     */
    constructor(modalController) {
        this.modalController = modalController;
    }
    /**
     * @param {?} src
     * @param {?=} srcFallback
     * @param {?=} srcHighRes
     * @param {?=} title
     * @param {?=} titleSize
     * @param {?=} text
     * @param {?=} scheme
     * @param {?=} slideOptions
     * @param {?=} swipeToClose
     * @return {?}
     */
    viewImage(src, srcFallback = '', srcHighRes = '', title = '', titleSize = '', text = '', scheme = 'auto', slideOptions = {}, swipeToClose = true) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_1__["__awaiter"])(this, void 0, void 0, function* () {
            /** @type {?} */
            const modal = yield this.modalController.create({
                component: ViewerModalComponent,
                componentProps: {
                    src,
                    srcFallback,
                    srcHighRes,
                    title,
                    titleSize,
                    text,
                    scheme,
                    slideOptions,
                    swipeToClose
                },
                cssClass: this.cssClass instanceof Array ? ['ion-img-viewer', ...this.cssClass] : ['ion-img-viewer', this.cssClass],
                keyboardClose: true,
                showBackdrop: true
            });
            return yield modal.present();
        });
    }
    /**
     * @return {?}
     */
    ngOnInit() { }
}
NgxIonicImageViewerComponent.ɵfac = function NgxIonicImageViewerComponent_Factory(t) { return new (t || NgxIonicImageViewerComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"])); };
NgxIonicImageViewerComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: NgxIonicImageViewerComponent, selectors: [["ion-img-viewer"]], inputs: { alt: "alt", cssClass: "cssClass", scheme: "scheme", slideOptions: "slideOptions", src: "src", srcFallback: "srcFallback", srcHighRes: "srcHighRes", swipeToClose: "swipeToClose", text: "text", title: "title", titleSize: "titleSize" }, decls: 1, vars: 2, consts: [[3, "alt", "src", "click", "error"]], template: function NgxIonicImageViewerComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "img", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function NgxIonicImageViewerComponent_Template_img_click_0_listener() { return ctx.viewImage(ctx.src, ctx.srcFallback, ctx.srcHighRes, ctx.title, ctx.titleSize, ctx.text, ctx.scheme, ctx.slideOptions, ctx.swipeToClose); })("error", function NgxIonicImageViewerComponent_Template_img_error_0_listener() { return ctx.src = ctx.srcFallback; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("alt", ctx.alt)("src", ctx.src, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
    } }, styles: ["[_nghost-%COMP%] {\n        display: block;\n      }"] });
/** @nocollapse */
NgxIonicImageViewerComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
];
NgxIonicImageViewerComponent.propDecorators = {
    alt: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    cssClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    scheme: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    slideOptions: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    src: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    srcFallback: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    srcHighRes: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    swipeToClose: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    text: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    titleSize: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }]
};
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgxIonicImageViewerComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'ion-img-viewer',
                template: "<img\n  [alt]=\"alt\"\n  [src]=\"src\"\n  (click)=\"viewImage(src, srcFallback, srcHighRes, title, titleSize, text, scheme, slideOptions, swipeToClose)\"\n  (error)=\"src = srcFallback\"\n/>\n",
                encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewEncapsulation"].Emulated,
                styles: [`
      :host {
        display: block;
      }
    `]
            }]
    }], function () { return [{ type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }]; }, { alt: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], cssClass: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], scheme: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], slideOptions: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], src: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], srcFallback: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], srcHighRes: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], swipeToClose: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], text: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], title: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], titleSize: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();
if (false) {}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/ngx-ionic-image-viewer.directive.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgxIonicImageViewerDirective {
    /**
     * @param {?} el
     * @param {?} renderer
     * @param {?} modalController
     */
    constructor(el, renderer, modalController) {
        this.el = el;
        this.renderer = renderer;
        this.modalController = modalController;
    }
    /**
     * @return {?}
     */
    onClick() {
        this.viewImage(this.src, this.srcFallback, this.srcHighRes, this.title, this.titleSize, this.text, this.scheme, this.slideOptions, this.swipeToClose);
    }
    /**
     * @param {?} error
     * @return {?}
     */
    onError(error) {
        if (this.src !== this.el.nativeElement.src) {
            this.src = this.el.nativeElement.src;
        }
        if (this.srcFallback) {
            this.renderer.setAttribute(this.el.nativeElement, 'src', this.srcFallback);
        }
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        if (!this.el.nativeElement.hasAttribute('src')) {
            this.renderer.setAttribute(this.el.nativeElement, 'src', this.src);
        }
    }
    /**
     * @param {?} src
     * @param {?=} srcFallback
     * @param {?=} srcHighRes
     * @param {?=} title
     * @param {?=} titleSize
     * @param {?=} text
     * @param {?=} scheme
     * @param {?=} slideOptions
     * @param {?=} swipeToClose
     * @return {?}
     */
    viewImage(src, srcFallback = '', srcHighRes = '', title = '', titleSize = '', text = '', scheme = 'auto', slideOptions = {}, swipeToClose = true) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_1__["__awaiter"])(this, void 0, void 0, function* () {
            /** @type {?} */
            const modal = yield this.modalController.create({
                component: ViewerModalComponent,
                componentProps: {
                    src,
                    srcFallback,
                    srcHighRes,
                    title,
                    titleSize,
                    text,
                    scheme,
                    slideOptions,
                    swipeToClose
                },
                cssClass: this.cssClass instanceof Array ? ['ion-img-viewer', ...this.cssClass] : ['ion-img-viewer', this.cssClass],
                keyboardClose: true,
                showBackdrop: true
            });
            return yield modal.present();
        });
    }
}
NgxIonicImageViewerDirective.ɵfac = function NgxIonicImageViewerDirective_Factory(t) { return new (t || NgxIonicImageViewerDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["Renderer2"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"])); };
NgxIonicImageViewerDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: NgxIonicImageViewerDirective, selectors: [["", "ionImgViewer", ""]], hostBindings: function NgxIonicImageViewerDirective_HostBindings(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function NgxIonicImageViewerDirective_click_HostBindingHandler() { return ctx.onClick(); })("error", function NgxIonicImageViewerDirective_error_HostBindingHandler($event) { return ctx.onError($event); });
    } }, inputs: { src: "src", cssClass: "cssClass", scheme: "scheme", slideOptions: "slideOptions", srcFallback: "srcFallback", srcHighRes: "srcHighRes", swipeToClose: "swipeToClose", text: "text", title: "title", titleSize: "titleSize" } });
/** @nocollapse */
NgxIonicImageViewerDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Renderer2"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
];
NgxIonicImageViewerDirective.propDecorators = {
    cssClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    scheme: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    slideOptions: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    src: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    srcFallback: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    srcHighRes: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    swipeToClose: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    text: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    titleSize: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    onClick: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"], args: ['click',] }],
    onError: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"], args: ['error', ['$event'],] }]
};
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgxIonicImageViewerDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{
                selector: '[ionImgViewer]'
            }]
    }], function () { return [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Renderer2"] }, { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }]; }, { 
    /**
     * @return {?}
     */
    onClick: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"],
            args: ['click']
        }], 
    /**
     * @param {?} error
     * @return {?}
     */
    onError: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"],
            args: ['error', ['$event']]
        }], src: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], cssClass: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], scheme: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], slideOptions: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], srcFallback: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], srcHighRes: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], swipeToClose: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], text: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], title: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], titleSize: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();
if (false) {}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/ngx-ionic-image-viewer.module.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgxIonicImageViewerModule {
}
NgxIonicImageViewerModule.ɵfac = function NgxIonicImageViewerModule_Factory(t) { return new (t || NgxIonicImageViewerModule)(); };
NgxIonicImageViewerModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: NgxIonicImageViewerModule });
NgxIonicImageViewerModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](NgxIonicImageViewerModule, { declarations: function () { return [NgxIonicImageViewerComponent, NgxIonicImageViewerDirective, ViewerModalComponent]; }, imports: function () { return [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"]]; }, exports: function () { return [NgxIonicImageViewerComponent, NgxIonicImageViewerDirective, ViewerModalComponent]; } }); })();
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgxIonicImageViewerModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                declarations: [NgxIonicImageViewerComponent, NgxIonicImageViewerDirective, ViewerModalComponent],
                imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"]],
                entryComponents: [ViewerModalComponent],
                exports: [NgxIonicImageViewerComponent, NgxIonicImageViewerDirective, ViewerModalComponent]
            }]
    }], null, null); })();

/**
 * @fileoverview added by tsickle
 * Generated from: public-api.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * Generated from: ngx-ionic-image-viewer.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */



//# sourceMappingURL=ngx-ionic-image-viewer.js.map

/***/ }),

/***/ "8h23":
/*!********************************************************************!*\
  !*** ./src/app/pages/customers/instance/styles/instance.page.scss ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host {\n  --page-margin: var(--app-broad-margin);\n  --page-background: var(--app-background-shade);\n  --page-pictures-gutter: calc(var(--page-margin) / 4);\n}\n\n.legal-content {\n  --background: var(--page-background);\n  --padding-start: var(--page-margin);\n  --padding-end: var(--page-margin);\n  --padding-top: var(--page-margin);\n  --padding-bottom: var(--page-margin);\n}\n\n.legal-content .legal-title {\n  color: var(--ion-color-secondary);\n  margin: var(--page-margin) 0px calc(var(--page-margin) / 2);\n}\n\n.legal-content .legal-text {\n  color: var(--ion-color-medium);\n  margin: calc(var(--page-margin) / 2) 0px var(--page-margin);\n  font-size: 14px;\n  line-height: 20px;\n  text-align: justify;\n}\n\n.legal-content ion-item-divider {\n  --background: var(--page-background);\n  --padding-start: var(--page-margin);\n  --padding-top: calc(var(--page-margin) * 2);\n}\n\n.legal-content .notification-item {\n  --padding-start: 0px;\n  --inner-padding-end: 0px;\n  --background: var(--page-background);\n  padding: var(--page-margin);\n  color: var(--ion-color-medium);\n  box-shadow: inset 0 8px 2px -9px var(--ion-color-darkest);\n}\n\n.legal-content .notification-item .notification-item-wrapper {\n  --ion-grid-column-padding: 0px;\n  width: 100%;\n  align-items: center;\n}\n\n.legal-content .notification-item .details-wrapper {\n  display: flex;\n  flex-direction: column;\n  justify-content: space-around;\n  padding-left: var(--page-margin);\n}\n\n.legal-content .notification-item .details-wrapper .details-name {\n  margin-top: 0px;\n  margin-bottom: 5px;\n  font-size: 16px;\n  font-weight: 400;\n  letter-spacing: 0.2px;\n  color: var(--ion-color-secondary);\n}\n\n.legal-content .notification-item .details-wrapper .details-description {\n  font-size: 12px;\n  margin: 0px;\n}\n\n.legal-content .notification-item .date-wrapper {\n  align-self: flex-start;\n}\n\n.legal-content .notification-item .date-wrapper .notification-date {\n  margin: 0px;\n  font-size: 12px;\n  text-align: end;\n}\n\n.legal-content .notification-item .date-wrapper .notification-description {\n  font-size: 12px;\n  margin: 0px;\n  text-align: end;\n}\n\n.legal-content .related-activities-wrapper {\n  padding: 0px 0px calc(var(--page-margin) * 2);\n}\n\n.legal-content .related-activities-wrapper .related-activity {\n  --ion-grid-column-padding: 0px;\n}\n\n.legal-content .related-activities-wrapper .related-activity:not(:last-child) {\n  margin-bottom: var(--page-margin);\n}\n\n.legal-content .related-activities-wrapper .related-activity .activity-details {\n  position: relative;\n}\n\n.legal-content .related-activities-wrapper .related-activity .activity-details .activity-name {\n  margin: 0px;\n  margin-top: 5px;\n  font-size: 14px;\n}\n\n.legal-content .related-activities-wrapper .related-activity .activity-details .activity-name .type {\n  color: #2b17e2;\n}\n\n.legal-content .related-activities-wrapper .related-activity .activity-details .activity-category {\n  display: block;\n  margin-top: 2px;\n  font-size: 10px;\n}\n\n.legal-content .related-activities-wrapper .related-activity .activity-details .activity-rating {\n  position: absolute;\n  top: 0;\n  right: 0;\n  margin-top: 5px;\n  margin-right: var(--page-margin);\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.legal-content .related-activities-wrapper .related-activity .activity-details .activity-rating .rating-icon {\n  color: var(--page-color);\n}\n\n.legal-content .related-activities-wrapper .related-activity .activity-details .activity-rating .rating-value {\n  color: var(--page-color);\n  font-size: 14px;\n  margin-left: 4px;\n}\n\n.legal-content .related-activities-wrapper .related-activity .picture-wrapper {\n  --col-item-width: 4;\n  flex: 0 0 calc(calc(var(--col-item-width) / var(--ion-grid-columns, 12)) * 100%);\n  width: calc(calc(var(--col-item-width) / var(--ion-grid-columns, 12)) * 100%);\n  max-width: calc(calc(var(--col-item-width) / var(--ion-grid-columns, 12)) * 100%);\n  padding: 0px var(--page-pictures-gutter);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL2luc3RhbmNlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQTtFQUNFLHNDQUFBO0VBQ0EsOENBQUE7RUFFQSxvREFBQTtBQUZGOztBQU1BO0VBQ0Usb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsaUNBQUE7RUFDQSxvQ0FBQTtBQUhGOztBQUtFO0VBQ0UsaUNBQUE7RUFDQSwyREFBQTtBQUhKOztBQU1FO0VBQ0UsOEJBQUE7RUFDQSwyREFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0FBSko7O0FBT0U7RUFDRSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsMkNBQUE7QUFMSjs7QUFRRTtFQUNFLG9CQUFBO0VBQ0Esd0JBQUE7RUFDQSxvQ0FBQTtFQUVBLDJCQUFBO0VBQ0EsOEJBQUE7RUFDQSx5REFBQTtBQVBKOztBQVNJO0VBQ0UsOEJBQUE7RUFFQSxXQUFBO0VBQ0EsbUJBQUE7QUFSTjs7QUFXSTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLDZCQUFBO0VBQ0EsZ0NBQUE7QUFUTjs7QUFXTTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDRCxnQkFBQTtFQUNBLHFCQUFBO0VBQ0EsaUNBQUE7QUFUUDs7QUFZTTtFQUNFLGVBQUE7RUFDQSxXQUFBO0FBVlI7O0FBY0k7RUFDRSxzQkFBQTtBQVpOOztBQWNNO0VBQ0UsV0FBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0FBWlI7O0FBZU07RUFDRSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7QUFiUjs7QUFrQkU7RUFDRSw2Q0FBQTtBQWhCSjs7QUFrQkk7RUFDRSw4QkFBQTtBQWhCTjs7QUFrQk07RUFDRSxpQ0FBQTtBQWhCUjs7QUFtQk07RUFFRSxrQkFBQTtBQWxCUjs7QUFvQlE7RUFDRSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7QUFsQlY7O0FBb0JVO0VBQ0UsY0FBQTtBQWxCWjs7QUFzQlE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7QUFwQlY7O0FBdUJRO0VBQ0Usa0JBQUE7RUFDQSxNQUFBO0VBQ0EsUUFBQTtFQUNBLGVBQUE7RUFDQSxnQ0FBQTtFQUVBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBdEJWOztBQXdCVTtFQUNFLHdCQUFBO0FBdEJaOztBQXlCVTtFQUNFLHdCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBdkJaOztBQTRCTTtFQUNFLG1CQUFBO0VBRUEsZ0ZBQUE7RUFDQSw2RUFBQTtFQUNBLGlGQUFBO0VBRUEsd0NBQUE7QUE1QlIiLCJmaWxlIjoiaW5zdGFuY2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gQ3VzdG9tIHZhcmlhYmxlc1xuLy8gTm90ZTogIFRoZXNlIG9uZXMgd2VyZSBhZGRlZCBieSB1cyBhbmQgaGF2ZSBub3RoaW5nIHRvIGRvIHdpdGggSW9uaWMgQ1NTIEN1c3RvbSBQcm9wZXJ0aWVzXG46aG9zdCB7XG4gIC0tcGFnZS1tYXJnaW46IHZhcigtLWFwcC1icm9hZC1tYXJnaW4pO1xuICAtLXBhZ2UtYmFja2dyb3VuZDogdmFyKC0tYXBwLWJhY2tncm91bmQtc2hhZGUpO1xuXG4gIC0tcGFnZS1waWN0dXJlcy1ndXR0ZXI6IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gNCk7XG59XG5cbi8vIE5vdGU6ICBBbGwgdGhlIENTUyB2YXJpYWJsZXMgZGVmaW5lZCBiZWxvdyBhcmUgb3ZlcnJpZGVzIG9mIElvbmljIGVsZW1lbnRzIENTUyBDdXN0b20gUHJvcGVydGllc1xuLmxlZ2FsLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHZhcigtLXBhZ2UtYmFja2dyb3VuZCk7XG4gIC0tcGFkZGluZy1zdGFydDogdmFyKC0tcGFnZS1tYXJnaW4pO1xuICAtLXBhZGRpbmctZW5kOiB2YXIoLS1wYWdlLW1hcmdpbik7XG4gIC0tcGFkZGluZy10b3A6IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgLS1wYWRkaW5nLWJvdHRvbTogdmFyKC0tcGFnZS1tYXJnaW4pO1xuXG4gIC5sZWdhbC10aXRsZSB7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xuICAgIG1hcmdpbjogdmFyKC0tcGFnZS1tYXJnaW4pIDBweCBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDIpO1xuICB9XG5cbiAgLmxlZ2FsLXRleHQge1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbiAgICBtYXJnaW46IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMikgMHB4IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgbGluZS1oZWlnaHQ6IDIwcHg7XG4gICAgdGV4dC1hbGlnbjoganVzdGlmeTtcbiAgfVxuXG4gIGlvbi1pdGVtLWRpdmlkZXIge1xuICAgIC0tYmFja2dyb3VuZDogdmFyKC0tcGFnZS1iYWNrZ3JvdW5kKTtcbiAgICAtLXBhZGRpbmctc3RhcnQ6IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgICAtLXBhZGRpbmctdG9wOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAqIDIpO1xuICB9XG5cbiAgLm5vdGlmaWNhdGlvbi1pdGVtIHtcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDBweDtcbiAgICAtLWlubmVyLXBhZGRpbmctZW5kOiAwcHg7XG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1wYWdlLWJhY2tncm91bmQpO1xuXG4gICAgcGFkZGluZzogdmFyKC0tcGFnZS1tYXJnaW4pO1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbiAgICBib3gtc2hhZG93OiBpbnNldCAwIDhweCAycHggLTlweCB2YXIoLS1pb24tY29sb3ItZGFya2VzdCk7XG5cbiAgICAubm90aWZpY2F0aW9uLWl0ZW0td3JhcHBlciB7XG4gICAgICAtLWlvbi1ncmlkLWNvbHVtbi1wYWRkaW5nOiAwcHg7XG5cbiAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICB9XG5cbiAgICAuZGV0YWlscy13cmFwcGVyIHtcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XG4gICAgICBwYWRkaW5nLWxlZnQ6IHZhcigtLXBhZ2UtbWFyZ2luKTtcblxuICAgICAgLmRldGFpbHMtbmFtZSB7XG4gICAgICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICAgICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICBcdGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgICBcdGxldHRlci1zcGFjaW5nOiAwLjJweDtcbiAgICAgIFx0Y29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xuICAgICAgfVxuXG4gICAgICAuZGV0YWlscy1kZXNjcmlwdGlvbiB7XG4gICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgbWFyZ2luOiAwcHg7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLmRhdGUtd3JhcHBlciB7XG4gICAgICBhbGlnbi1zZWxmOiBmbGV4LXN0YXJ0O1xuXG4gICAgICAubm90aWZpY2F0aW9uLWRhdGUge1xuICAgICAgICBtYXJnaW46IDBweDtcbiAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICB0ZXh0LWFsaWduOiBlbmQ7XG4gICAgICB9XG5cbiAgICAgIC5ub3RpZmljYXRpb24tZGVzY3JpcHRpb24ge1xuICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgIG1hcmdpbjogMHB4O1xuICAgICAgICB0ZXh0LWFsaWduOiBlbmQ7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLnJlbGF0ZWQtYWN0aXZpdGllcy13cmFwcGVyIHtcbiAgICBwYWRkaW5nOiAwcHggMHB4IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pICogMik7XG5cbiAgICAucmVsYXRlZC1hY3Rpdml0eSB7XG4gICAgICAtLWlvbi1ncmlkLWNvbHVtbi1wYWRkaW5nOiAwcHg7XG5cbiAgICAgICY6bm90KDpsYXN0LWNoaWxkKSB7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgICAgIH1cblxuICAgICAgLmFjdGl2aXR5LWRldGFpbHMge1xuICAgICAgICAvLyB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcblxuICAgICAgICAuYWN0aXZpdHktbmFtZSB7XG4gICAgICAgICAgbWFyZ2luOiAwcHg7XG4gICAgICAgICAgbWFyZ2luLXRvcDogNXB4O1xuICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcblxuICAgICAgICAgIC50eXBle1xuICAgICAgICAgICAgY29sb3I6IHJnYig0MywgMjMsIDIyNik7XG4gICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAuYWN0aXZpdHktY2F0ZWdvcnkge1xuICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICAgIG1hcmdpbi10b3A6IDJweDtcbiAgICAgICAgICBmb250LXNpemU6IDEwcHg7XG4gICAgICAgIH1cblxuICAgICAgICAuYWN0aXZpdHktcmF0aW5nIHtcbiAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgdG9wOiAwO1xuICAgICAgICAgIHJpZ2h0OiAwO1xuICAgICAgICAgIG1hcmdpbi10b3A6IDVweDtcbiAgICAgICAgICBtYXJnaW4tcmlnaHQ6IHZhcigtLXBhZ2UtbWFyZ2luKTtcblxuICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgICAgICAgIC5yYXRpbmctaWNvbiB7XG4gICAgICAgICAgICBjb2xvcjogdmFyKC0tcGFnZS1jb2xvcik7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLnJhdGluZy12YWx1ZSB7XG4gICAgICAgICAgICBjb2xvcjogdmFyKC0tcGFnZS1jb2xvcik7XG4gICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogNHB4O1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAucGljdHVyZS13cmFwcGVyIHtcbiAgICAgICAgLS1jb2wtaXRlbS13aWR0aDogNDtcbiAgICAgICAgLy8gU1NSIGZpeDogT3ZlcnJpZGUgaW9uLWNvbCBzdHlsZXNcbiAgICAgICAgZmxleDogMCAwIGNhbGMoY2FsYyh2YXIoLS1jb2wtaXRlbS13aWR0aCkgLyB2YXIoLS1pb24tZ3JpZC1jb2x1bW5zLCAxMikpICogMTAwJSk7XG4gICAgICAgIHdpZHRoOiBjYWxjKGNhbGModmFyKC0tY29sLWl0ZW0td2lkdGgpIC8gdmFyKC0taW9uLWdyaWQtY29sdW1ucywgMTIpKSAqIDEwMCUpO1xuICAgICAgICBtYXgtd2lkdGg6IGNhbGMoY2FsYyh2YXIoLS1jb2wtaXRlbS13aWR0aCkgLyB2YXIoLS1pb24tZ3JpZC1jb2x1bW5zLCAxMikpICogMTAwJSk7XG4gIFxuICAgICAgICBwYWRkaW5nOiAwcHggdmFyKC0tcGFnZS1waWN0dXJlcy1ndXR0ZXIpO1xuICAgICAgICBcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "9I/D":
/*!*******************************************************************!*\
  !*** ./src/app/pages/customers/track-record/track-record.page.ts ***!
  \*******************************************************************/
/*! exports provided: TrackRecordPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TrackRecordPage", function() { return TrackRecordPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_track_record_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./track-record.page.html */ "e8CX");
/* harmony import */ var _styles_track_record_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/track-record.page.scss */ "lDzJ");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _app_core_service_uploader_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @app/core/_service/uploader.service */ "0Fbw");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var compressorjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! compressorjs */ "fI17");
/* harmony import */ var compressorjs__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(compressorjs__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _customers_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../customers.service */ "adrT");












let TrackRecordPage = class TrackRecordPage {
    constructor(modalController, uploadService, loadingController, customersService) {
        this.modalController = modalController;
        this.uploadService = uploadService;
        this.loadingController = loadingController;
        this.customersService = customersService;
        this.singleLoading = false;
        this.multiple = 1;
        this.validations = {
            'take_bill': [
                { type: 'required', message: '不能为空，请上传相关跟办图片详情' }
            ],
            'details': [
                { type: 'required', message: '内容不能为空' }
            ],
            'handle_type': [
                { type: 'required', message: '需选择一项.' }
            ],
        };
    }
    ngOnInit() {
        this.handleTypes = [
            '跟办',
            '来访/带看（需审核）',
            '成交确认（需审核）'
        ];
        this.validationsForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            'take_bill': new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"]([]),
            'details': new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required),
            'handle_type': new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required),
        });
    }
    presentLoader() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.loadingElement = yield this.loadingController.create({
                message: '加载中 ...'
            });
            yield this.loadingElement.present();
            const { role, data } = yield this.loadingElement.onDidDismiss();
            this.singleLoading = false;
        });
    }
    dismissLoader() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.loadingElement) {
                yield this.loadingElement.dismiss();
            }
        });
    }
    get f() { return this.validationsForm.controls; }
    dismiss() {
        this.modalController.dismiss();
    }
    // passDismiss() {
    //   // using the injected ModalController this page
    //   // can "dismiss" itself and optionally pass back data
    //   this.modalController.dismiss({
    //       'intention': this.intention
    //   });
    // }
    onSubmit(values) {
        if (!this.referralsId || !this.f.take_bill.value[0].link) {
            return;
        }
        // this.f.take_bill
        let picUrls = [];
        this.f.take_bill.value.forEach(element => {
            element.link ? picUrls.push(element.link) : '';
        });
        this.customersService.addTrackRecord(this.userId, this.referralsId, picUrls, this.f.details.value, this.handleTypes.indexOf(this.f.handle_type.value) || 0).subscribe(res => {
            if (res.ok) {
                this.modalController.dismiss();
                //   this.intention = res.data;
                //   this.modalController.dismiss({
                //     'intention': this.intention
                // });
            }
        });
    }
    ImageChange(params) {
        const { files, type, index } = params;
        // this.files = files;
    }
    fileChange(params) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const { files, operationType, index } = params;
            const pu = (fd) => {
                const uplodfile = { data: fd, inProgress: false, progress: 0, index: index };
                this.uploadFile(uplodfile);
            };
            if (!files[index])
                return;
            switch (operationType) {
                case 'add':
                    new compressorjs__WEBPACK_IMPORTED_MODULE_10___default.a(this.dataURItoBlob(files[index].url), {
                        quality: 0.6,
                        convertSize: 500000,
                        success(result) {
                            const formData = new FormData();
                            formData.append('file', result);
                            formData.append('dir', 'comment');
                            formData.append('fileType', 'image');
                            pu(formData);
                        },
                        error(err) {
                            console.log(err.message);
                        },
                    });
                    break;
                case 'remove':
                    break;
                default:
                    break;
            }
        });
    }
    uploadFile(file) {
        file.inProgress = true;
        if (this.singleLoading === false) {
            this.presentLoader();
            this.singleLoading = true;
        }
        this.uploadService.upload(file.data).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["map"])(event => {
            switch (event.type) {
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpEventType"].UploadProgress:
                    file.progress = Math.round(event.loaded * 100 / event.total);
                    break;
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpEventType"].Response:
                    this.f.take_bill.value[file.index].link = event.body.link;
                    this.dismissLoader();
                    return event;
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["catchError"])((error) => {
            file.inProgress = false;
            this.dismissLoader();
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_8__["of"])(`${file.data.name} upload failed.`);
        })).subscribe((event) => {
            if (typeof (event) === 'object') {
                console.log(event.body);
            }
        });
    }
    dataURItoBlob(dataURI) {
        // convert base64/URLEncoded data component to raw binary data held in a string
        let byteString;
        if (dataURI.split(',')[0].indexOf('base64') >= 0) {
            byteString = atob(dataURI.split(',')[1]);
        }
        else {
            byteString = unescape(dataURI.split(',')[1]);
        }
        // separate out the mime component
        const mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
        // write the bytes of the string to a typed array
        const ia = new Uint8Array(byteString.length);
        for (let i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }
        return new Blob([ia], { type: mimeString });
    }
    imageClick(params) {
        console.log(params);
    }
};
TrackRecordPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"] },
    { type: _app_core_service_uploader_service__WEBPACK_IMPORTED_MODULE_6__["UploadService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["LoadingController"] },
    { type: _customers_service__WEBPACK_IMPORTED_MODULE_11__["CustomersService"] }
];
TrackRecordPage.propDecorators = {
    referralsId: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"] }],
    userId: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"] }]
};
TrackRecordPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-track-record',
        template: _raw_loader_track_record_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_styles_track_record_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TrackRecordPage);



/***/ }),

/***/ "Fy7a":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/customers/details/customers-details.page.html ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <!-- <ion-menu-button color=\"light\"></ion-menu-button> -->\n      <ion-back-button defaultHref=\"app/referrals\" text=\"\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"contact-card-content\">\n  <ion-row class=\"user-details-wrapper\">\n    <ion-col size=\"4\">\n      <app-aspect-ratio [ratio]=\"{w: 1, h: 1}\">\n        <app-image-shell class=\"user-avatar\" animation=\"spinner\"\n          [src]=\"'./assets/sample-images/notifications/notification.jpg'\" [alt]=\"'image'\"></app-image-shell>\n      </app-aspect-ratio>\n    </ion-col>\n    <ion-col class=\"user-info-wrapper\" size=\"8\">\n      <h3 class=\"user-name\">{{referralsDetails?.customerName}}</h3>\n      <h5 class=\"user-handle\">{{referralsDetails?.phone}}</h5>\n    </ion-col>\n    <!-- <ion-col class=\"user-stats-wrapper\" size=\"6\">\n      <span class=\"user-stat-value\">1553</span>\n      <span class=\"user-stat-name\">Following</span>\n    </ion-col>\n    <ion-col class=\"user-stats-wrapper\" size=\"6\">\n      <span class=\"user-stat-value\">537</span>\n      <span class=\"user-stat-name\">Followers</span>\n    </ion-col>\n    <ion-col size=\"12\">\n      <p class=\"user-bio\">\n        I am a product and visual designer based in Uruguay. I have designed at Google, Amazon and Microsoft.\n      </p>\n    </ion-col> -->\n    <!-- <ion-col size=\"12\">\n      <h4 class=\"preference-name\">电话</h4>\n      <p class=\"preference-value\">\n        {{referralsDetails?.phone}}\n      </p>\n    </ion-col> -->\n    <!-- <ion-col size=\"12\">\n      <h4 class=\"preference-name\">Email</h4>\n      <p class=\"preference-value\">\n        clairhale@ionic.com\n      </p>\n    </ion-col> -->\n    <ion-col size=\"12\">\n      <p class=\"user-bio\">\n        {{referralsDetails?.description}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <p class=\"user-bio\">\n        客户首次推荐日期: {{referralsDetails?.createTime}}\n      </p>\n      <p class=\"user-bio\">\n        最新跟办日期: {{referralsDetails?.updateTime}}\n      </p>\n    </ion-col>\n  </ion-row>\n  <!-- <ion-row class=\"user-preferences-wrapper\">\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">Mobile</h4>\n      <p class=\"preference-value\">\n        +1-202-555-0102\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">Email</h4>\n      <p class=\"preference-value\">\n        clairhale@ionic.com\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">Address</h4>\n      <p class=\"preference-value\">\n        921 Church St, San Francisco, CA\n        <br/>\n        94114, USA\n      </p>\n    </ion-col>\n  </ion-row> -->\n\n  <div class=\"related-deals-wrapper\" *ngIf=\"referralsDetails?.transactionsDTOS && referralsDetails.transactionsDTOS.length > 0\">\n    <!-- <h3 class=\"related-deals-title\">More hot deals</h3> -->\n    <ion-row class=\"related-deal\" *ngFor=\"let deal of referralsDetails.transactionsDTOS\">\n      <ion-col class=\"deal-logo-wrapper\" size=\"3\">\n        <app-aspect-ratio [ratio]=\"{w: 1, h: 1}\">\n          <app-image-shell [src]=\"deal?.firstFigure\" [alt]=\"'deals logo'\" class=\"related-deal-logo\" animation=\"spinner\"></app-image-shell>\n        </app-aspect-ratio>\n      </ion-col>\n      <ion-col class=\"deal-info-wrapper\" size=\"6\">\n        <h4 class=\"related-deal-title\">\n          <app-text-shell [data]=\"deal?.projectName\"></app-text-shell>\n        </h4>\n        <p class=\"related-deal-description\">\n          {{deal?.currentHandler}} \n          <span class=\"status\" *ngIf=\"deal?.currentStatus\">「{{deal?.currentStatus==='0'?'跟办中':(deal?.currentStatus==='1'?'已来访':'已成交')}}」</span>\n          <!-- <app-text-shell [data]=\"deal?.currentHandler\"></app-text-shell> -->\n        </p>\n      </ion-col>\n      <!-- <ion-col class=\"deal-info-wrapper\" size=\"2\">\n        <h4 class=\"related-deal-title\">\n          <app-text-shell [data]=\"deal?.projectName\"></app-text-shell>\n        </h4>\n        <p class=\"related-deal-description\">\n          <app-text-shell [data]=\"deal?.currentHandler\"></app-text-shell>\n        </p>\n      </ion-col> -->\n      <ion-col class=\"stats-col\" size=\"2\">\n        <span class=\"item-rating\" [attr.ratingBase]=\"deal.grade ? deal.grade : 'S'\" (click)=\"presentModal(deal?.instanceId)\" >\n          <app-text-shell [data]=\"'详情'\"></app-text-shell>\n        </span>\n        <!-- <div class=\"item-price-range\"> -->\n        <!-- <div class=\"item-price-range\" *ngIf=\"deal?.substitute === '0' && (!this.userRole || this.userRole === '' || this.userRole === 'salesman')\">\n          <span class=\"price\" (click)=\"presentTrackModal()\"> 跟办 </span> -->\n          <!-- <span class=\"price\">{{deal?.substitute === '0' ? '帮带看': (deal?.substitute === '1' ? '自行带看': '陪同')}}</span> -->\n          <!-- <span class=\"no-price\" *ngFor=\"let price of [].constructor(5 - (item.priceRange || 1))\">$</span> -->\n        <!-- </div> -->\n        <div class=\"item-price-range\" *ngIf=\"deal?.name !== '楼盘判客'\">\n          <span class=\"price\" (click)=\"presentTrackModal(deal?.id)\"> 跟办 </span>\n        </div>\n      </ion-col>\n    </ion-row>\n  </div>\n</ion-content>");

/***/ }),

/***/ "Ktgh":
/*!*******************************************************************!*\
  !*** ./src/app/pages/customers/details/customers-details.page.ts ***!
  \*******************************************************************/
/*! exports provided: CustomersDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomersDetailsPage", function() { return CustomersDetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_customers_details_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./customers-details.page.html */ "Fy7a");
/* harmony import */ var _styles_customers_details_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/customers-details.page.scss */ "geym");
/* harmony import */ var _styles_customers_details_shell_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./styles/customers-details.shell.scss */ "f+TS");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _customers_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../customers.service */ "adrT");
/* harmony import */ var _instance_instance_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../instance/instance.page */ "g34P");
/* harmony import */ var _track_record_track_record_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../track-record/track-record.page */ "9I/D");










let CustomersDetailsPage = class CustomersDetailsPage {
    constructor(route, customersService, routerOutlet, modalController) {
        this.customersService = customersService;
        this.routerOutlet = routerOutlet;
        this.modalController = modalController;
        this.referralId = route.snapshot.params['referralId'];
        this.userRole = localStorage.getItem('userRole');
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.customersService.getByRelated(this.referralId).subscribe(res => {
            //
            if (res.ok) {
                this.referralsDetails = res.data;
            }
        });
    }
    presentModal(ins) {
        var _a;
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _instance_instance_page__WEBPACK_IMPORTED_MODULE_8__["InstancePage"],
                swipeToClose: true,
                presentingElement: this.routerOutlet.nativeEl,
                componentProps: {
                    'instanceId': ins,
                    'userId': (_a = this.currentUser) === null || _a === void 0 ? void 0 : _a.mktUserId
                }
            });
            // return await modal.present();
            yield modal.present();
        });
    }
    presentTrackModal(referralId) {
        var _a;
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _track_record_track_record_page__WEBPACK_IMPORTED_MODULE_9__["TrackRecordPage"],
                swipeToClose: true,
                presentingElement: this.routerOutlet.nativeEl,
                componentProps: {
                    'referralsId': referralId,
                    'userId': (_a = this.currentUser) === null || _a === void 0 ? void 0 : _a.mktUserId
                }
            });
            // return await modal.present();
            yield modal.present();
        });
    }
};
CustomersDetailsPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _customers_service__WEBPACK_IMPORTED_MODULE_7__["CustomersService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonRouterOutlet"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"] }
];
CustomersDetailsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-customers-details',
        template: _raw_loader_customers_details_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_styles_customers_details_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"], _styles_customers_details_shell_scss__WEBPACK_IMPORTED_MODULE_3__["default"]]
    })
], CustomersDetailsPage);



/***/ }),

/***/ "Pdd+":
/*!*********************************************************************!*\
  !*** ./src/app/pages/customers/details/customers-details.module.ts ***!
  \*********************************************************************/
/*! exports provided: CustomersDetailsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomersDetailsModule", function() { return CustomersDetailsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../components/components.module */ "j1ZV");
/* harmony import */ var _customers_details_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./customers-details.page */ "Ktgh");
/* harmony import */ var _instance_instance_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../instance/instance.page */ "g34P");
/* harmony import */ var ng_zorro_antd_mobile__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ng-zorro-antd-mobile */ "EZ1+");
/* harmony import */ var _app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @app/pipes/pipes.module */ "iTUp");
/* harmony import */ var _track_record_track_record_page__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../track-record/track-record.page */ "9I/D");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var ngx_ionic_image_viewer__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-ionic-image-viewer */ "6g0+");













let CustomersDetailsModule = class CustomersDetailsModule {
};
CustomersDetailsModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
            _components_components_module__WEBPACK_IMPORTED_MODULE_5__["ComponentsModule"],
            ng_zorro_antd_mobile__WEBPACK_IMPORTED_MODULE_8__["StepsModule"],
            _app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_9__["PipesModule"],
            ng_zorro_antd_mobile__WEBPACK_IMPORTED_MODULE_8__["ImagePickerModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_11__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_11__["ReactiveFormsModule"],
            ngx_ionic_image_viewer__WEBPACK_IMPORTED_MODULE_12__["NgxIonicImageViewerModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{ path: '', component: _customers_details_page__WEBPACK_IMPORTED_MODULE_6__["CustomersDetailsPage"] }])
        ],
        declarations: [_customers_details_page__WEBPACK_IMPORTED_MODULE_6__["CustomersDetailsPage"], _instance_instance_page__WEBPACK_IMPORTED_MODULE_7__["InstancePage"], _track_record_track_record_page__WEBPACK_IMPORTED_MODULE_10__["TrackRecordPage"]],
        entryComponents: [_instance_instance_page__WEBPACK_IMPORTED_MODULE_7__["InstancePage"], _track_record_track_record_page__WEBPACK_IMPORTED_MODULE_10__["TrackRecordPage"]],
    })
], CustomersDetailsModule);



/***/ }),

/***/ "e8CX":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/customers/track-record/track-record.page.html ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"dismiss()\">关闭</ion-button>\n    </ion-buttons>\n    <ion-title>\n      添加跟办记录\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"forms-validations-content\">\n  <form class=\"validations-form\" [formGroup]=\"validationsForm\" (ngSubmit)=\"onSubmit(validationsForm.value)\">\n    <ion-list class=\"inputs-list\" lines=\"full\">\n      <ion-list-header>\n        <ion-label class=\"header-title\">上传跟办详情图片</ion-label>\n      </ion-list-header>\n\n      <!-- When this bug (https://github.com/ionic-team/ionic-framework/issues/22117) gets fixed, remove .item-label-floating class -->\n      <!-- <ion-item class=\"input-item item-label-floating\">\n        <ion-label position=\"floating\">上传带看单</ion-label>\n      </ion-item> -->\n      <div slot=\"end\">\n        <ImagePicker\n          [files]=\"f.take_bill.value\"\n          [multiple]=\"multiple === 0\"\n          [length]=\"3\"\n          [selectable]=\"f.take_bill.value.length < 3\"\n          [accept]=\"'image/gif,image/jpeg,image/jpg,image/png'\"\n          (onChange)=\"fileChange($event)\"\n          (onImageClick)=\"imageClick($event)\"\n          (onImageChange)=\"ImageChange($event)\">\n        </ImagePicker>\n      </div>\n\n\n      <ion-item class=\"input-item item-label-floating\">\n        <ion-label position=\"floating\">说明</ion-label>\n        <ion-input type=\"text\" formControlName=\"details\" clearInput></ion-input>\n      </ion-item>\n      <div class=\"error-container\">\n        <ng-container *ngFor=\"let validation of validations.details\">\n          <div class=\"error-message\" *ngIf=\"validationsForm.get('details').hasError(validation.type) && (validationsForm.get('details').dirty || validationsForm.get('details').touched)\">\n            <ion-icon name=\"information-circle-outline\"></ion-icon>\n            <span>{{ validation.message }}</span>\n          </div>\n        </ng-container>\n      </div>\n\n      <ion-item class=\"input-item item-label-floating\">\n        <ion-label position=\"floating\">办理方式</ion-label>\n        <ion-select formControlName=\"handle_type\" cancelText=\"取消\" okText=\"确认\">\n          <ion-select-option *ngFor=\"let ht of handleTypes\" [value]=\"ht\">{{ ht }}</ion-select-option>\n        </ion-select>\n      </ion-item>\n    </ion-list>\n\n    <ion-button class=\"submit-btn\" type=\"submit\" expand=\"block\" fill=\"outline\" [disabled]=\"!validationsForm.valid || !f.take_bill.value[0]?.link\">确认添加</ion-button>\n  </form>\n</ion-content>\n");

/***/ }),

/***/ "f+TS":
/*!*****************************************************************************!*\
  !*** ./src/app/pages/customers/details/styles/customers-details.shell.scss ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("app-image-shell.user-avatar {\n  --image-shell-loading-background: rgba(var(--ion-color-light-rgb), 0.25);\n  --image-shell-border-radius: 50%;\n  --image-shell-spinner-color: var(--ion-color-light);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL2N1c3RvbWVycy1kZXRhaWxzLnNoZWxsLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx3RUFBQTtFQUNBLGdDQUFBO0VBQ0EsbURBQUE7QUFDRiIsImZpbGUiOiJjdXN0b21lcnMtZGV0YWlscy5zaGVsbC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiYXBwLWltYWdlLXNoZWxsLnVzZXItYXZhdGFyIHtcbiAgLS1pbWFnZS1zaGVsbC1sb2FkaW5nLWJhY2tncm91bmQ6IHJnYmEodmFyKC0taW9uLWNvbG9yLWxpZ2h0LXJnYiksIDAuMjUpO1xuICAtLWltYWdlLXNoZWxsLWJvcmRlci1yYWRpdXM6IDUwJTtcbiAgLS1pbWFnZS1zaGVsbC1zcGlubmVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xufVxuIl19 */");

/***/ }),

/***/ "g/Tr":
/*!****************************************************!*\
  !*** ./src/app/pages/transact/transact.service.ts ***!
  \****************************************************/
/*! exports provided: TransactService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TransactService", function() { return TransactService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "tk/3");



let TransactService = class TransactService {
    constructor(http) {
        this.http = http;
    }
    // public getDetailsDataSource(slug: string): Observable<any> {
    //   const rawDataSource = this.http.get<any>('./assets/sample-data/food/details.json')
    //   .pipe(
    //     mergeMap(details => details.items.filter(item => item.slug === slug)),
    //     map(
    //       (data: FoodDetailsModel) => {
    //         // Note: HttpClient cannot know how to instantiate a class for the returned data
    //         // We need to properly cast types from json data
    //         const details = new FoodDetailsModel();
    //         // The Object.assign() method copies all enumerable own properties from one or more source objects to a target object.
    //         // Note: If you have non-enummerable properties, you can try a spread operator instead. details = {...data};
    //         // (see: https://scotch.io/bar-talk/copying-objects-in-javascript#toc-using-spread-elements-)
    //         Object.assign(details, data);
    //         return details;
    //       }
    //     )
    //   );
    //   // This method tapps into the raw data source and stores the resolved data in the TransferState, then when
    //   // transitioning from the server rendered view to the browser, checks if we already loaded the data in the server to prevent
    //   // duplicate http requests.
    //   const cachedDataSource = this.transferStateHelper.checkDataSourceState('food-details-state', rawDataSource);
    //   return cachedDataSource;
    // }
    // public getDetailsStore(dataSource: Observable<FoodDetailsModel>): DataStore<FoodDetailsModel> {
    //   // Initialize the model specifying that it is a shell model
    //   const shellModel: FoodDetailsModel = new FoodDetailsModel();
    //   this.detailsDataStore = new DataStore(shellModel);
    //   // If running in the server, then don't add shell to the Data Store
    //   // If we already loaded the Data Source in the server, then don't show a shell when transitioning back to the broswer from the server
    //   if (isPlatformServer(this.platformId) || dataSource['ssr_state']) {
    //     // Trigger loading mechanism with 0 delay (this will prevent the shell to be shown)
    //     this.detailsDataStore.load(dataSource, 0);
    //   } else { // On browser transitions
    //     // Trigger the loading mechanism (with shell)
    //     this.detailsDataStore.load(dataSource);
    //   }
    //   return this.detailsDataStore;
    // }
    getCurrentTransact(slug, userId) {
        return this.http.post('/mkt/engine-rest/task', { processInstanceId: slug, assignee: userId })
            .pipe();
    }
    getTransactList(userId) {
        return this.http.post('/mkt/engine-rest/task', { "assignee": userId, "sorting": [{ "sortBy": "dueDate",
                    "sortOrder": "asc"
                }] })
            .pipe();
    }
    getCurrentReferrals(slug) {
        return this.http.get(`/mkt/api/mp/referrals/instance/${slug}`)
            .pipe();
    }
    getTaskCount(userId) {
        return this.http.get('/mkt/engine-rest/task/count', { params: { assignee: userId } })
            .pipe();
    }
    completeTask(taskId, params) {
        return this.http.post(`/mkt/engine-rest/task/${taskId}/complete`, params)
            .pipe();
    }
};
TransactService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
TransactService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], TransactService);



/***/ }),

/***/ "g34P":
/*!***********************************************************!*\
  !*** ./src/app/pages/customers/instance/instance.page.ts ***!
  \***********************************************************/
/*! exports provided: InstancePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InstancePage", function() { return InstancePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_instance_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./instance.page.html */ "j1Kt");
/* harmony import */ var _styles_instance_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/instance.page.scss */ "8h23");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _app_pages_transact_transact_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @app/pages/transact/transact.service */ "g/Tr");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _customers_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../customers.service */ "adrT");







let InstancePage = class InstancePage {
    constructor(modalController, customersService, transactService) {
        this.modalController = modalController;
        this.customersService = customersService;
        this.transactService = transactService;
        this.steps = [];
        this.current = 0;
        this.index = 'First-content';
    }
    ngOnInit() {
        this.steps = [
            {
                title: '审核',
            },
            {
                title: '跟办',
            },
            {
                title: '到期',
            }
        ];
        if (this.instanceId) {
            this.transactService.getCurrentReferrals(this.instanceId).subscribe(res => {
                var _a, _b;
                if (res.ok) {
                    this.currentReferrals = res.data;
                    if (((_a = this.currentReferrals) === null || _a === void 0 ? void 0 : _a.workflowStatus) != '1') {
                        if (((_b = this.currentReferrals) === null || _b === void 0 ? void 0 : _b.currentHandler) === '楼盘判客') {
                            this.current = 0;
                        }
                        else {
                            this.current = 1;
                        }
                    }
                    else {
                        this.current = 2;
                    }
                    if (this.currentReferrals) {
                        this.customersService.getListRef(this.currentReferrals.id).subscribe(data => {
                            if (data.ok) {
                                //
                                this.trackRecord = data.data;
                            }
                        });
                    }
                }
            });
            this.customersService.getHistoryTaskByInstanceId(this.instanceId, "startTime", "asc").subscribe(resp => {
                var _a, _b;
                this.taskList = resp;
                if (this.taskList.length > 0) {
                    if (((_a = this.taskList[this.taskList.length - 1]) === null || _a === void 0 ? void 0 : _a.name) === '楼盘判客' && ((_b = this.taskList[this.taskList.length - 1]) === null || _b === void 0 ? void 0 : _b.deleteReason) === 'completed') {
                        this.current = 1;
                    }
                }
            });
        }
    }
    dismiss() {
        this.modalController.dismiss();
    }
    del(id) {
        this.customersService.delTrackRecord(id).subscribe(res => {
            console.log('del ok');
            this.dismiss();
        });
    }
};
InstancePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: _customers_service__WEBPACK_IMPORTED_MODULE_6__["CustomersService"] },
    { type: _app_pages_transact_transact_service__WEBPACK_IMPORTED_MODULE_4__["TransactService"] }
];
InstancePage.propDecorators = {
    instanceId: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    userId: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
InstancePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-instance-page',
        template: _raw_loader_instance_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_styles_instance_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], InstancePage);



/***/ }),

/***/ "geym":
/*!****************************************************************************!*\
  !*** ./src/app/pages/customers/details/styles/customers-details.page.scss ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host {\n  --page-margin: var(--app-broad-margin);\n  --page-background: var(--app-background-shade);\n  --page-highlighted-background: var(--ion-color-tertiary-tint);\n  --page-rating-4-color: #a8e07c;\n  --page-rating-3-color: #cee07c;\n  --page-rating-2-color: #e0c77c;\n  --page-rating-1-color: #e07c7c;\n}\n\nion-header ion-toolbar {\n  --background: transparent;\n}\n\nion-content {\n  position: absolute;\n  top: 0;\n  border-top: calc(var(--app-header-height) + var(--ion-safe-area-top));\n  border-top-style: solid;\n  border-top-color: var(--page-highlighted-background);\n}\n\n.contact-card-content {\n  --background: var(--page-background);\n  transform: translateZ(0);\n}\n\n.contact-card-content .user-details-wrapper {\n  --ion-grid-column-padding: 0px;\n  padding: 0px var(--page-margin) var(--page-margin);\n  background-color: var(--page-highlighted-background);\n  color: var(--ion-color-light);\n  align-items: center;\n}\n\n.contact-card-content .user-details-wrapper .user-avatar {\n  border: solid 3px var(--ion-color-light);\n}\n\n.contact-card-content .user-details-wrapper .user-info-wrapper {\n  padding-left: calc(var(--page-margin) / 2);\n}\n\n.contact-card-content .user-details-wrapper .user-info-wrapper .user-name {\n  margin: 0px 0px 5px;\n}\n\n.contact-card-content .user-details-wrapper .user-info-wrapper .user-handle {\n  margin: 0px;\n  font-weight: 400;\n}\n\n.contact-card-content .user-details-wrapper .user-stats-wrapper {\n  text-align: center;\n  padding-top: calc(var(--page-margin) / 2);\n}\n\n.contact-card-content .user-details-wrapper .user-stats-wrapper .user-stat-value {\n  margin-right: 5px;\n  font-weight: 500;\n  font-size: 18px;\n}\n\n.contact-card-content .user-details-wrapper .user-stats-wrapper .user-stat-name {\n  font-size: 16px;\n}\n\n.contact-card-content .user-details-wrapper .user-bio {\n  margin: var(--page-margin) 0px 0px;\n  line-height: 1.2;\n  font-size: 14px;\n}\n\n.contact-card-content .user-preferences-wrapper {\n  --ion-grid-column-padding: 0px;\n  padding: var(--page-margin);\n}\n\n.contact-card-content .user-preferences-wrapper .preference-name {\n  margin: 0px 0px 5px;\n  font-size: 16px;\n}\n\n.contact-card-content .user-preferences-wrapper .preference-value {\n  margin: 0px 0px calc(var(--page-margin) / 2);\n  font-size: 14px;\n  line-height: 1.4;\n  color: var(--ion-color-dark-tint);\n}\n\n.contact-card-content .related-deals-wrapper {\n  margin: calc(var(--page-margin)) var(--page-margin) calc(var(--page-margin) * 2);\n}\n\n.contact-card-content .related-deals-wrapper .related-deals-title {\n  text-align: center;\n  font-size: 20px;\n  font-weight: 400;\n  text-transform: uppercase;\n  color: var(--ion-color-dark-shade);\n  margin: 0px 0px var(--page-margin);\n}\n\n.contact-card-content .related-deals-wrapper .related-deal {\n  --ion-grid-column-padding: 0px;\n  border-radius: var(--app-broad-radius);\n  background-color: var(--ion-color-lightest);\n}\n\n.contact-card-content .related-deals-wrapper .related-deal:not(:last-child) {\n  margin-bottom: calc(var(--page-margin) / 2);\n}\n\n.contact-card-content .related-deals-wrapper .related-deal .deal-logo-wrapper {\n  padding: calc(var(--page-margin) / 4) var(--page-margin) calc(var(--page-margin) / 4) calc(var(--page-margin) / 2);\n  border-right: 2px dashed rgba(var(--ion-color-dark-rgb), 0.1);\n}\n\n.contact-card-content .related-deals-wrapper .related-deal .deal-info-wrapper {\n  padding-left: var(--page-margin);\n  padding-right: calc(var(--page-margin) / 2);\n  padding-top: calc(var(--page-margin) / 4);\n  padding-bottom: calc(var(--page-margin) / 4);\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n}\n\n.contact-card-content .related-deals-wrapper .related-deal .deal-info-wrapper .related-deal-title {\n  margin: 0px;\n  margin-bottom: 5px;\n  color: var(--ion-color-dark-tint);\n  font-size: 20px;\n}\n\n.contact-card-content .related-deals-wrapper .related-deal .deal-info-wrapper .related-deal-description {\n  margin: 0px;\n  color: var(--ion-color-medium-tint);\n  font-size: 16px;\n}\n\n.contact-card-content .related-deals-wrapper .related-deal .deal-info-wrapper .related-deal-description .status {\n  margin: 2px;\n  color: var(--page-rating-4-color);\n  font-size: 12px;\n}\n\n.contact-card-content .related-deals-wrapper .stats-col {\n  flex: 0 0 calc(calc(var(--col-item-width) / var(--ion-grid-columns, 12)) * 100%);\n  width: calc(calc(var(--col-item-width) / var(--ion-grid-columns, 12)) * 100%);\n  max-width: calc(calc(var(--col-item-width) / var(--ion-grid-columns, 12)) * 100%);\n  margin: calc(var(--page-margin) / 2);\n}\n\n.contact-card-content .related-deals-wrapper .stats-col .item-rating {\n  background-color: rgba(var(--page-color-rgb), 0.35);\n  color: var(--ion-color-lightest);\n  border-radius: var(--app-narrow-radius);\n  padding-top: calc(var(--page-margin) / 3);\n  padding-bottom: calc(var(--page-margin) / 3);\n  padding-left: calc(var(--page-margin) / 2);\n  padding-right: calc(var(--page-margin) / 2);\n  font-size: 12px;\n  font-weight: 600;\n  width: 100%;\n  display: block;\n  text-align: center;\n}\n\n.contact-card-content .related-deals-wrapper .stats-col .item-rating[ratingBase=S] {\n  background-color: var(--page-rating-1-color);\n}\n\n.contact-card-content .related-deals-wrapper .stats-col .item-rating[ratingBase=A] {\n  background-color: var(--page-rating-2-color);\n}\n\n.contact-card-content .related-deals-wrapper .stats-col .item-rating[ratingBase=B] {\n  background-color: var(--page-rating-3-color);\n}\n\n.contact-card-content .related-deals-wrapper .stats-col .item-rating[ratingBase=C] {\n  background-color: var(--page-rating-4-color);\n}\n\n.contact-card-content .related-deals-wrapper .stats-col .item-rating[ratingBase=D] {\n  background-color: var(--page-rating-5-color);\n}\n\n.contact-card-content .related-deals-wrapper .stats-col .item-price-range {\n  margin-top: 5px;\n  font-size: 12px;\n  letter-spacing: 1px;\n  font-weight: 500;\n  text-align: center;\n}\n\n.contact-card-content .related-deals-wrapper .stats-col .item-price-range .price {\n  color: var(--page-color);\n  text-decoration: underline;\n}\n\n.contact-card-content .related-deals-wrapper .stats-col .item-price-range .no-price {\n  color: rgba(var(--ion-color-light-shade-rgb), 0.4);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL2N1c3RvbWVycy1kZXRhaWxzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQTtFQUNFLHNDQUFBO0VBQ0EsOENBQUE7RUFFQSw2REFBQTtFQUVBLDhCQUFBO0VBQ0EsOEJBQUE7RUFDQSw4QkFBQTtFQUNBLDhCQUFBO0FBSEY7O0FBV0U7RUFDRSx5QkFBQTtBQVJKOztBQVdBO0VBQ0Usa0JBQUE7RUFDQSxNQUFBO0VBQ0EscUVBQUE7RUFDQSx1QkFBQTtFQUNBLG9EQUFBO0FBUkY7O0FBV0E7RUFDRSxvQ0FBQTtFQUVBLHdCQUFBO0FBVEY7O0FBV0U7RUFDRSw4QkFBQTtFQUVBLGtEQUFBO0VBQ0Esb0RBQUE7RUFDQSw2QkFBQTtFQUNBLG1CQUFBO0FBVko7O0FBWUk7RUFDRSx3Q0FBQTtBQVZOOztBQWFJO0VBQ0UsMENBQUE7QUFYTjs7QUFhTTtFQUNFLG1CQUFBO0FBWFI7O0FBY007RUFDRSxXQUFBO0VBQ0EsZ0JBQUE7QUFaUjs7QUFnQkk7RUFDRSxrQkFBQTtFQUNBLHlDQUFBO0FBZE47O0FBZ0JNO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFkUjs7QUFpQk07RUFDRSxlQUFBO0FBZlI7O0FBbUJJO0VBQ0Usa0NBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFqQk47O0FBcUJFO0VBQ0UsOEJBQUE7RUFFQSwyQkFBQTtBQXBCSjs7QUFzQkk7RUFDRSxtQkFBQTtFQUNBLGVBQUE7QUFwQk47O0FBdUJJO0VBQ0UsNENBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQ0FBQTtBQXJCTjs7QUF5QkU7RUFDRSxnRkFBQTtBQXZCSjs7QUF5Qkk7RUFDRSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLHlCQUFBO0VBQ0Esa0NBQUE7RUFDQSxrQ0FBQTtBQXZCTjs7QUEwQkk7RUFDRSw4QkFBQTtFQUVBLHNDQUFBO0VBQ0EsMkNBQUE7QUF6Qk47O0FBMkJNO0VBQ0UsMkNBQUE7QUF6QlI7O0FBNEJNO0VBQ0Usa0hBQUE7RUFDQSw2REFBQTtBQTFCUjs7QUE2Qk07RUFDRSxnQ0FBQTtFQUNBLDJDQUFBO0VBQ0EseUNBQUE7RUFDQSw0Q0FBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0FBM0JSOztBQTZCUTtFQUNFLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGlDQUFBO0VBQ0EsZUFBQTtBQTNCVjs7QUE4QlE7RUFDRSxXQUFBO0VBQ0EsbUNBQUE7RUFDQSxlQUFBO0FBNUJWOztBQThCVTtFQUNFLFdBQUE7RUFDQSxpQ0FBQTtFQUNBLGVBQUE7QUE1Qlo7O0FBa0NJO0VBR0UsZ0ZBQUE7RUFDQSw2RUFBQTtFQUNBLGlGQUFBO0VBRUEsb0NBQUE7QUFuQ047O0FBc0NNO0VBRUUsbURBQUE7RUFDSixnQ0FBQTtFQUNBLHVDQUFBO0VBQ0EseUNBQUE7RUFDQSw0Q0FBQTtFQUNBLDBDQUFBO0VBQ0EsMkNBQUE7RUFDQyxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBckNMOztBQXVDSTtFQUNDLDRDQUFBO0FBckNMOztBQXVDSTtFQUNDLDRDQUFBO0FBckNMOztBQXVDSTtFQUNDLDRDQUFBO0FBckNMOztBQXVDSTtFQUNDLDRDQUFBO0FBckNMOztBQXVDUTtFQUNILDRDQUFBO0FBckNMOztBQXlDTTtFQUNFLGVBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FBdkNSOztBQXlDUTtFQUNFLHdCQUFBO0VBQ0EsMEJBQUE7QUF2Q1Y7O0FBMENRO0VBQ0Usa0RBQUE7QUF4Q1YiLCJmaWxlIjoiY3VzdG9tZXJzLWRldGFpbHMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gQ3VzdG9tIHZhcmlhYmxlc1xuLy8gTm90ZTogIFRoZXNlIG9uZXMgd2VyZSBhZGRlZCBieSB1cyBhbmQgaGF2ZSBub3RoaW5nIHRvIGRvIHdpdGggSW9uaWMgQ1NTIEN1c3RvbSBQcm9wZXJ0aWVzXG46aG9zdCB7XG4gIC0tcGFnZS1tYXJnaW46IHZhcigtLWFwcC1icm9hZC1tYXJnaW4pO1xuICAtLXBhZ2UtYmFja2dyb3VuZDogdmFyKC0tYXBwLWJhY2tncm91bmQtc2hhZGUpO1xuXG4gIC0tcGFnZS1oaWdobGlnaHRlZC1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItdGVydGlhcnktdGludCk7XG5cbiAgLS1wYWdlLXJhdGluZy00LWNvbG9yOiAjYThlMDdjO1xuICAtLXBhZ2UtcmF0aW5nLTMtY29sb3I6ICNjZWUwN2M7XG4gIC0tcGFnZS1yYXRpbmctMi1jb2xvcjogI2UwYzc3YztcbiAgLS1wYWdlLXJhdGluZy0xLWNvbG9yOiAjZTA3YzdjO1xuXG59XG5cbi8vIE5vdGU6ICBBbGwgdGhlIENTUyB2YXJpYWJsZXMgZGVmaW5lZCBiZWxvdyBhcmUgb3ZlcnJpZGVzIG9mIElvbmljIGVsZW1lbnRzIENTUyBDdXN0b20gUHJvcGVydGllc1xuXG4vLyBVc2UgYSBjb2xvcmVkIGJvcmRlci10b3AgdG8gZml4IHdlaXJkIHRyYW5zaXRpb25zIGJldHdlZW4gdG9vbGJhcnMgdGhhdCBoYXZlIGRpZmZlcmVudCBiYWNrZ3JvdW5kIGNvbG9yc1xuaW9uLWhlYWRlciB7XG4gIGlvbi10b29sYmFyIHtcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICB9XG59XG5pb24tY29udGVudCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAwO1xuICBib3JkZXItdG9wOiBjYWxjKHZhcigtLWFwcC1oZWFkZXItaGVpZ2h0KSArIHZhcigtLWlvbi1zYWZlLWFyZWEtdG9wKSk7XG4gIGJvcmRlci10b3Atc3R5bGU6IHNvbGlkO1xuICBib3JkZXItdG9wLWNvbG9yOiB2YXIoLS1wYWdlLWhpZ2hsaWdodGVkLWJhY2tncm91bmQpO1xufVxuXG4uY29udGFjdC1jYXJkLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHZhcigtLXBhZ2UtYmFja2dyb3VuZCk7XG4gIC8vIFRvIGZpeCBoYWxmIHBpeGVsIGxpbmUgYmV0d2VlbiBpb24taGVhZGVyIGFuZCAgaW9uLWNvbnRlbnRcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVaKDApO1xuXG4gIC51c2VyLWRldGFpbHMtd3JhcHBlciB7XG4gICAgLS1pb24tZ3JpZC1jb2x1bW4tcGFkZGluZzogMHB4O1xuXG4gICAgcGFkZGluZzogMHB4IHZhcigtLXBhZ2UtbWFyZ2luKSB2YXIoLS1wYWdlLW1hcmdpbik7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tcGFnZS1oaWdobGlnaHRlZC1iYWNrZ3JvdW5kKTtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuXG4gICAgLnVzZXItYXZhdGFyIHtcbiAgICAgIGJvcmRlcjogc29saWQgM3B4IHZhcigtLWlvbi1jb2xvci1saWdodCk7XG4gICAgfVxuXG4gICAgLnVzZXItaW5mby13cmFwcGVyIHtcbiAgICAgIHBhZGRpbmctbGVmdDogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcblxuICAgICAgLnVzZXItbmFtZSB7XG4gICAgICAgIG1hcmdpbjogMHB4IDBweCA1cHg7XG4gICAgICB9XG5cbiAgICAgIC51c2VyLWhhbmRsZSB7XG4gICAgICAgIG1hcmdpbjogMHB4O1xuICAgICAgICBmb250LXdlaWdodDogNDAwO1xuICAgICAgfVxuICAgIH1cblxuICAgIC51c2VyLXN0YXRzLXdyYXBwZXIge1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgcGFkZGluZy10b3A6IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMik7XG5cbiAgICAgIC51c2VyLXN0YXQtdmFsdWUge1xuICAgICAgICBtYXJnaW4tcmlnaHQ6IDVweDtcbiAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgICAgfVxuXG4gICAgICAudXNlci1zdGF0LW5hbWUge1xuICAgICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLnVzZXItYmlvIHtcbiAgICAgIG1hcmdpbjogdmFyKC0tcGFnZS1tYXJnaW4pIDBweCAwcHg7XG4gICAgICBsaW5lLWhlaWdodDogMS4yO1xuICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgIH1cbiAgfVxuXG4gIC51c2VyLXByZWZlcmVuY2VzLXdyYXBwZXIge1xuICAgIC0taW9uLWdyaWQtY29sdW1uLXBhZGRpbmc6IDBweDtcblxuICAgIHBhZGRpbmc6IHZhcigtLXBhZ2UtbWFyZ2luKTtcblxuICAgIC5wcmVmZXJlbmNlLW5hbWUge1xuICAgICAgbWFyZ2luOiAwcHggMHB4IDVweDtcbiAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICB9XG5cbiAgICAucHJlZmVyZW5jZS12YWx1ZSB7XG4gICAgICBtYXJnaW46IDBweCAwcHggY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgIGxpbmUtaGVpZ2h0OiAxLjQ7XG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmstdGludCk7XG4gICAgfVxuICB9XG5cbiAgLnJlbGF0ZWQtZGVhbHMtd3JhcHBlciB7XG4gICAgbWFyZ2luOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSkgdmFyKC0tcGFnZS1tYXJnaW4pIGNhbGModmFyKC0tcGFnZS1tYXJnaW4pICogMik7XG5cbiAgICAucmVsYXRlZC1kZWFscy10aXRsZSB7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICBmb250LXdlaWdodDogNDAwO1xuICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyay1zaGFkZSk7XG4gICAgICBtYXJnaW46IDBweCAwcHggdmFyKC0tcGFnZS1tYXJnaW4pO1xuICAgIH1cblxuICAgIC5yZWxhdGVkLWRlYWwge1xuICAgICAgLS1pb24tZ3JpZC1jb2x1bW4tcGFkZGluZzogMHB4O1xuXG4gICAgICBib3JkZXItcmFkaXVzOiB2YXIoLS1hcHAtYnJvYWQtcmFkaXVzKTtcbiAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodGVzdCk7XG5cbiAgICAgICY6bm90KDpsYXN0LWNoaWxkKSB7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMik7XG4gICAgICB9XG5cbiAgICAgIC5kZWFsLWxvZ28td3JhcHBlciB7XG4gICAgICAgIHBhZGRpbmc6IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gNCkgdmFyKC0tcGFnZS1tYXJnaW4pIGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gNCkgY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcbiAgICAgICAgYm9yZGVyLXJpZ2h0OiAycHggZGFzaGVkIHJnYmEodmFyKC0taW9uLWNvbG9yLWRhcmstcmdiKSwgLjEpO1xuICAgICAgfVxuXG4gICAgICAuZGVhbC1pbmZvLXdyYXBwZXIge1xuICAgICAgICBwYWRkaW5nLWxlZnQ6IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgICAgICAgcGFkZGluZy1yaWdodDogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcbiAgICAgICAgcGFkZGluZy10b3A6IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gNCk7XG4gICAgICAgIHBhZGRpbmctYm90dG9tOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDQpO1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcblxuICAgICAgICAucmVsYXRlZC1kZWFsLXRpdGxlIHtcbiAgICAgICAgICBtYXJnaW46IDBweDtcbiAgICAgICAgICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrLXRpbnQpO1xuICAgICAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5yZWxhdGVkLWRlYWwtZGVzY3JpcHRpb24ge1xuICAgICAgICAgIG1hcmdpbjogMHB4O1xuICAgICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtLXRpbnQpO1xuICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcblxuICAgICAgICAgIC5zdGF0dXMge1xuICAgICAgICAgICAgbWFyZ2luOiAycHg7XG4gICAgICAgICAgICBjb2xvcjogdmFyKC0tcGFnZS1yYXRpbmctNC1jb2xvcik7XG4gICAgICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgLnN0YXRzLWNvbCB7XG4gICAgICAvLyAtLWNvbC1pdGVtLXdpZHRoOiAyO1xuICAgICAgLy8gU1NSIGZpeDogT3ZlcnJpZGUgaW9uLWNvbCBzdHlsZXNcbiAgICAgIGZsZXg6IDAgMCBjYWxjKGNhbGModmFyKC0tY29sLWl0ZW0td2lkdGgpIC8gdmFyKC0taW9uLWdyaWQtY29sdW1ucywgMTIpKSAqIDEwMCUpO1xuICAgICAgd2lkdGg6IGNhbGMoY2FsYyh2YXIoLS1jb2wtaXRlbS13aWR0aCkgLyB2YXIoLS1pb24tZ3JpZC1jb2x1bW5zLCAxMikpICogMTAwJSk7XG4gICAgICBtYXgtd2lkdGg6IGNhbGMoY2FsYyh2YXIoLS1jb2wtaXRlbS13aWR0aCkgLyB2YXIoLS1pb24tZ3JpZC1jb2x1bW5zLCAxMikpICogMTAwJSk7XG5cbiAgICAgIG1hcmdpbjogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcbiAgICAgIC8vIHBhZGRpbmctbGVmdDogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcblxuICAgICAgLml0ZW0tcmF0aW5nIHtcbiAgICAgICAgLy8gRGVmYXVsdCBiYWNrZ3JvdW5kXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEodmFyKC0tcGFnZS1jb2xvci1yZ2IpLCAuMzUpO1xuXHRcdFx0XHRjb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0ZXN0KTtcblx0XHRcdFx0Ym9yZGVyLXJhZGl1czogdmFyKC0tYXBwLW5hcnJvdy1yYWRpdXMpO1xuXHRcdFx0XHRwYWRkaW5nLXRvcDogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAzKTtcblx0XHRcdFx0cGFkZGluZy1ib3R0b206IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMyk7XG5cdFx0XHRcdHBhZGRpbmctbGVmdDogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcblx0XHRcdFx0cGFkZGluZy1yaWdodDogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcblx0XHRcdCAgZm9udC1zaXplOiAxMnB4O1xuXHRcdFx0ICBmb250LXdlaWdodDogNjAwO1xuXHRcdFx0ICB3aWR0aDogMTAwJTtcblx0XHRcdCAgZGlzcGxheTogYmxvY2s7XG5cdFx0XHQgIHRleHQtYWxpZ246IGNlbnRlcjtcblxuXHRcdFx0XHQmW3JhdGluZ0Jhc2U9XCJTXCJdIHtcblx0XHRcdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1wYWdlLXJhdGluZy0xLWNvbG9yKTtcblx0XHRcdFx0fVxuXHRcdFx0XHQmW3JhdGluZ0Jhc2U9XCJBXCJdIHtcblx0XHRcdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1wYWdlLXJhdGluZy0yLWNvbG9yKTtcblx0XHRcdFx0fVxuXHRcdFx0XHQmW3JhdGluZ0Jhc2U9XCJCXCJdIHtcblx0XHRcdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1wYWdlLXJhdGluZy0zLWNvbG9yKTtcblx0XHRcdFx0fVxuXHRcdFx0XHQmW3JhdGluZ0Jhc2U9XCJDXCJdIHtcblx0XHRcdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1wYWdlLXJhdGluZy00LWNvbG9yKTtcblx0XHRcdFx0fVxuICAgICAgICAmW3JhdGluZ0Jhc2U9XCJEXCJdIHtcblx0XHRcdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1wYWdlLXJhdGluZy01LWNvbG9yKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG4gICAgICAuaXRlbS1wcmljZS1yYW5nZSB7XG4gICAgICAgIG1hcmdpbi10b3A6IDVweDtcbiAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG5cbiAgICAgICAgLnByaWNlIHtcbiAgICAgICAgICBjb2xvcjogdmFyKC0tcGFnZS1jb2xvcik7XG4gICAgICAgICAgdGV4dC1kZWNvcmF0aW9uOnVuZGVybGluZVxuICAgICAgICB9XG5cbiAgICAgICAgLm5vLXByaWNlIHtcbiAgICAgICAgICBjb2xvcjogcmdiYSh2YXIoLS1pb24tY29sb3ItbGlnaHQtc2hhZGUtcmdiKSwgLjQwKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxufVxuIl19 */");

/***/ }),

/***/ "j1Kt":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/customers/instance/instance.page.html ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"dismiss()\">关闭</ion-button>\n    </ion-buttons>\n    <ion-title>\n      详情\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"legal-content\">\n  <!-- <h3 class=\"legal-title\">新邦网络平台用户服务协议</h3>\n  <p class=\"legal-text\">\n    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n  </p>\n  <h3 class=\"legal-title\">Using our services</h3>\n  <p class=\"legal-text\">\n    It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n  </p>\n  <h3 class=\"legal-title\">About these terms</h3>\n  <p class=\"legal-text\">\n    There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.\n  </p> -->\n  <!-- <div>\n    <div class=\"sub-title\">Horizontal small size</div>\n  </div> -->\n  <div>\n    <Steps [size]=\"'small'\" [current]=\"current\" [direction]=\"'horizontal'\">\n      <Step *ngFor=\"let v of steps\" [title]=\"v.title\" [description]=\"v.description\"></Step>\n    </Steps>\n  </div>\n\n  <ion-item-group>\n    <ion-item-divider>\n      <ion-label>办理详情</ion-label>\n    </ion-item-divider>\n  <ion-item class=\"notification-item\" lines=\"none\" *ngFor=\"let task of taskList\">\n    <ion-row class=\"notification-item-wrapper\">\n      <!-- <ion-col size=\"2\">\n        <app-aspect-ratio [ratio]=\"{w: 1, h: 1}\">\n          <app-image-shell class=\"notification-image\" [src]=\"notification.image\" [alt]=\"'user image'\"></app-image-shell>\n        </app-aspect-ratio>\n      </ion-col> -->\n      <ion-col class=\"details-wrapper\">\n        <h2 class=\"details-name\">{{ task.name }}</h2>\n        <p class=\"details-description\">办理人：{{ task.assignee }}</p>\n      </ion-col>\n      <ion-col size=\"4\" class=\"date-wrapper\">\n        <h3 class=\"notification-date\">{{ task?.endTime ? (task?.endTime | appTimeMMDay): ''}}</h3>\n        <p class=\"notification-description\">{{task.deleteReason === 'completed' ? '已办理' : '处理中...'}}</p>\n      </ion-col>\n    </ion-row>\n  </ion-item>\n  <ng-container >\n    <ion-item-group>\n      <ion-item-divider>\n        <ion-label>跟办记录</ion-label>\n      </ion-item-divider>\n      <div class=\"related-activities-wrapper\" *ngIf=\"trackRecord && trackRecord.length > 0\">\n        <!-- <h3 class=\"detail-alt-title\">More activities?</h3> -->\n        <ion-row class=\"related-activity\" *ngFor=\"let track of trackRecord\">\n          <ion-col class=\"picture-wrapper\" *ngFor=\"let url of track?.urls.slice(0, 3); let i = index\">\n            <app-aspect-ratio [ratio]=\"{w: 1, h: 1}\">\n              <app-image-shell class=\"picture-image\" [src]=\"url\" [alt]=\"'img'\" ionImgViewer></app-image-shell>\n            </app-aspect-ratio>\n          </ion-col>\n          <ion-col size=\"12\">\n            <!-- <app-image-shell [display]=\"'cover'\" animation=\"spinner\" class=\"related-activity-picture\" [src]=\"track?.url\" ionImgViewer>\n              <app-aspect-ratio [ratio]=\"{w:64, h:23}\">\n              </app-aspect-ratio>\n            </app-image-shell> -->\n            <!-- <ion-img-viewer \n  title=\"Demo\" \n  text=\"Component\" \n  scheme=\"dark\" \n  [src]=\"track?.url\">\n</ion-img-viewer> -->\n          </ion-col>\n          <ion-col size=\"12\" class=\"activity-details\">\n            <h5 class=\"activity-name\">\n              <!-- <ion-label class=\"type\"><app-text-shell [data]=\"track?.handleType\"></app-text-shell></ion-label> -->\n              <!-- <app-text-shell [data]=\"track?.content\"></app-text-shell> -->\n              <span style=\"color: rgb(81, 24, 240);\">「{{track?.handleType === '0' ? '普通跟办': (track?.handleType === '1'? '带看/来访': '成交确认')}}」</span>\n              {{track?.content}}\n            </h5>\n            <span class=\"activity-category\">\n              <app-text-shell [data]=\"track?.createId\"></app-text-shell>\n            </span>\n            <ion-button class=\"activity-rating\" expand=\"block\" fill=\"clear\" color=\"medium\" (click)=\"del(track?.id)\" *ngIf=\"track?.createId===userId\">\n              <ion-icon slot=\"icon-only\" name=\"trash\" ></ion-icon>\n            </ion-button>\n            <!-- <div class=\"activity-rating\">\n              <ion-icon class=\"rating-icon\" name=\"star-outline\"></ion-icon>\n              <div class=\"rating-value\"> -->\n                <!-- <app-text-shell [data]=\"relatedActivity.rating\"></app-text-shell> -->\n              <!-- </div> -->\n            <!-- </div> -->\n          </ion-col>\n        </ion-row>\n      </div>\n    </ion-item-group>\n  </ng-container>\n</ion-item-group>\n  \n</ion-content>\n");

/***/ }),

/***/ "lDzJ":
/*!****************************************************************************!*\
  !*** ./src/app/pages/customers/track-record/styles/track-record.page.scss ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host {\n  --page-margin: var(--app-broad-margin);\n  --page-background: var(--app-background-shade);\n}\n\nion-content {\n  position: absolute;\n  top: 0;\n  border-top: calc(var(--app-header-height) + var(--ion-safe-area-top));\n  border-top-style: solid;\n  border-top-color: var(--ion-color-primary);\n}\n\n.forms-validations-content {\n  --background: var(--page-background);\n}\n\n.forms-validations-content .validations-form {\n  margin-bottom: calc(var(--page-margin) * 2);\n}\n\n.forms-validations-content .validations-form .inputs-list {\n  --ion-item-background: var(--page-background);\n  padding: var(--page-margin) var(--page-margin) calc(var(--page-margin) * 2);\n}\n\n.forms-validations-content .validations-form .inputs-list ion-list-header {\n  padding-inline-start: 0px;\n}\n\n.forms-validations-content .validations-form .inputs-list ion-list-header .header-title {\n  text-transform: uppercase;\n  font-size: 16px;\n  color: var(--ion-color-secondary);\n}\n\n.forms-validations-content .validations-form .inputs-list .input-item {\n  --padding-start: 0px;\n  --padding-end: 0px;\n  --inner-padding-end: 0px;\n}\n\n.forms-validations-content .validations-form .inputs-list .error-container .error-message {\n  margin: calc(var(--page-margin) / 2) 0px;\n  display: flex;\n  align-items: center;\n  color: var(--ion-color-danger);\n  font-size: 14px;\n}\n\n.forms-validations-content .validations-form .inputs-list .error-container .error-message ion-icon {\n  padding-inline-end: calc(var(--page-margin) / 2);\n  flex-shrink: 0;\n}\n\n.forms-validations-content .validations-form .submit-btn {\n  margin: var(--page-margin);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3RyYWNrLXJlY29yZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDRSxzQ0FBQTtFQUNBLDhDQUFBO0FBREY7O0FBSUE7RUFDRSxrQkFBQTtFQUNBLE1BQUE7RUFDQSxxRUFBQTtFQUNBLHVCQUFBO0VBQ0EsMENBQUE7QUFERjs7QUFLQTtFQUNFLG9DQUFBO0FBRkY7O0FBSUU7RUFDRSwyQ0FBQTtBQUZKOztBQUlJO0VBQ0UsNkNBQUE7RUFFQSwyRUFBQTtBQUhOOztBQUtNO0VBQ0UseUJBQUE7QUFIUjs7QUFLUTtFQUNFLHlCQUFBO0VBQ0YsZUFBQTtFQUNBLGlDQUFBO0FBSFI7O0FBT007RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0Esd0JBQUE7QUFMUjs7QUFVUTtFQUNFLHdDQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7RUFDQSxlQUFBO0FBUlY7O0FBVVU7RUFDRSxnREFBQTtFQUNBLGNBQUE7QUFSWjs7QUFjSTtFQUNFLDBCQUFBO0FBWk4iLCJmaWxlIjoidHJhY2stcmVjb3JkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIEN1c3RvbSB2YXJpYWJsZXNcbi8vIE5vdGU6ICBUaGVzZSBvbmVzIHdlcmUgYWRkZWQgYnkgdXMgYW5kIGhhdmUgbm90aGluZyB0byBkbyB3aXRoIElvbmljIENTUyBDdXN0b20gUHJvcGVydGllc1xuOmhvc3Qge1xuICAtLXBhZ2UtbWFyZ2luOiB2YXIoLS1hcHAtYnJvYWQtbWFyZ2luKTtcbiAgLS1wYWdlLWJhY2tncm91bmQ6IHZhcigtLWFwcC1iYWNrZ3JvdW5kLXNoYWRlKTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMDtcbiAgYm9yZGVyLXRvcDogY2FsYyh2YXIoLS1hcHAtaGVhZGVyLWhlaWdodCkgKyB2YXIoLS1pb24tc2FmZS1hcmVhLXRvcCkpO1xuICBib3JkZXItdG9wLXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLXRvcC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG4vLyBOb3RlOiAgQWxsIHRoZSBDU1MgdmFyaWFibGVzIGRlZmluZWQgYmVsb3cgYXJlIG92ZXJyaWRlcyBvZiBJb25pYyBlbGVtZW50cyBDU1MgQ3VzdG9tIFByb3BlcnRpZXNcbi5mb3Jtcy12YWxpZGF0aW9ucy1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1wYWdlLWJhY2tncm91bmQpO1xuXG4gIC52YWxpZGF0aW9ucy1mb3JtIHtcbiAgICBtYXJnaW4tYm90dG9tOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAqIDIpO1xuXG4gICAgLmlucHV0cy1saXN0IHtcbiAgICAgIC0taW9uLWl0ZW0tYmFja2dyb3VuZDogdmFyKC0tcGFnZS1iYWNrZ3JvdW5kKTtcblxuICAgICAgcGFkZGluZzogdmFyKC0tcGFnZS1tYXJnaW4pIHZhcigtLXBhZ2UtbWFyZ2luKSBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAqIDIpO1xuXG4gICAgICBpb24tbGlzdC1oZWFkZXIge1xuICAgICAgICBwYWRkaW5nLWlubGluZS1zdGFydDogMHB4O1xuXG4gICAgICAgIC5oZWFkZXItdGl0bGUge1xuICAgICAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gICAgICBcdFx0Zm9udC1zaXplOiAxNnB4O1xuICAgICAgXHRcdGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kYXJ5KTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAuaW5wdXQtaXRlbSB7XG4gICAgICAgIC0tcGFkZGluZy1zdGFydDogMHB4O1xuICAgICAgICAtLXBhZGRpbmctZW5kOiAwcHg7XG4gICAgICAgIC0taW5uZXItcGFkZGluZy1lbmQ6IDBweDtcbiAgICAgIH1cbiAgICAgIFxuXG4gICAgICAuZXJyb3ItY29udGFpbmVyIHtcbiAgICAgICAgLmVycm9yLW1lc3NhZ2Uge1xuICAgICAgICAgIG1hcmdpbjogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKSAwcHg7XG4gICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFuZ2VyKTtcbiAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG5cbiAgICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICBwYWRkaW5nLWlubGluZS1lbmQ6IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMik7XG4gICAgICAgICAgICBmbGV4LXNocmluazogMDtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICBcdH1cbiAgICB9XG5cbiAgICAuc3VibWl0LWJ0biB7XG4gICAgICBtYXJnaW46IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgICB9XG4gIH1cbn1cbiJdfQ== */");

/***/ })

}]);
//# sourceMappingURL=customers-details-customers-details-module.js.map