(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-accompany-accompany-module"],{

/***/ "6/yJ":
/*!*****************************************************!*\
  !*** ./src/app/pages/accompany/accompany.module.ts ***!
  \*****************************************************/
/*! exports provided: AccompanyModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccompanyModule", function() { return AccompanyModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _app_components_components_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @app/components/components.module */ "j1ZV");
/* harmony import */ var _accompany_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./accompany.page */ "b4MU");








let AccompanyModule = class AccompanyModule {
};
AccompanyModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
            _app_components_components_module__WEBPACK_IMPORTED_MODULE_6__["ComponentsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ReactiveFormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{ path: '', component: _accompany_page__WEBPACK_IMPORTED_MODULE_7__["AccompanyPage"] }])
        ],
        declarations: [_accompany_page__WEBPACK_IMPORTED_MODULE_7__["AccompanyPage"]]
    })
], AccompanyModule);



/***/ }),

/***/ "EljO":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/accompany/accompany.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- <ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header> -->\n\n<ion-content class=\"transact-details-content\">\n  \n  \n  <ion-row class=\"user-preferences-wrapper\">\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">客户：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.customerName}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">电话：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.phone}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">咨询楼盘：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.basicInfo?.projectName}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">客户意向：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.description}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">经纪人：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.brokerName}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">经纪人电话：</h4>\n      <p class=\"preference-value\">\n        <a style=\"text-decoration:underline;\" (href)=\"'tel: ' + currentReferral?.brokerPhone\">{{currentReferral?.brokerPhone}}</a>\n      </p> \n    </ion-col>\n  </ion-row>\n\n  <ion-item-divider>\n    <ion-label>陪同客户事宜安排</ion-label>\n  </ion-item-divider>\n\n  <ion-item class=\"input-item\">\n    <ion-label position=\"floating\">客户描述</ion-label>\n    <ion-input type=\"text\" [value]=\"description\" clearInput (ionChange)=\"descriptionChange($event)\"></ion-input>\n  </ion-item>\n\n  <ion-item class=\"input-item item-label-floating\">\n    <ion-label position=\"floating\">陪同人员</ion-label>\n    <ion-select [value]=\"salesmanId\" cancelText=\"取消\" okText=\"确认\" (ionChange)=\"salesmanIdChange($event)\">\n      <ion-select-option *ngFor=\"let item of salesmans\" [value]=\"item?.id\" >{{ item?.realName }}</ion-select-option>\n    </ion-select>\n  </ion-item>\n\n  <!-- <ion-item class=\"input-item\">\n    <ion-label position=\"floating\">陪同人员</ion-label>\n    <ion-input type=\"number\" [value]=\"salesmanId\" clearInput (ionChange)=\"phoneChange($event)\"></ion-input>\n  </ion-item> -->\n  \n  <ion-button class=\"submit-btn\" type=\"submit\" expand=\"block\" fill=\"outline\"  [disabled]=\"userRole !== 'secretary'\" (click)=\"onSubmit()\">提交</ion-button>\n    \n\n</ion-content>\n");

/***/ }),

/***/ "UP0v":
/*!************************************************************!*\
  !*** ./src/app/pages/accompany/styles/accompany.page.scss ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host {\n  --page-background: var(--app-background-shade);\n  --page-highlighted-background: #00AFFF;\n  --page-margin: var(--app-fair-margin);\n  --page-tags-gutter: 5px;\n}\n\nion-header ion-toolbar {\n  --background: transparent;\n}\n\nion-content {\n  position: absolute;\n  top: 0;\n  border-top-style: solid;\n  border-top-color: var(--page-highlighted-background);\n}\n\n.transact-details-content {\n  --background: var(--page-background);\n  transform: translateZ(0);\n  /* Works - pass \"my-custom-class\" in cssClass to increase specificity */\n}\n\n.transact-details-content ion-item-divider {\n  --background: var(--page-background);\n  --padding-bottom: calc(var(--page-margin) / 2);\n  --padding-top: calc(var(--page-margin) / 2);\n  --padding-start: var(--page-margin);\n  --padding-end: var(--page-margin);\n  border: none;\n}\n\n.transact-details-content .user-details-wrapper {\n  --ion-grid-column-padding: 0px;\n  padding: 0px var(--page-margin) var(--page-margin);\n  background-color: var(--page-highlighted-background);\n  color: var(--ion-color-light);\n  align-items: center;\n}\n\n.transact-details-content .user-details-wrapper .user-avatar {\n  border: solid 3px var(--ion-color-light);\n}\n\n.transact-details-content .user-details-wrapper .user-info-wrapper {\n  padding-left: calc(var(--page-margin) / 2);\n}\n\n.transact-details-content .user-details-wrapper .user-info-wrapper .user-name {\n  margin: 0px 0px 5px;\n}\n\n.transact-details-content .user-details-wrapper .user-info-wrapper .user-handle {\n  margin: 0px;\n  font-weight: 400;\n}\n\n.transact-details-content .user-preferences-wrapper {\n  --ion-grid-column-padding: 0px;\n  padding: var(--page-margin);\n}\n\n.transact-details-content .user-preferences-wrapper .preference-name {\n  margin: 0px 0px 5px;\n  font-size: 16px;\n}\n\n.transact-details-content .user-preferences-wrapper .preference-value {\n  margin: 0px 0px calc(var(--page-margin) / 2);\n  font-size: 14px;\n  line-height: 1.4;\n  color: var(--ion-color-dark-tint);\n}\n\n.transact-details-content .radio-tags {\n  padding: 0px calc(var(--page-margin) - var(--page-tags-gutter));\n  background-color: var(--page-background);\n  justify-content: space-between;\n  --radio-tag-color: #000;\n  --radio-tag-background: #FFF;\n  --radio-tag-active-color: #FFF;\n  --radio-tag-active-background: #000;\n}\n\n.transact-details-content .radio-tags .radio-tag {\n  --padding-start: 0px;\n  --inner-padding-end: 8px;\n  --inner-padding-start: 8px;\n  --min-height: 18px;\n  --border-radius: 8px;\n  --border-width: 1px;\n  --border-style: solid;\n  --border-color: var(--radio-tag-color);\n  --ion-item-background: var(--radio-tag-background);\n  --ion-item-color: var(--radio-tag-color);\n  flex: 1;\n}\n\n.transact-details-content .radio-tags .radio-tag.item-radio-checked {\n  --ion-item-background: var(--radio-tag-active-background);\n  --ion-item-color: var(--radio-tag-active-color);\n}\n\n.transact-details-content .radio-tags .radio-tag.item-interactive-disabled {\n  opacity: 0.5;\n}\n\n.transact-details-content .radio-tags .radio-tag.item-interactive-disabled .tag-label {\n  opacity: 1;\n}\n\n.transact-details-content .radio-tags .radio-tag .tag-label {\n  margin: 5px;\n  font-size: 12px;\n  font-weight: 500;\n  letter-spacing: 0.2px;\n  text-align: center;\n}\n\n.transact-details-content .radio-tags .radio-tag ion-radio {\n  margin: 0px;\n  width: 0px;\n  --border-width: 0px;\n  height: 0px;\n  --color-checked: transparent;\n}\n\n.transact-details-content .radio-tags .radio-tag {\n  --radio-tag-color: var(--ion-color-secondary);\n  --radio-tag-background: var(--ion-color-lightest);\n  --radio-tag-active-color: var(--ion-color-lightest);\n  --radio-tag-active-background: var(--ion-color-secondary);\n  padding: 0px var(--page-tags-gutter);\n  margin: var(--page-tags-gutter) 0px;\n}\n\n.transact-details-content .submit-btn,\n.transact-details-content .tip-label {\n  margin: var(--page-margin);\n}\n\n.transact-details-content .user-bio {\n  padding: 0px var(--page-margin) var(--page-margin);\n  line-height: 1.2;\n  font-size: 14px;\n}\n\n.transact-details-content .user-stats-wrapper {\n  color: var(--ion-color-tertiary-tint);\n  text-align: center;\n  padding-top: calc(var(--page-margin) / 2);\n}\n\n.transact-details-content .user-stats-wrapper .user-stat-value {\n  margin-right: 5px;\n  font-weight: 500;\n  font-size: 14px;\n}\n\n.transact-details-content .user-stats-wrapper .user-stat-name {\n  font-size: 14px;\n  text-decoration: underline;\n}\n\n.transact-details-content .alert-wrapper {\n  background: #e5e5e5;\n}\n\n.transact-details-content .my-custom-class .alert-wrapper {\n  background: #e5e5e5;\n}\n\n.transact-details-content .input-item {\n  --background: var(--page-background);\n  --padding-start: var(--page-margin);\n  --padding-end: var(--page-margin);\n  --inner-padding-end: 0px;\n}\n\n:host-context(.ios) .radio-tags,\n:host-context(.ios) .checkbox-tags {\n  margin-bottom: calc(var(--page-margin) * 2);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2FjY29tcGFueS5wYWdlLnNjc3MiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi90aGVtZS9taXhpbnMvaW5wdXRzL3JhZGlvLXRhZy5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdBO0VBRUUsOENBQUE7RUFFQSxzQ0FBQTtFQUdBLHFDQUFBO0VBRUEsdUJBQUE7QUFQRjs7QUFjRTtFQUNFLHlCQUFBO0FBWEo7O0FBY0E7RUFDRSxrQkFBQTtFQUNBLE1BQUE7RUFFQSx1QkFBQTtFQUNBLG9EQUFBO0FBWkY7O0FBaUJBO0VBQ0Usb0NBQUE7RUFFQSx3QkFBQTtFQXNJQSx1RUFBQTtBQXBKRjs7QUFnQkU7RUFDQSxvQ0FBQTtFQUNBLDhDQUFBO0VBQ0EsMkNBQUE7RUFDQSxtQ0FBQTtFQUNBLGlDQUFBO0VBRUEsWUFBQTtBQWZGOztBQWtCRTtFQUNFLDhCQUFBO0VBRUEsa0RBQUE7RUFDQSxvREFBQTtFQUNBLDZCQUFBO0VBQ0EsbUJBQUE7QUFqQko7O0FBbUJJO0VBQ0Usd0NBQUE7QUFqQk47O0FBb0JJO0VBQ0UsMENBQUE7QUFsQk47O0FBb0JNO0VBQ0UsbUJBQUE7QUFsQlI7O0FBcUJNO0VBQ0UsV0FBQTtFQUNBLGdCQUFBO0FBbkJSOztBQTZDRTtFQUNFLDhCQUFBO0VBRUEsMkJBQUE7QUE1Q0o7O0FBOENJO0VBQ0UsbUJBQUE7RUFDQSxlQUFBO0FBNUNOOztBQStDSTtFQUNFLDRDQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUNBQUE7QUE3Q047O0FBbURFO0VBQ0UsK0RBQUE7RUFDRix3Q0FBQTtFQUNFLDhCQUFBO0VDcEhGLHVCQUFBO0VBQ0EsNEJBQUE7RUFDQSw4QkFBQTtFQUNBLG1DQUFBO0FEb0VGOztBQ2xFQztFQUVHLG9CQUFBO0VBQ0Esd0JBQUE7RUFDRiwwQkFBQTtFQUNFLGtCQUFBO0VBRUYsb0JBQUE7RUFDRSxtQkFBQTtFQUNGLHFCQUFBO0VBQ0Esc0NBQUE7RUFDQSxrREFBQTtFQUNBLHdDQUFBO0VBRUUsT0FBQTtBRGlFSjs7QUMvREU7RUFDSSx5REFBQTtFQUNBLCtDQUFBO0FEaUVOOztBQzlESTtFQUNFLFlBQUE7QURnRU47O0FDOURNO0VBRUUsVUFBQTtBRCtEUjs7QUMzREk7RUFDRCxXQUFBO0VBQ0csZUFBQTtFQUNBLGdCQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtBRDZETjs7QUMxREU7RUFDQyxXQUFBO0VBRUEsVUFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtFQUVBLDRCQUFBO0FEMERIOztBQWFJO0VBQ0UsNkNBQUE7RUFDQSxpREFBQTtFQUNBLG1EQUFBO0VBQ0EseURBQUE7RUFFQSxvQ0FBQTtFQUNBLG1DQUFBO0FBWk47O0FBaUJFOztFQUVFLDBCQUFBO0FBZko7O0FBa0JFO0VBQ0Usa0RBQUE7RUFFQSxnQkFBQTtFQUNBLGVBQUE7QUFqQko7O0FBb0JFO0VBQ0UscUNBQUE7RUFFQSxrQkFBQTtFQUNBLHlDQUFBO0FBbkJKOztBQXFCSTtFQUNFLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBbkJOOztBQXNCSTtFQUNFLGVBQUE7RUFDQSwwQkFBQTtBQXBCTjs7QUF5QkU7RUFDRSxtQkFBQTtBQXZCSjs7QUEyQkU7RUFDRSxtQkFBQTtBQXpCSjs7QUE0QkU7RUFDRSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsaUNBQUE7RUFDQSx3QkFBQTtBQTFCSjs7QUFnQ0U7O0VBRUUsMkNBQUE7QUE3QkoiLCJmaWxlIjoiYWNjb21wYW55LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBpbXBvcnQgXCIuLi8uLi8uLi8uLi90aGVtZS9taXhpbnMvaW5wdXRzL3JhZGlvLXRhZ1wiO1xuLy8gQ3VzdG9tIHZhcmlhYmxlc1xuLy8gTm90ZTogIFRoZXNlIG9uZXMgd2VyZSBhZGRlZCBieSB1cyBhbmQgaGF2ZSBub3RoaW5nIHRvIGRvIHdpdGggSW9uaWMgQ1NTIEN1c3RvbSBQcm9wZXJ0aWVzXG46aG9zdCB7XG4gIC8vIC0tcGFnZS1tYXJnaW46IHZhcigtLWFwcC1icm9hZC1tYXJnaW4pO1xuICAtLXBhZ2UtYmFja2dyb3VuZDogdmFyKC0tYXBwLWJhY2tncm91bmQtc2hhZGUpO1xuXG4gIC0tcGFnZS1oaWdobGlnaHRlZC1iYWNrZ3JvdW5kOiAjMDBBRkZGO1xuXG5cbiAgLS1wYWdlLW1hcmdpbjogdmFyKC0tYXBwLWZhaXItbWFyZ2luKTtcblxuICAtLXBhZ2UtdGFncy1ndXR0ZXI6IDVweDtcbn1cblxuLy8gTm90ZTogIEFsbCB0aGUgQ1NTIHZhcmlhYmxlcyBkZWZpbmVkIGJlbG93IGFyZSBvdmVycmlkZXMgb2YgSW9uaWMgZWxlbWVudHMgQ1NTIEN1c3RvbSBQcm9wZXJ0aWVzXG5cbi8vIFVzZSBhIGNvbG9yZWQgYm9yZGVyLXRvcCB0byBmaXggd2VpcmQgdHJhbnNpdGlvbnMgYmV0d2VlbiB0b29sYmFycyB0aGF0IGhhdmUgZGlmZmVyZW50IGJhY2tncm91bmQgY29sb3JzXG5pb24taGVhZGVyIHtcbiAgaW9uLXRvb2xiYXIge1xuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIH1cbn1cbmlvbi1jb250ZW50IHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDA7XG4gIC8vIGJvcmRlci10b3A6IGNhbGModmFyKC0tYXBwLWhlYWRlci1oZWlnaHQpICsgdmFyKC0taW9uLXNhZmUtYXJlYS10b3ApKTtcbiAgYm9yZGVyLXRvcC1zdHlsZTogc29saWQ7XG4gIGJvcmRlci10b3AtY29sb3I6IHZhcigtLXBhZ2UtaGlnaGxpZ2h0ZWQtYmFja2dyb3VuZCk7XG59XG5cblxuXG4udHJhbnNhY3QtZGV0YWlscy1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1wYWdlLWJhY2tncm91bmQpO1xuICAvLyBUbyBmaXggaGFsZiBwaXhlbCBsaW5lIGJldHdlZW4gaW9uLWhlYWRlciBhbmQgIGlvbi1jb250ZW50XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWigwKTtcblxuICBpb24taXRlbS1kaXZpZGVyIHtcblx0XHQtLWJhY2tncm91bmQ6IHZhcigtLXBhZ2UtYmFja2dyb3VuZCk7XG5cdFx0LS1wYWRkaW5nLWJvdHRvbTogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcblx0XHQtLXBhZGRpbmctdG9wOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDIpO1xuXHRcdC0tcGFkZGluZy1zdGFydDogdmFyKC0tcGFnZS1tYXJnaW4pO1xuXHRcdC0tcGFkZGluZy1lbmQ6IHZhcigtLXBhZ2UtbWFyZ2luKTtcblxuXHRcdGJvcmRlcjogbm9uZTtcblx0fVxuXG4gIC51c2VyLWRldGFpbHMtd3JhcHBlciB7XG4gICAgLS1pb24tZ3JpZC1jb2x1bW4tcGFkZGluZzogMHB4O1xuXG4gICAgcGFkZGluZzogMHB4IHZhcigtLXBhZ2UtbWFyZ2luKSB2YXIoLS1wYWdlLW1hcmdpbik7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tcGFnZS1oaWdobGlnaHRlZC1iYWNrZ3JvdW5kKTtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuXG4gICAgLnVzZXItYXZhdGFyIHtcbiAgICAgIGJvcmRlcjogc29saWQgM3B4IHZhcigtLWlvbi1jb2xvci1saWdodCk7XG4gICAgfVxuXG4gICAgLnVzZXItaW5mby13cmFwcGVyIHtcbiAgICAgIHBhZGRpbmctbGVmdDogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcblxuICAgICAgLnVzZXItbmFtZSB7XG4gICAgICAgIG1hcmdpbjogMHB4IDBweCA1cHg7XG4gICAgICB9XG5cbiAgICAgIC51c2VyLWhhbmRsZSB7XG4gICAgICAgIG1hcmdpbjogMHB4O1xuICAgICAgICBmb250LXdlaWdodDogNDAwO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIC51c2VyLXN0YXRzLXdyYXBwZXIge1xuICAgIC8vICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIC8vICAgcGFkZGluZy10b3A6IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMik7XG5cbiAgICAvLyAgIC51c2VyLXN0YXQtdmFsdWUge1xuICAgIC8vICAgICBtYXJnaW4tcmlnaHQ6IDVweDtcbiAgICAvLyAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAvLyAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgIC8vICAgfVxuXG4gICAgLy8gICAudXNlci1zdGF0LW5hbWUge1xuICAgIC8vICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgLy8gICB9XG4gICAgLy8gfVxuXG4gICAgLy8gLnVzZXItYmlvIHtcbiAgICAvLyAgIG1hcmdpbjogdmFyKC0tcGFnZS1tYXJnaW4pIDBweCAwcHg7XG4gICAgLy8gICBsaW5lLWhlaWdodDogMS4yO1xuICAgIC8vICAgZm9udC1zaXplOiAxNHB4O1xuICAgIC8vIH1cbiAgfVxuXG4gIC51c2VyLXByZWZlcmVuY2VzLXdyYXBwZXIge1xuICAgIC0taW9uLWdyaWQtY29sdW1uLXBhZGRpbmc6IDBweDtcblxuICAgIHBhZGRpbmc6IHZhcigtLXBhZ2UtbWFyZ2luKTtcblxuICAgIC5wcmVmZXJlbmNlLW5hbWUge1xuICAgICAgbWFyZ2luOiAwcHggMHB4IDVweDtcbiAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICB9XG5cbiAgICAucHJlZmVyZW5jZS12YWx1ZSB7XG4gICAgICBtYXJnaW46IDBweCAwcHggY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgIGxpbmUtaGVpZ2h0OiAxLjQ7XG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmstdGludCk7XG4gICAgfVxuXG5cbiAgfVxuXG4gIC5yYWRpby10YWdzIHtcbiAgICBwYWRkaW5nOiAwcHggY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLSB2YXIoLS1wYWdlLXRhZ3MtZ3V0dGVyKSk7XG5cdFx0YmFja2dyb3VuZC1jb2xvcjogdmFyKC0tcGFnZS1iYWNrZ3JvdW5kKTtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG5cblx0XHRAaW5jbHVkZSByYWRpby10YWcoKTtcblxuICAgIC8vIEFkZCBhIGRlZXBlciBzZWxlY3RvciB0byBvdmVycmlkZSBkZWZhdWx0IGNvbG9yc1xuICAgIC5yYWRpby10YWcge1xuICAgICAgLS1yYWRpby10YWctY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xuICAgICAgLS1yYWRpby10YWctYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWxpZ2h0ZXN0KTtcbiAgICAgIC0tcmFkaW8tdGFnLWFjdGl2ZS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0ZXN0KTtcbiAgICAgIC0tcmFkaW8tdGFnLWFjdGl2ZS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kYXJ5KTtcblxuICAgICAgcGFkZGluZzogMHB4IHZhcigtLXBhZ2UtdGFncy1ndXR0ZXIpO1xuICAgICAgbWFyZ2luOiB2YXIoLS1wYWdlLXRhZ3MtZ3V0dGVyKSAwcHg7XG4gICAgfVxuXG5cdH1cblxuICAuc3VibWl0LWJ0bixcbiAgLnRpcC1sYWJlbCB7XG4gICAgbWFyZ2luOiB2YXIoLS1wYWdlLW1hcmdpbik7XG4gIH1cblxuICAudXNlci1iaW8ge1xuICAgIHBhZGRpbmc6IDBweCB2YXIoLS1wYWdlLW1hcmdpbikgdmFyKC0tcGFnZS1tYXJnaW4pO1xuICAgIC8vIG1hcmdpbjogdmFyKC0tcGFnZS1tYXJnaW4pIDBweCAwcHg7XG4gICAgbGluZS1oZWlnaHQ6IDEuMjtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gIH1cblxuICAudXNlci1zdGF0cy13cmFwcGVyIHtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5LXRpbnQpO1xuICAgIFxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwYWRkaW5nLXRvcDogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcblxuICAgIC51c2VyLXN0YXQtdmFsdWUge1xuICAgICAgbWFyZ2luLXJpZ2h0OiA1cHg7XG4gICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgIH1cblxuICAgIC51c2VyLXN0YXQtbmFtZSB7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgICB9XG4gIH1cblxuXG4gIC5hbGVydC13cmFwcGVyIHtcbiAgICBiYWNrZ3JvdW5kOiAjZTVlNWU1O1xuICB9XG4gIFxuICAvKiBXb3JrcyAtIHBhc3MgXCJteS1jdXN0b20tY2xhc3NcIiBpbiBjc3NDbGFzcyB0byBpbmNyZWFzZSBzcGVjaWZpY2l0eSAqL1xuICAubXktY3VzdG9tLWNsYXNzIC5hbGVydC13cmFwcGVyIHtcbiAgICBiYWNrZ3JvdW5kOiAjZTVlNWU1O1xuICB9XG5cbiAgLmlucHV0LWl0ZW0ge1xuICAgIC0tYmFja2dyb3VuZDogdmFyKC0tcGFnZS1iYWNrZ3JvdW5kKTtcbiAgICAtLXBhZGRpbmctc3RhcnQ6IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgICAtLXBhZGRpbmctZW5kOiB2YXIoLS1wYWdlLW1hcmdpbik7XG4gICAgLS1pbm5lci1wYWRkaW5nLWVuZDogMHB4O1xuXG4gIH1cbn1cblxuOmhvc3QtY29udGV4dCguaW9zKSB7XG4gIC5yYWRpby10YWdzLFxuICAuY2hlY2tib3gtdGFncyB7XG4gICAgbWFyZ2luLWJvdHRvbTogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgKiAyKTtcbiAgfVxufVxuIiwiQG1peGluIHJhZGlvLXRhZygpIHtcbiAgLy8gRGVmYXVsdCB2YWx1ZXNcbiAgLS1yYWRpby10YWctY29sb3I6ICMwMDA7XG4gIC0tcmFkaW8tdGFnLWJhY2tncm91bmQ6ICNGRkY7XG4gIC0tcmFkaW8tdGFnLWFjdGl2ZS1jb2xvcjogI0ZGRjtcbiAgLS1yYWRpby10YWctYWN0aXZlLWJhY2tncm91bmQ6ICMwMDA7XG5cblx0LnJhZGlvLXRhZyB7XG4gICAgLy8gUmVzZXQgdmFsdWVzIGZyb20gSW9uaWMgKGlvbi1pdGVtKSBzdHlsZXNcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDBweDtcbiAgICAtLWlubmVyLXBhZGRpbmctZW5kOiA4cHg7XG5cdFx0LS1pbm5lci1wYWRkaW5nLXN0YXJ0OiA4cHg7XG4gICAgLS1taW4taGVpZ2h0OiAxOHB4O1xuXG5cdFx0LS1ib3JkZXItcmFkaXVzOiA4cHg7XG4gICAgLS1ib3JkZXItd2lkdGg6IDFweDtcblx0XHQtLWJvcmRlci1zdHlsZTogc29saWQ7XG5cdFx0LS1ib3JkZXItY29sb3I6IHZhcigtLXJhZGlvLXRhZy1jb2xvcik7XG5cdFx0LS1pb24taXRlbS1iYWNrZ3JvdW5kOiB2YXIoLS1yYWRpby10YWctYmFja2dyb3VuZCk7XG5cdFx0LS1pb24taXRlbS1jb2xvcjogdmFyKC0tcmFkaW8tdGFnLWNvbG9yKTtcblxuICAgIGZsZXg6IDE7XG5cblx0XHQmLml0ZW0tcmFkaW8tY2hlY2tlZCB7XG4gICAgICAtLWlvbi1pdGVtLWJhY2tncm91bmQ6IHZhcigtLXJhZGlvLXRhZy1hY3RpdmUtYmFja2dyb3VuZCk7XG4gICAgICAtLWlvbi1pdGVtLWNvbG9yOiB2YXIoLS1yYWRpby10YWctYWN0aXZlLWNvbG9yKTtcblx0XHR9XG5cbiAgICAmLml0ZW0taW50ZXJhY3RpdmUtZGlzYWJsZWQge1xuICAgICAgb3BhY2l0eTogMC41O1xuXG4gICAgICAudGFnLWxhYmVsIHtcbiAgICAgICAgLy8gT3ZlcnJpZGUgSW9uaWMgZGVmYXVsdCBzdHlsZVxuICAgICAgICBvcGFjaXR5OiAxO1xuICAgICAgfVxuICAgIH1cblxuICAgIC50YWctbGFiZWwge1xuXHRcdFx0bWFyZ2luOiA1cHg7XG4gICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgbGV0dGVyLXNwYWNpbmc6IDAuMnB4O1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuXHRcdH1cblxuXHRcdGlvbi1yYWRpbyB7XG5cdFx0XHRtYXJnaW46IDBweDtcblx0XHRcdC8vIFRvIGhpZGUgdGhlIC5yYWRpby1pY29uXG5cdFx0XHR3aWR0aDogMHB4O1xuXHRcdFx0LS1ib3JkZXItd2lkdGg6IDBweDtcblx0XHRcdGhlaWdodDogMHB4O1xuXHRcdFx0Ly8gV2UgY2FudCBzZXQgd2lkdGggYW5kIGhlaWdodCBmb3IgLnJhZGlvLWljb24gLnJhZGlvLWlubmVyLCBzbyBsZXRzIGhpZGUgaXQgY2hhbmdpbmcgaXRzIGNvbG9yXG5cdFx0XHQtLWNvbG9yLWNoZWNrZWQ6IHRyYW5zcGFyZW50O1xuXHRcdH1cblx0fVxufVxuIl19 */");

/***/ }),

/***/ "b4MU":
/*!***************************************************!*\
  !*** ./src/app/pages/accompany/accompany.page.ts ***!
  \***************************************************/
/*! exports provided: AccompanyPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccompanyPage", function() { return AccompanyPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_accompany_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./accompany.page.html */ "EljO");
/* harmony import */ var _styles_accompany_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/accompany.page.scss */ "UP0v");
/* harmony import */ var _styles_accompany_shell_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./styles/accompany.shell.scss */ "jzLY");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var ngx_clipboard__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-clipboard */ "Dvla");
/* harmony import */ var _allocation_allocation_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../allocation/allocation.service */ "PqGj");
/* harmony import */ var _deal_deal_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../deal/deal.service */ "3cZy");










let AccompanyPage = class AccompanyPage {
    constructor(route, router, dealService, alertController, allocationService, _clipboardService) {
        this.router = router;
        this.dealService = dealService;
        this.alertController = alertController;
        this.allocationService = allocationService;
        this._clipboardService = _clipboardService;
        this.salesmans = [];
        this.referralId = route.snapshot.params['referralId'];
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.userRole = localStorage.getItem('userRole');
        this.dealService.getReferrals(this.referralId).subscribe(data => {
            var _a, _b, _c;
            if (data.data != null) {
                const phone = (_a = data.data) === null || _a === void 0 ? void 0 : _a.phone.replace(/(\d{3})(\d{4})(\d{4})/, "$1****$3");
                this.currentReferral = data.data;
                this.currentReferral.phone = phone;
                this.description = (_b = this.currentReferral) === null || _b === void 0 ? void 0 : _b.description;
                this.salesmanId = (_c = this.currentReferral) === null || _c === void 0 ? void 0 : _c.salesmanId;
            }
        });
        this.allocationService.getSalesmansList().subscribe(resp => {
            var _a;
            if (resp.ok) {
                this.salesmans = resp.data;
                this.salesmans.push({ id: (_a = this.currentUser) === null || _a === void 0 ? void 0 : _a.mktUserId, realName: '我' });
            }
        });
    }
    ngOnInit() {
    }
    presentAlertConfirm() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: '录入成功',
                message: '您添加陪同信息录入成功，请线下确认相关事宜！',
                backdropDismiss: false,
                buttons: [
                    {
                        text: '关闭页面',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: () => {
                            // console.log('Confirm Cancel: blah');
                            WeixinJSBridge.call('closeWindow');
                        }
                    }
                    // , {
                    //   text: '返回首页',
                    //   handler: () => {
                    //     // console.log('Confirm Okay');
                    //     this.router.navigate(['/app/referrals']);
                    //   }
                    // }
                ]
            });
            yield alert.present();
        });
    }
    onSubmit() {
        var _a;
        //
        if (this.referralId == null)
            return;
        if (this.userRole !== 'secretary')
            return;
        if (((_a = this.currentReferral) === null || _a === void 0 ? void 0 : _a.substitute) !== '2')
            return;
        this.dealService.updateReferralsDock(this.referralId, this.description, this.salesmanId).subscribe(res => {
            this.presentAlertConfirm();
        });
    }
    descriptionChange(ev) {
        this.description = ev.detail.value;
    }
    salesmanIdChange(ev) {
        this.salesmanId = ev.detail.value;
    }
};
AccompanyPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _deal_deal_service__WEBPACK_IMPORTED_MODULE_9__["DealService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] },
    { type: _allocation_allocation_service__WEBPACK_IMPORTED_MODULE_8__["AllocationService"] },
    { type: ngx_clipboard__WEBPACK_IMPORTED_MODULE_7__["ClipboardService"] }
];
AccompanyPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-accompany',
        template: _raw_loader_accompany_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_styles_accompany_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"], _styles_accompany_shell_scss__WEBPACK_IMPORTED_MODULE_3__["default"]]
    })
], AccompanyPage);



/***/ }),

/***/ "jzLY":
/*!*************************************************************!*\
  !*** ./src/app/pages/accompany/styles/accompany.shell.scss ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("app-image-shell.user-avatar {\n  --image-shell-loading-background: rgba(var(--ion-color-light-rgb), 0.25);\n  --image-shell-border-radius: 50%;\n  --image-shell-spinner-color: var(--ion-color-light);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2FjY29tcGFueS5zaGVsbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usd0VBQUE7RUFDQSxnQ0FBQTtFQUNBLG1EQUFBO0FBQ0YiLCJmaWxlIjoiYWNjb21wYW55LnNoZWxsLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJhcHAtaW1hZ2Utc2hlbGwudXNlci1hdmF0YXIge1xuICAtLWltYWdlLXNoZWxsLWxvYWRpbmctYmFja2dyb3VuZDogcmdiYSh2YXIoLS1pb24tY29sb3ItbGlnaHQtcmdiKSwgMC4yNSk7XG4gIC0taW1hZ2Utc2hlbGwtYm9yZGVyLXJhZGl1czogNTAlO1xuICAtLWltYWdlLXNoZWxsLXNwaW5uZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodCk7XG59XG4iXX0= */");

/***/ })

}]);
//# sourceMappingURL=pages-accompany-accompany-module.js.map