(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-transact-details-transact-details-module"],{

/***/ "IV9T":
/*!**************************************************************************!*\
  !*** ./src/app/pages/transact/details/styles/transact-details.page.scss ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host {\n  --page-background: var(--app-background-shade);\n  --page-highlighted-background: #00AFFF;\n  --page-margin: var(--app-fair-margin);\n  --page-tags-gutter: 5px;\n}\n\nion-header ion-toolbar {\n  --background: transparent;\n}\n\nion-content {\n  position: absolute;\n  top: 0;\n  border-top-style: solid;\n  border-top-color: var(--page-highlighted-background);\n}\n\n.transact-details-content {\n  --background: var(--page-background);\n  transform: translateZ(0);\n  /* Works - pass \"my-custom-class\" in cssClass to increase specificity */\n}\n\n.transact-details-content ion-item-divider {\n  --background: var(--page-background);\n  --padding-bottom: calc(var(--page-margin) / 2);\n  --padding-top: calc(var(--page-margin) / 2);\n  --padding-start: var(--page-margin);\n  --padding-end: var(--page-margin);\n  border: none;\n}\n\n.transact-details-content .user-details-wrapper {\n  --ion-grid-column-padding: 0px;\n  padding: 0px var(--page-margin) var(--page-margin);\n  background-color: var(--page-highlighted-background);\n  color: var(--ion-color-light);\n  align-items: center;\n}\n\n.transact-details-content .user-details-wrapper .user-avatar {\n  border: solid 3px var(--ion-color-light);\n}\n\n.transact-details-content .user-details-wrapper .user-info-wrapper {\n  padding-left: calc(var(--page-margin) / 2);\n}\n\n.transact-details-content .user-details-wrapper .user-info-wrapper .user-name {\n  margin: 0px 0px 5px;\n}\n\n.transact-details-content .user-details-wrapper .user-info-wrapper .user-handle {\n  margin: 0px;\n  font-weight: 400;\n}\n\n.transact-details-content .user-preferences-wrapper {\n  --ion-grid-column-padding: 0px;\n  padding: var(--page-margin);\n}\n\n.transact-details-content .user-preferences-wrapper .preference-name {\n  margin: 0px 0px 5px;\n  font-size: 16px;\n}\n\n.transact-details-content .user-preferences-wrapper .preference-value {\n  margin: 0px 0px calc(var(--page-margin) / 2);\n  font-size: 14px;\n  line-height: 1.4;\n  color: var(--ion-color-dark-tint);\n}\n\n.transact-details-content .radio-tags {\n  padding: 0px calc(var(--page-margin) - var(--page-tags-gutter));\n  background-color: var(--page-background);\n  justify-content: space-between;\n  --radio-tag-color: #000;\n  --radio-tag-background: #FFF;\n  --radio-tag-active-color: #FFF;\n  --radio-tag-active-background: #000;\n}\n\n.transact-details-content .radio-tags .radio-tag {\n  --padding-start: 0px;\n  --inner-padding-end: 8px;\n  --inner-padding-start: 8px;\n  --min-height: 18px;\n  --border-radius: 8px;\n  --border-width: 1px;\n  --border-style: solid;\n  --border-color: var(--radio-tag-color);\n  --ion-item-background: var(--radio-tag-background);\n  --ion-item-color: var(--radio-tag-color);\n  flex: 1;\n}\n\n.transact-details-content .radio-tags .radio-tag.item-radio-checked {\n  --ion-item-background: var(--radio-tag-active-background);\n  --ion-item-color: var(--radio-tag-active-color);\n}\n\n.transact-details-content .radio-tags .radio-tag.item-interactive-disabled {\n  opacity: 0.5;\n}\n\n.transact-details-content .radio-tags .radio-tag.item-interactive-disabled .tag-label {\n  opacity: 1;\n}\n\n.transact-details-content .radio-tags .radio-tag .tag-label {\n  margin: 5px;\n  font-size: 12px;\n  font-weight: 500;\n  letter-spacing: 0.2px;\n  text-align: center;\n}\n\n.transact-details-content .radio-tags .radio-tag ion-radio {\n  margin: 0px;\n  width: 0px;\n  --border-width: 0px;\n  height: 0px;\n  --color-checked: transparent;\n}\n\n.transact-details-content .radio-tags .radio-tag {\n  --radio-tag-color: var(--ion-color-secondary);\n  --radio-tag-background: var(--ion-color-lightest);\n  --radio-tag-active-color: var(--ion-color-lightest);\n  --radio-tag-active-background: var(--ion-color-secondary);\n  padding: 0px var(--page-tags-gutter);\n  margin: var(--page-tags-gutter) 0px;\n}\n\n.transact-details-content .submit-btn,\n.transact-details-content .tip-label {\n  margin: var(--page-margin);\n}\n\n.transact-details-content .user-bio {\n  padding: 0px var(--page-margin) var(--page-margin);\n  line-height: 1.2;\n  font-size: 14px;\n}\n\n.transact-details-content .user-stats-wrapper {\n  color: var(--ion-color-tertiary-tint);\n  text-align: center;\n  padding-top: calc(var(--page-margin) / 2);\n}\n\n.transact-details-content .user-stats-wrapper .user-stat-value {\n  margin-right: 5px;\n  font-weight: 500;\n  font-size: 14px;\n}\n\n.transact-details-content .user-stats-wrapper .user-stat-name {\n  font-size: 14px;\n  text-decoration: underline;\n}\n\n.transact-details-content .alert-wrapper {\n  background: #e5e5e5;\n}\n\n.transact-details-content .my-custom-class .alert-wrapper {\n  background: #e5e5e5;\n}\n\n:host-context(.ios) .radio-tags,\n:host-context(.ios) .checkbox-tags {\n  margin-bottom: calc(var(--page-margin) * 2);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3RyYW5zYWN0LWRldGFpbHMucGFnZS5zY3NzIiwiLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vdGhlbWUvbWl4aW5zL2lucHV0cy9yYWRpby10YWcuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHQTtFQUVFLDhDQUFBO0VBRUEsc0NBQUE7RUFHQSxxQ0FBQTtFQUVBLHVCQUFBO0FBUEY7O0FBY0U7RUFDRSx5QkFBQTtBQVhKOztBQWNBO0VBQ0Usa0JBQUE7RUFDQSxNQUFBO0VBRUEsdUJBQUE7RUFDQSxvREFBQTtBQVpGOztBQWVBO0VBQ0Usb0NBQUE7RUFFQSx3QkFBQTtFQXNJQSx1RUFBQTtBQWxKRjs7QUFjRTtFQUNBLG9DQUFBO0VBQ0EsOENBQUE7RUFDQSwyQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsaUNBQUE7RUFFQSxZQUFBO0FBYkY7O0FBZ0JFO0VBQ0UsOEJBQUE7RUFFQSxrREFBQTtFQUNBLG9EQUFBO0VBQ0EsNkJBQUE7RUFDQSxtQkFBQTtBQWZKOztBQWlCSTtFQUNFLHdDQUFBO0FBZk47O0FBa0JJO0VBQ0UsMENBQUE7QUFoQk47O0FBa0JNO0VBQ0UsbUJBQUE7QUFoQlI7O0FBbUJNO0VBQ0UsV0FBQTtFQUNBLGdCQUFBO0FBakJSOztBQTJDRTtFQUNFLDhCQUFBO0VBRUEsMkJBQUE7QUExQ0o7O0FBNENJO0VBQ0UsbUJBQUE7RUFDQSxlQUFBO0FBMUNOOztBQTZDSTtFQUNFLDRDQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUNBQUE7QUEzQ047O0FBaURFO0VBQ0UsK0RBQUE7RUFDRix3Q0FBQTtFQUNFLDhCQUFBO0VDbEhGLHVCQUFBO0VBQ0EsNEJBQUE7RUFDQSw4QkFBQTtFQUNBLG1DQUFBO0FEb0VGOztBQ2xFQztFQUVHLG9CQUFBO0VBQ0Esd0JBQUE7RUFDRiwwQkFBQTtFQUNFLGtCQUFBO0VBRUYsb0JBQUE7RUFDRSxtQkFBQTtFQUNGLHFCQUFBO0VBQ0Esc0NBQUE7RUFDQSxrREFBQTtFQUNBLHdDQUFBO0VBRUUsT0FBQTtBRGlFSjs7QUMvREU7RUFDSSx5REFBQTtFQUNBLCtDQUFBO0FEaUVOOztBQzlESTtFQUNFLFlBQUE7QURnRU47O0FDOURNO0VBRUUsVUFBQTtBRCtEUjs7QUMzREk7RUFDRCxXQUFBO0VBQ0csZUFBQTtFQUNBLGdCQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtBRDZETjs7QUMxREU7RUFDQyxXQUFBO0VBRUEsVUFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtFQUVBLDRCQUFBO0FEMERIOztBQVdJO0VBQ0UsNkNBQUE7RUFDQSxpREFBQTtFQUNBLG1EQUFBO0VBQ0EseURBQUE7RUFFQSxvQ0FBQTtFQUNBLG1DQUFBO0FBVk47O0FBZUU7O0VBRUUsMEJBQUE7QUFiSjs7QUFnQkU7RUFDRSxrREFBQTtFQUVBLGdCQUFBO0VBQ0EsZUFBQTtBQWZKOztBQWtCRTtFQUNFLHFDQUFBO0VBRUEsa0JBQUE7RUFDQSx5Q0FBQTtBQWpCSjs7QUFtQkk7RUFDRSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQWpCTjs7QUFvQkk7RUFDRSxlQUFBO0VBQ0EsMEJBQUE7QUFsQk47O0FBdUJFO0VBQ0UsbUJBQUE7QUFyQko7O0FBeUJFO0VBQ0UsbUJBQUE7QUF2Qko7O0FBNEJFOztFQUVFLDJDQUFBO0FBekJKIiwiZmlsZSI6InRyYW5zYWN0LWRldGFpbHMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGltcG9ydCBcIi4uLy4uLy4uLy4uLy4uL3RoZW1lL21peGlucy9pbnB1dHMvcmFkaW8tdGFnXCI7XG4vLyBDdXN0b20gdmFyaWFibGVzXG4vLyBOb3RlOiAgVGhlc2Ugb25lcyB3ZXJlIGFkZGVkIGJ5IHVzIGFuZCBoYXZlIG5vdGhpbmcgdG8gZG8gd2l0aCBJb25pYyBDU1MgQ3VzdG9tIFByb3BlcnRpZXNcbjpob3N0IHtcbiAgLy8gLS1wYWdlLW1hcmdpbjogdmFyKC0tYXBwLWJyb2FkLW1hcmdpbik7XG4gIC0tcGFnZS1iYWNrZ3JvdW5kOiB2YXIoLS1hcHAtYmFja2dyb3VuZC1zaGFkZSk7XG5cbiAgLS1wYWdlLWhpZ2hsaWdodGVkLWJhY2tncm91bmQ6ICMwMEFGRkY7XG5cblxuICAtLXBhZ2UtbWFyZ2luOiB2YXIoLS1hcHAtZmFpci1tYXJnaW4pO1xuXG4gIC0tcGFnZS10YWdzLWd1dHRlcjogNXB4O1xufVxuXG4vLyBOb3RlOiAgQWxsIHRoZSBDU1MgdmFyaWFibGVzIGRlZmluZWQgYmVsb3cgYXJlIG92ZXJyaWRlcyBvZiBJb25pYyBlbGVtZW50cyBDU1MgQ3VzdG9tIFByb3BlcnRpZXNcblxuLy8gVXNlIGEgY29sb3JlZCBib3JkZXItdG9wIHRvIGZpeCB3ZWlyZCB0cmFuc2l0aW9ucyBiZXR3ZWVuIHRvb2xiYXJzIHRoYXQgaGF2ZSBkaWZmZXJlbnQgYmFja2dyb3VuZCBjb2xvcnNcbmlvbi1oZWFkZXIge1xuICBpb24tdG9vbGJhciB7XG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgfVxufVxuaW9uLWNvbnRlbnQge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMDtcbiAgLy8gYm9yZGVyLXRvcDogY2FsYyh2YXIoLS1hcHAtaGVhZGVyLWhlaWdodCkgKyB2YXIoLS1pb24tc2FmZS1hcmVhLXRvcCkpO1xuICBib3JkZXItdG9wLXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLXRvcC1jb2xvcjogdmFyKC0tcGFnZS1oaWdobGlnaHRlZC1iYWNrZ3JvdW5kKTtcbn1cblxuLnRyYW5zYWN0LWRldGFpbHMtY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogdmFyKC0tcGFnZS1iYWNrZ3JvdW5kKTtcbiAgLy8gVG8gZml4IGhhbGYgcGl4ZWwgbGluZSBiZXR3ZWVuIGlvbi1oZWFkZXIgYW5kICBpb24tY29udGVudFxuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVooMCk7XG5cbiAgaW9uLWl0ZW0tZGl2aWRlciB7XG5cdFx0LS1iYWNrZ3JvdW5kOiB2YXIoLS1wYWdlLWJhY2tncm91bmQpO1xuXHRcdC0tcGFkZGluZy1ib3R0b206IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMik7XG5cdFx0LS1wYWRkaW5nLXRvcDogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcblx0XHQtLXBhZGRpbmctc3RhcnQ6IHZhcigtLXBhZ2UtbWFyZ2luKTtcblx0XHQtLXBhZGRpbmctZW5kOiB2YXIoLS1wYWdlLW1hcmdpbik7XG5cblx0XHRib3JkZXI6IG5vbmU7XG5cdH1cblxuICAudXNlci1kZXRhaWxzLXdyYXBwZXIge1xuICAgIC0taW9uLWdyaWQtY29sdW1uLXBhZGRpbmc6IDBweDtcblxuICAgIHBhZGRpbmc6IDBweCB2YXIoLS1wYWdlLW1hcmdpbikgdmFyKC0tcGFnZS1tYXJnaW4pO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLXBhZ2UtaGlnaGxpZ2h0ZWQtYmFja2dyb3VuZCk7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodCk7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgIC51c2VyLWF2YXRhciB7XG4gICAgICBib3JkZXI6IHNvbGlkIDNweCB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xuICAgIH1cblxuICAgIC51c2VyLWluZm8td3JhcHBlciB7XG4gICAgICBwYWRkaW5nLWxlZnQ6IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMik7XG5cbiAgICAgIC51c2VyLW5hbWUge1xuICAgICAgICBtYXJnaW46IDBweCAwcHggNXB4O1xuICAgICAgfVxuXG4gICAgICAudXNlci1oYW5kbGUge1xuICAgICAgICBtYXJnaW46IDBweDtcbiAgICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyAudXNlci1zdGF0cy13cmFwcGVyIHtcbiAgICAvLyAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAvLyAgIHBhZGRpbmctdG9wOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDIpO1xuXG4gICAgLy8gICAudXNlci1zdGF0LXZhbHVlIHtcbiAgICAvLyAgICAgbWFyZ2luLXJpZ2h0OiA1cHg7XG4gICAgLy8gICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgLy8gICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAvLyAgIH1cblxuICAgIC8vICAgLnVzZXItc3RhdC1uYW1lIHtcbiAgICAvLyAgICAgZm9udC1zaXplOiAxNnB4O1xuICAgIC8vICAgfVxuICAgIC8vIH1cblxuICAgIC8vIC51c2VyLWJpbyB7XG4gICAgLy8gICBtYXJnaW46IHZhcigtLXBhZ2UtbWFyZ2luKSAwcHggMHB4O1xuICAgIC8vICAgbGluZS1oZWlnaHQ6IDEuMjtcbiAgICAvLyAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAvLyB9XG4gIH1cblxuICAudXNlci1wcmVmZXJlbmNlcy13cmFwcGVyIHtcbiAgICAtLWlvbi1ncmlkLWNvbHVtbi1wYWRkaW5nOiAwcHg7XG5cbiAgICBwYWRkaW5nOiB2YXIoLS1wYWdlLW1hcmdpbik7XG5cbiAgICAucHJlZmVyZW5jZS1uYW1lIHtcbiAgICAgIG1hcmdpbjogMHB4IDBweCA1cHg7XG4gICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgfVxuXG4gICAgLnByZWZlcmVuY2UtdmFsdWUge1xuICAgICAgbWFyZ2luOiAwcHggMHB4IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMik7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICBsaW5lLWhlaWdodDogMS40O1xuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrLXRpbnQpO1xuICAgIH1cblxuXG4gIH1cblxuICAucmFkaW8tdGFncyB7XG4gICAgcGFkZGluZzogMHB4IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC0gdmFyKC0tcGFnZS10YWdzLWd1dHRlcikpO1xuXHRcdGJhY2tncm91bmQtY29sb3I6IHZhcigtLXBhZ2UtYmFja2dyb3VuZCk7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuXG5cdFx0QGluY2x1ZGUgcmFkaW8tdGFnKCk7XG5cbiAgICAvLyBBZGQgYSBkZWVwZXIgc2VsZWN0b3IgdG8gb3ZlcnJpZGUgZGVmYXVsdCBjb2xvcnNcbiAgICAucmFkaW8tdGFnIHtcbiAgICAgIC0tcmFkaW8tdGFnLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kYXJ5KTtcbiAgICAgIC0tcmFkaW8tdGFnLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1saWdodGVzdCk7XG4gICAgICAtLXJhZGlvLXRhZy1hY3RpdmUtY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodGVzdCk7XG4gICAgICAtLXJhZGlvLXRhZy1hY3RpdmUtYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeSk7XG5cbiAgICAgIHBhZGRpbmc6IDBweCB2YXIoLS1wYWdlLXRhZ3MtZ3V0dGVyKTtcbiAgICAgIG1hcmdpbjogdmFyKC0tcGFnZS10YWdzLWd1dHRlcikgMHB4O1xuICAgIH1cblxuXHR9XG5cbiAgLnN1Ym1pdC1idG4sXG4gIC50aXAtbGFiZWwge1xuICAgIG1hcmdpbjogdmFyKC0tcGFnZS1tYXJnaW4pO1xuICB9XG5cbiAgLnVzZXItYmlvIHtcbiAgICBwYWRkaW5nOiAwcHggdmFyKC0tcGFnZS1tYXJnaW4pIHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgICAvLyBtYXJnaW46IHZhcigtLXBhZ2UtbWFyZ2luKSAwcHggMHB4O1xuICAgIGxpbmUtaGVpZ2h0OiAxLjI7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICB9XG5cbiAgLnVzZXItc3RhdHMtd3JhcHBlciB7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeS10aW50KTtcbiAgICBcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgcGFkZGluZy10b3A6IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMik7XG5cbiAgICAudXNlci1zdGF0LXZhbHVlIHtcbiAgICAgIG1hcmdpbi1yaWdodDogNXB4O1xuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICB9XG5cbiAgICAudXNlci1zdGF0LW5hbWUge1xuICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgfVxuICB9XG5cblxuICAuYWxlcnQtd3JhcHBlciB7XG4gICAgYmFja2dyb3VuZDogI2U1ZTVlNTtcbiAgfVxuICBcbiAgLyogV29ya3MgLSBwYXNzIFwibXktY3VzdG9tLWNsYXNzXCIgaW4gY3NzQ2xhc3MgdG8gaW5jcmVhc2Ugc3BlY2lmaWNpdHkgKi9cbiAgLm15LWN1c3RvbS1jbGFzcyAuYWxlcnQtd3JhcHBlciB7XG4gICAgYmFja2dyb3VuZDogI2U1ZTVlNTtcbiAgfVxufVxuXG46aG9zdC1jb250ZXh0KC5pb3MpIHtcbiAgLnJhZGlvLXRhZ3MsXG4gIC5jaGVja2JveC10YWdzIHtcbiAgICBtYXJnaW4tYm90dG9tOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAqIDIpO1xuICB9XG59XG4iLCJAbWl4aW4gcmFkaW8tdGFnKCkge1xuICAvLyBEZWZhdWx0IHZhbHVlc1xuICAtLXJhZGlvLXRhZy1jb2xvcjogIzAwMDtcbiAgLS1yYWRpby10YWctYmFja2dyb3VuZDogI0ZGRjtcbiAgLS1yYWRpby10YWctYWN0aXZlLWNvbG9yOiAjRkZGO1xuICAtLXJhZGlvLXRhZy1hY3RpdmUtYmFja2dyb3VuZDogIzAwMDtcblxuXHQucmFkaW8tdGFnIHtcbiAgICAvLyBSZXNldCB2YWx1ZXMgZnJvbSBJb25pYyAoaW9uLWl0ZW0pIHN0eWxlc1xuICAgIC0tcGFkZGluZy1zdGFydDogMHB4O1xuICAgIC0taW5uZXItcGFkZGluZy1lbmQ6IDhweDtcblx0XHQtLWlubmVyLXBhZGRpbmctc3RhcnQ6IDhweDtcbiAgICAtLW1pbi1oZWlnaHQ6IDE4cHg7XG5cblx0XHQtLWJvcmRlci1yYWRpdXM6IDhweDtcbiAgICAtLWJvcmRlci13aWR0aDogMXB4O1xuXHRcdC0tYm9yZGVyLXN0eWxlOiBzb2xpZDtcblx0XHQtLWJvcmRlci1jb2xvcjogdmFyKC0tcmFkaW8tdGFnLWNvbG9yKTtcblx0XHQtLWlvbi1pdGVtLWJhY2tncm91bmQ6IHZhcigtLXJhZGlvLXRhZy1iYWNrZ3JvdW5kKTtcblx0XHQtLWlvbi1pdGVtLWNvbG9yOiB2YXIoLS1yYWRpby10YWctY29sb3IpO1xuXG4gICAgZmxleDogMTtcblxuXHRcdCYuaXRlbS1yYWRpby1jaGVja2VkIHtcbiAgICAgIC0taW9uLWl0ZW0tYmFja2dyb3VuZDogdmFyKC0tcmFkaW8tdGFnLWFjdGl2ZS1iYWNrZ3JvdW5kKTtcbiAgICAgIC0taW9uLWl0ZW0tY29sb3I6IHZhcigtLXJhZGlvLXRhZy1hY3RpdmUtY29sb3IpO1xuXHRcdH1cblxuICAgICYuaXRlbS1pbnRlcmFjdGl2ZS1kaXNhYmxlZCB7XG4gICAgICBvcGFjaXR5OiAwLjU7XG5cbiAgICAgIC50YWctbGFiZWwge1xuICAgICAgICAvLyBPdmVycmlkZSBJb25pYyBkZWZhdWx0IHN0eWxlXG4gICAgICAgIG9wYWNpdHk6IDE7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLnRhZy1sYWJlbCB7XG5cdFx0XHRtYXJnaW46IDVweDtcbiAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICBsZXR0ZXItc3BhY2luZzogMC4ycHg7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG5cdFx0fVxuXG5cdFx0aW9uLXJhZGlvIHtcblx0XHRcdG1hcmdpbjogMHB4O1xuXHRcdFx0Ly8gVG8gaGlkZSB0aGUgLnJhZGlvLWljb25cblx0XHRcdHdpZHRoOiAwcHg7XG5cdFx0XHQtLWJvcmRlci13aWR0aDogMHB4O1xuXHRcdFx0aGVpZ2h0OiAwcHg7XG5cdFx0XHQvLyBXZSBjYW50IHNldCB3aWR0aCBhbmQgaGVpZ2h0IGZvciAucmFkaW8taWNvbiAucmFkaW8taW5uZXIsIHNvIGxldHMgaGlkZSBpdCBjaGFuZ2luZyBpdHMgY29sb3Jcblx0XHRcdC0tY29sb3ItY2hlY2tlZDogdHJhbnNwYXJlbnQ7XG5cdFx0fVxuXHR9XG59XG4iXX0= */");

/***/ }),

/***/ "LE7c":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/transact/details/transact-details.page.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- <ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header> -->\n\n<ion-content class=\"transact-details-content\">\n  \n  <!-- <ion-row class=\"user-details-wrapper\">\n    <ion-col size=\"4\">\n      <app-aspect-ratio [ratio]=\"{w: 1, h: 1}\">\n        <app-image-shell class=\"user-avatar\" animation=\"spinner\" [src]=\"'./assets/sample-images/notifications/100x100Notification2.jpg'\" [alt]=\"'notification image'\"></app-image-shell>\n      </app-aspect-ratio>\n    </ion-col>\n    <ion-col class=\"user-info-wrapper\" size=\"8\">\n      <h3 class=\"user-name\">Claire Hale</h3>\n      <h5 class=\"user-handle\">@clairehale</h5>\n    </ion-col>\n    <ion-col class=\"user-stats-wrapper\" size=\"6\">\n      <span class=\"user-stat-value\">1553</span>\n      <span class=\"user-stat-name\">Following</span>\n    </ion-col>\n    <ion-col class=\"user-stats-wrapper\" size=\"6\">\n      <span class=\"user-stat-value\">537</span>\n      <span class=\"user-stat-name\">Followers</span>\n    </ion-col>\n    <ion-col size=\"12\">\n      <p class=\"user-bio\">\n        I am a product and visual designer based in Uruguay. I have designed at Google, Amazon and Microsoft.\n      </p>\n    </ion-col>\n  </ion-row> -->\n  <ion-row class=\"user-preferences-wrapper\">\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">客户：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.customerName}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">电话：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.phone}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">咨询楼盘：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.basicInfo?.projectName}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">客户意向：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.description}}\n      </p>\n    </ion-col>\n  </ion-row>\n\n  <ion-item-divider>\n    <ion-label>{{currentReferral?.currentHandler == '楼盘判客'?'审核状态':'确认接收'}}</ion-label>\n  </ion-item-divider>\n  <form [formGroup]=\"radioTagsForm\" *ngIf=\"currentReferral?.currentHandler === '楼盘判客'\">\n    <ion-radio-group formControlName=\"selected_option\">\n      <ion-row class=\"radio-tags\">\n        <ion-item class=\"radio-tag\" lines=\"none\">\n          <ion-label class=\"tag-label\">号码有效</ion-label>\n          <ion-radio value=\"0\"></ion-radio>\n        </ion-item>\n        <ion-item class=\"radio-tag\" lines=\"none\">\n          <ion-label class=\"tag-label\">\n            <span>有疑问</span>\n          </ion-label>\n          <ion-radio value=\"1\" [disabled]=\"placeholder === '1'\"></ion-radio>\n        </ion-item>\n        <!-- <ion-item class=\"radio-tag\" lines=\"none\">\n          <ion-label class=\"tag-label\">\n            <span>&#36;&#36;</span>\n          </ion-label>\n          <ion-radio value=\"2\" disabled=\"true\"></ion-radio>\n        </ion-item> -->\n        <ion-item class=\"radio-tag\" lines=\"none\">\n          <ion-label class=\"tag-label\">\n            <span>号码已存在</span>\n          </ion-label>\n          <ion-radio value=\"2\"></ion-radio>\n        </ion-item>\n      </ion-row>\n    </ion-radio-group>\n\n\n  </form>\n  <form [formGroup]=\"checkTagsForm\" *ngIf=\"currentReferral?.currentHandler === '业务员确认接收'\">\n\n  <ion-radio-group formControlName=\"confirm_option\">\n    <ion-row class=\"radio-tags\">\n      <ion-item class=\"radio-tag\" lines=\"none\">\n        <ion-label class=\"tag-label\">确认接收</ion-label>\n        <ion-radio value=\"0\"></ion-radio>\n      </ion-item>\n      <ion-item class=\"radio-tag\" lines=\"none\">\n        <ion-label class=\"tag-label\">\n          <span>拒绝退回</span>\n        </ion-label>\n        <ion-radio value=\"1\"></ion-radio>\n      </ion-item>\n    </ion-row>\n  </ion-radio-group>\n</form>\n\n  <ion-button class=\"submit-btn\" type=\"submit\" expand=\"block\" fill=\"outline\" [disabled]=\"!radioTagsForm.valid && !checkTagsForm.valid\" (click)=\"onSubmit()\">提交</ion-button>\n    <!-- <ion-label class=\"tip-label\">\n      <span>选择有疑问提交后，系统会提示客户补充二位号码后重新发送审核</span>\n    </ion-label> -->\n\n    <ion-col size=\"12\">\n      <p class=\"user-bio\">\n        选择有疑问提交后，系统会提示客户补充二位号码后重新发送审核。\n      </p>\n    </ion-col>\n\n    <ion-col class=\"user-stats-wrapper\" size=\"6\" *ngIf=\"onHold > 1\">\n      <span class=\"user-stat-value\">您还有{{onHold}}条流程待办理</span>\n      <span class=\"user-stat-name\">\n        <a style=\"text-decoration:underline;\" (click)=\"presentModal()\">点击查看详情</a>\n      </span>\n    </ion-col>\n\n\n\n</ion-content>\n<!-- <ion-alert></ion-alert> -->\n");

/***/ }),

/***/ "f8+Y":
/*!***************************************************************************!*\
  !*** ./src/app/pages/transact/details/styles/transact-details.shell.scss ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("app-image-shell.user-avatar {\n  --image-shell-loading-background: rgba(var(--ion-color-light-rgb), 0.25);\n  --image-shell-border-radius: 50%;\n  --image-shell-spinner-color: var(--ion-color-light);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3RyYW5zYWN0LWRldGFpbHMuc2hlbGwuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHdFQUFBO0VBQ0EsZ0NBQUE7RUFDQSxtREFBQTtBQUNGIiwiZmlsZSI6InRyYW5zYWN0LWRldGFpbHMuc2hlbGwuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImFwcC1pbWFnZS1zaGVsbC51c2VyLWF2YXRhciB7XG4gIC0taW1hZ2Utc2hlbGwtbG9hZGluZy1iYWNrZ3JvdW5kOiByZ2JhKHZhcigtLWlvbi1jb2xvci1saWdodC1yZ2IpLCAwLjI1KTtcbiAgLS1pbWFnZS1zaGVsbC1ib3JkZXItcmFkaXVzOiA1MCU7XG4gIC0taW1hZ2Utc2hlbGwtc3Bpbm5lci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbn1cbiJdfQ== */");

/***/ }),

/***/ "o3LR":
/*!*****************************************************************!*\
  !*** ./src/app/pages/transact/details/transact-details.page.ts ***!
  \*****************************************************************/
/*! exports provided: TransactDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TransactDetailsPage", function() { return TransactDetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_transact_details_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./transact-details.page.html */ "LE7c");
/* harmony import */ var _styles_transact_details_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/transact-details.page.scss */ "IV9T");
/* harmony import */ var _styles_transact_details_shell_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./styles/transact-details.shell.scss */ "f8+Y");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _listing_listing_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../listing/listing.page */ "KrZc");
/* harmony import */ var _transact_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../transact.service */ "g/Tr");










let TransactDetailsPage = class TransactDetailsPage {
    constructor(route, router, transactService, alertController, routerOutlet, modalController) {
        this.router = router;
        this.transactService = transactService;
        this.alertController = alertController;
        this.routerOutlet = routerOutlet;
        this.modalController = modalController;
        this.instanceId = route.snapshot.params['instanceId'];
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.radioTagsForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            selected_option: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required),
        });
        this.checkTagsForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            confirm_option: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required)
        });
        this.transactService.getCurrentTransact(this.instanceId, this.currentUser.mktUserId).subscribe(res => {
            if (res.length >= 0 && res[0] != null) {
                this.currentTaskId = res[0].id;
                this.transactService.getCurrentReferrals(this.instanceId).subscribe(data => {
                    var _a, _b, _c, _d, _e, _f;
                    //
                    // this.currentReferral = data.data;
                    if (data.data != null) {
                        const phone = ((_a = data.data) === null || _a === void 0 ? void 0 : _a.placeholder) === '1' ? (_b = data.data) === null || _b === void 0 ? void 0 : _b.phone.replace(/(\d{5})(\d{2})(\d{4})/, "$1**$3") : (_c = data.data) === null || _c === void 0 ? void 0 : _c.phone.replace(/(\d{3})(\d{4})(\d{4})/, "$1****$3");
                        this.currentReferral = data.data;
                        if (((_d = this.currentReferral) === null || _d === void 0 ? void 0 : _d.placeholder) === "1") {
                            this.placeholder = (_e = this.currentReferral) === null || _e === void 0 ? void 0 : _e.placeholder;
                        }
                        if (((_f = this.currentReferral) === null || _f === void 0 ? void 0 : _f.currentHandler) === '楼盘判客') {
                            this.currentReferral.phone = phone;
                        }
                    }
                });
            }
            else {
                this.presentAlertConfirm('无效办理!', '您当前办理的流程已经办理或已完结!!!');
            }
        });
        this.transactService.getTaskCount(this.currentUser.mktUserId).subscribe(resp => {
            //
            if ((resp === null || resp === void 0 ? void 0 : resp.count) > 0) {
                //
                this.onHold = resp === null || resp === void 0 ? void 0 : resp.count;
            }
        });
    }
    ngOnInit() {
        // const instanceId = this.route.paramMap.get('instanceId');
    }
    presentAlertConfirm(header, message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: header,
                message: message,
                backdropDismiss: false,
                buttons: [
                    {
                        text: '关闭页面',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: () => {
                            // console.log('Confirm Cancel: blah');
                            WeixinJSBridge.call('closeWindow');
                        }
                    }, {
                        text: '返回首页',
                        handler: () => {
                            // console.log('Confirm Okay');
                            this.router.navigate(['/app/home']);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    onSubmit() {
        var _a;
        //
        if (this.currentTaskId == null)
            return;
        // switch (this.currentReferral?.currentHandler) {
        //   case "楼盘判客":
        //     break;
        //   case "业务员确认接收":
        //     return event;
        // }
        const isValid = this.radioTagsForm.controls.selected_option.value == '0';
        const doubtfula = this.radioTagsForm.controls.selected_option.value == '2';
        const isReception = this.checkTagsForm.controls.confirm_option.value == '0';
        const params = ((_a = this.currentReferral) === null || _a === void 0 ? void 0 : _a.currentHandler) === '楼盘判客' ? {
            withVariablesInReturn: true,
            variables: {
                isValid: { value: isValid },
                doubtfula: { value: doubtfula }
            },
        } : {
            withVariablesInReturn: true,
            variables: {
                isReception: { value: isReception }
            },
        };
        this.transactService.completeTask(this.currentTaskId, params).subscribe(res => {
            //
            this.presentAlertConfirm('成功办理', '您当前办理流程已经提交完成！');
        });
    }
    presentModal(ins) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _listing_listing_page__WEBPACK_IMPORTED_MODULE_8__["ListingPage"],
                swipeToClose: true,
                presentingElement: this.routerOutlet.nativeEl,
                componentProps: {
                    'assignee': this.currentUser.mktUserId,
                }
            });
            yield modal.present();
        });
    }
};
TransactDetailsPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _transact_service__WEBPACK_IMPORTED_MODULE_9__["TransactService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["IonRouterOutlet"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"] }
];
TransactDetailsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-contact-card',
        template: _raw_loader_transact_details_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_styles_transact_details_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"], _styles_transact_details_shell_scss__WEBPACK_IMPORTED_MODULE_3__["default"]]
    })
], TransactDetailsPage);



/***/ }),

/***/ "uzjn":
/*!*******************************************************************!*\
  !*** ./src/app/pages/transact/details/transact-details.module.ts ***!
  \*******************************************************************/
/*! exports provided: TransactDetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TransactDetailsPageModule", function() { return TransactDetailsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _transact_details_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./transact-details.page */ "o3LR");
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../components/components.module */ "j1ZV");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _listing_listing_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../listing/listing.page */ "KrZc");
/* harmony import */ var _app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @app/pipes/pipes.module */ "iTUp");










let TransactDetailsPageModule = class TransactDetailsPageModule {
};
TransactDetailsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
            _components_components_module__WEBPACK_IMPORTED_MODULE_6__["ComponentsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormsModule"],
            _app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_9__["PipesModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ReactiveFormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{ path: '', component: _transact_details_page__WEBPACK_IMPORTED_MODULE_5__["TransactDetailsPage"] }])
        ],
        declarations: [_transact_details_page__WEBPACK_IMPORTED_MODULE_5__["TransactDetailsPage"], _listing_listing_page__WEBPACK_IMPORTED_MODULE_8__["ListingPage"]],
        entryComponents: [_listing_listing_page__WEBPACK_IMPORTED_MODULE_8__["ListingPage"]]
    })
], TransactDetailsPageModule);



/***/ })

}]);
//# sourceMappingURL=pages-transact-details-transact-details-module.js.map