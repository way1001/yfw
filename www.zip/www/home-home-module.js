(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "99Un":
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.module.ts ***!
  \*******************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./home.page */ "hsj+");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @app/components/components.module */ "j1ZV");








const homeRoutes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_5__["HomePage"],
    }
];
let HomePageModule = class HomePageModule {
};
HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ReactiveFormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(homeRoutes),
            _app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_5__["HomePage"]],
    })
], HomePageModule);



/***/ }),

/***/ "FdWk":
/*!********************************************!*\
  !*** ./src/app/pages/home/home.service.ts ***!
  \********************************************/
/*! exports provided: HomeService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeService", function() { return HomeService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "tk/3");



let HomeService = class HomeService {
    constructor(http) {
        this.http = http;
    }
    getAll() {
        return this.http.get(`/mkt/api/mp/basicinfo/all`)
            .pipe();
    }
    multiProcess() {
        return this.http.get(`/mkt/api/mp/workflow/all`)
            .pipe();
    }
    start(params) {
        return this.http.post('/mkt/engine-rest/process-definition/' + params.processDefinitionId + '/submit-form', params);
    }
    verification(phone, senderId) {
        return this.http.get('/mkt/api/mp/referrals/verification', { params: { phone, senderId } })
            .pipe();
    }
};
HomeService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
HomeService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], HomeService);



/***/ }),

/***/ "WXXZ":
/*!**************************************************!*\
  !*** ./src/app/pages/home/styles/home.page.scss ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host {\n  --page-margin: var(--app-fair-margin);\n  --page-background: var(--app-background-shade);\n  --page-rating-5-color: #7ce198;\n  --page-rating-4-color: #a8e07c;\n  --page-rating-3-color: #cee07c;\n  --page-rating-2-color: #e0c77c;\n  --page-rating-1-color: #e07c7c;\n}\n\nion-header ion-toolbar {\n  --background: transparent;\n}\n\nion-content {\n  position: absolute;\n  top: 0;\n  border-top: calc(var(--app-header-height) + var(--ion-safe-area-top));\n  border-top-style: solid;\n  border-top-color: var(--ion-color-primary);\n}\n\n.forms-validations-content {\n  --background: var(--page-background);\n}\n\n.forms-validations-content .validations-form {\n  margin-bottom: calc(var(--page-margin) * 2);\n}\n\n.forms-validations-content .validations-form .inputs-list {\n  --ion-item-background: var(--page-background);\n  padding: var(--page-margin) var(--page-margin) 0;\n}\n\n.forms-validations-content .validations-form .inputs-list ion-list-header {\n  padding-inline-start: 0px;\n}\n\n.forms-validations-content .validations-form .inputs-list ion-list-header .header-title {\n  text-transform: uppercase;\n  font-size: 12px;\n  color: var(--page-rating-1-color);\n}\n\n.forms-validations-content .validations-form .inputs-list .input-item {\n  --padding-start: 0px;\n  --padding-end: 0px;\n  --inner-padding-end: 0px;\n}\n\n.forms-validations-content .validations-form .inputs-list .terms-item {\n  --border-width: 0px;\n  --inner-padding-end: 0px;\n}\n\n.forms-validations-content .validations-form .inputs-list .error-container .error-message {\n  margin: calc(var(--page-margin) / 2) 0px;\n  display: flex;\n  align-items: center;\n  color: var(--ion-color-danger);\n  font-size: 14px;\n}\n\n.forms-validations-content .validations-form .inputs-list .error-container .error-message ion-icon {\n  padding-inline-end: calc(var(--page-margin) / 2);\n  flex-shrink: 0;\n}\n\n.forms-validations-content .validations-form .inputs-list .counter-item app-counter-input {\n  --counter-background: transparent;\n  --counter-color: var(--ion-color-primary);\n  --counter-border-color: var(--ion-color-primary);\n}\n\n.forms-validations-content .validations-form .inputs-list .counter-item .counter-value {\n  text-align: center;\n}\n\n.forms-validations-content .validations-form .submit-btn {\n  margin: var(--page-margin);\n}\n\n.forms-validations-content .validations-form ion-item-divider {\n  --background: var(--page-background);\n  --padding-bottom: calc(var(--page-margin) / 2);\n  --padding-top: calc(var(--page-margin) * 2);\n  --padding-start: var(--page-margin);\n  --padding-end: var(--page-margin);\n  border: none;\n}\n\n.forms-validations-content .validations-form ion-item-divider .no-tranck {\n  text-transform: uppercase;\n  font-size: 12px;\n  color: var(--page-rating-1-color);\n}\n\n.forms-validations-content .validations-form .checkbox-list {\n  --background: var(--page-background);\n  --ion-item-background: var(--page-background);\n}\n\n.forms-validations-content .validations-form .checkbox-list ion-list-header {\n  padding-inline-start: 0px;\n}\n\n.forms-validations-content .validations-form .checkbox-list ion-list-header .header-title {\n  text-transform: uppercase;\n  font-size: 12px;\n  color: var(--page-rating-1-color);\n}\n\n.forms-validations-content .validations-form .checkbox-list .checkbox-item {\n  --padding-start: var(--page-margin);\n  --padding-end: var(--page-margin);\n  --inner-padding-end: 0px;\n}\n\n.forms-validations-content .validations-form .checkbox-list .checkbox-item .checkbox-label {\n  font-size: 14px;\n  font-weight: 500;\n  letter-spacing: 0.2px;\n  color: var(--ion-color-medium);\n}\n\n.forms-validations-content .validations-form .checkbox-list .checkbox-item ion-checkbox {\n  margin-inline-end: 0px;\n}\n\n.forms-validations-content .validations-form .checkbox-list .checkbox-form {\n  --background: var(--page-background);\n}\n\n.forms-validations-content .validations-form .checkbox-list .checkbox-form .notification-item {\n  --background: var(--page-background);\n  --padding-start: 0px;\n  --inner-padding-end: 0px;\n  padding: var(--page-margin);\n  color: var(--ion-color-medium);\n  box-shadow: inset 0 8px 2px -9px var(--ion-color-darkest);\n}\n\n.forms-validations-content .validations-form .checkbox-list .checkbox-form .notification-item .notification-item-wrapper {\n  --ion-grid-column-padding: 0px;\n  width: 100%;\n  align-items: center;\n}\n\n.forms-validations-content .validations-form .checkbox-list .checkbox-form .notification-item .details-wrapper {\n  display: flex;\n  flex-direction: column;\n  justify-content: space-around;\n  padding-left: var(--page-margin);\n}\n\n.forms-validations-content .validations-form .checkbox-list .checkbox-form .notification-item .details-wrapper .details-name {\n  margin-top: 0px;\n  margin-bottom: 5px;\n  font-size: 16px;\n  font-weight: 400;\n  letter-spacing: 0.2px;\n  color: var(--ion-color-secondary);\n}\n\n.forms-validations-content .validations-form .checkbox-list .checkbox-form .notification-item .details-wrapper .details-description {\n  font-size: 12px;\n  margin: 0px;\n}\n\n.forms-validations-content .validations-form .checkbox-list .checkbox-form .notification-item .date-wrapper {\n  align-self: flex-start;\n}\n\n.forms-validations-content .validations-form .checkbox-list .checkbox-form .notification-item .date-wrapper .average-price {\n  margin: 0px;\n  font-size: 12px;\n  text-align: end;\n}\n\n.forms-validations-content .validations-form .checkbox-list .checkbox-form .notification-item .date-wrapper .commission-rating {\n  width: 56px;\n  color: var(--ion-color-lightest);\n  border-radius: var(--app-narrow-radius);\n  padding: calc(var(--page-margin) / 8) calc(var(--page-margin) / 4);\n  font-size: 10px;\n  font-weight: 400;\n  display: block;\n  text-align: center;\n  background-color: var(--page-rating-1-color);\n}\n\n.forms-validations-content .validations-form .checkbox-tags {\n  padding: calc(var(--page-margin) / 2) calc(var(--page-margin) - var(--page-tags-gutter));\n  --checkbox-tag-color: #000;\n  --checkbox-tag-background: #FFF;\n  --checkbox-tag-active-color: #FFF;\n  --checkbox-tag-active-background: #000;\n}\n\n.forms-validations-content .validations-form .checkbox-tags .checkbox-tag {\n  --padding-start: 0px;\n  --inner-padding-end: 8px;\n  --inner-padding-start: 8px;\n  --ion-item-background: var(--checkbox-tag-background);\n  --ion-item-color: var(--checkbox-tag-color);\n}\n\n.forms-validations-content .validations-form .checkbox-tags .checkbox-tag.rounded-tag {\n  --border-radius: 2.2rem;\n}\n\n.forms-validations-content .validations-form .checkbox-tags .checkbox-tag.item-checkbox-checked {\n  --ion-item-background: var(--checkbox-tag-active-background);\n  --ion-item-color: var(--checkbox-tag-active-color);\n}\n\n.forms-validations-content .validations-form .checkbox-tags .checkbox-tag.item-interactive-disabled {\n  opacity: 0.5;\n}\n\n.forms-validations-content .validations-form .checkbox-tags .checkbox-tag.item-interactive-disabled .tag-label {\n  opacity: 1;\n}\n\n.forms-validations-content .validations-form .checkbox-tags .checkbox-tag .tag-label {\n  margin: 5px;\n  font-size: 12px;\n  font-weight: 500;\n  letter-spacing: 0.2px;\n  text-align: center;\n}\n\n.forms-validations-content .validations-form .checkbox-tags .checkbox-tag ion-checkbox {\n  margin: 0px;\n  width: 0px;\n  --border-width: 0px;\n  height: 0px;\n  --color-checked: transparent;\n}\n\n.forms-validations-content .validations-form .checkbox-tags .checkbox-tag {\n  padding: 0px var(--page-tags-gutter);\n  margin: var(--page-tags-gutter) 0px;\n}\n\n.forms-validations-content .validations-form .checkbox-tags.square-checkbox-tags {\n  background-color: var(--page-background);\n}\n\n.forms-validations-content .validations-form .checkbox-tags.square-checkbox-tags .checkbox-tag {\n  --checkbox-tag-color: var(--ion-color-medium);\n  --checkbox-tag-background: var(--ion-color-lightest);\n  --checkbox-tag-active-color: var(--ion-color-lightest);\n  --checkbox-tag-active-background: var(--ion-color-secondary);\n}\n\n::ng-deep .select-alert {\n  --select-alert-color: #000;\n  --select-alert-background: #FFF;\n  --select-alert-margin: 16px;\n  --select-alert-color: var(--ion-color-lightest);\n  --select-alert-background: var(--ion-color-primary);\n  --select-alert-margin: 16px;\n}\n\n::ng-deep .select-alert .alert-head {\n  padding-top: calc((var(--select-alert-margin) / 4) * 3);\n  padding-bottom: calc((var(--select-alert-margin) / 4) * 3);\n  padding-inline-start: var(--select-alert-margin);\n  padding-inline-end: var(--select-alert-margin);\n}\n\n::ng-deep .select-alert .alert-title {\n  color: var(--select-alert-color);\n}\n\n::ng-deep .select-alert .alert-head,\n::ng-deep .select-alert .alert-message {\n  background-color: var(--select-alert-background);\n}\n\n::ng-deep .select-alert .alert-wrapper.sc-ion-alert-ios .alert-title {\n  margin: 0px;\n}\n\n::ng-deep .select-alert .alert-wrapper.sc-ion-alert-md .alert-title {\n  font-size: 18px;\n  font-weight: 400;\n}\n\n::ng-deep .select-alert .alert-wrapper.sc-ion-alert-md .alert-button {\n  --padding-top: 0;\n  --padding-start: 0.9em;\n  --padding-end: 0.9em;\n  --padding-bottom: 0;\n  height: 2.1em;\n  font-size: 13px;\n}\n\n::ng-deep .select-alert .alert-message {\n  display: none;\n}\n\n:host-context(.md) .checkbox-list,\n:host-context(.md) .range-list {\n  padding-top: 0px;\n  padding-bottom: 0px;\n}\n\n:host-context(.ios) .checkbox-tags {\n  margin-bottom: calc(var(--page-margin) * 2);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2hvbWUucGFnZS5zY3NzIiwiLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vdGhlbWUvbWl4aW5zL2lucHV0cy9jaGVja2JveC10YWcuc2NzcyIsIi4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uL3RoZW1lL21peGlucy9pbnB1dHMvc2VsZWN0LWFsZXJ0LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBS0E7RUFDRSxxQ0FBQTtFQUNBLDhDQUFBO0VBRUEsOEJBQUE7RUFDQSw4QkFBQTtFQUNBLDhCQUFBO0VBQ0EsOEJBQUE7RUFDQSw4QkFBQTtBQUxGOztBQVVFO0VBQ0UseUJBQUE7QUFQSjs7QUFVQTtFQUNFLGtCQUFBO0VBQ0EsTUFBQTtFQUNBLHFFQUFBO0VBQ0EsdUJBQUE7RUFDQSwwQ0FBQTtBQVBGOztBQVdBO0VBQ0Usb0NBQUE7QUFSRjs7QUFVRTtFQUNFLDJDQUFBO0FBUko7O0FBVUk7RUFDRSw2Q0FBQTtFQUlBLGdEQUFBO0FBWE47O0FBYU07RUFDRSx5QkFBQTtBQVhSOztBQWFRO0VBRUUseUJBQUE7RUFDRixlQUFBO0VBQ0EsaUNBQUE7QUFaUjs7QUFnQk07RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0Esd0JBQUE7QUFkUjs7QUFpQk07RUFDRSxtQkFBQTtFQUNBLHdCQUFBO0FBZlI7O0FBbUJRO0VBQ0Usd0NBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSw4QkFBQTtFQUNBLGVBQUE7QUFqQlY7O0FBbUJVO0VBQ0UsZ0RBQUE7RUFDQSxjQUFBO0FBakJaOztBQXVCUTtFQUNFLGlDQUFBO0VBQ0EseUNBQUE7RUFDQSxnREFBQTtBQXJCVjs7QUF3QlE7RUFDRSxrQkFBQTtBQXRCVjs7QUEyQkk7RUFDRSwwQkFBQTtBQXpCTjs7QUE0Qkk7RUFDRSxvQ0FBQTtFQUNBLDhDQUFBO0VBQ0EsMkNBQUE7RUFDQSxtQ0FBQTtFQUNBLGlDQUFBO0VBRUEsWUFBQTtBQTNCTjs7QUE2Qk07RUFDRSx5QkFBQTtFQUNBLGVBQUE7RUFDQSxpQ0FBQTtBQTNCUjs7QUErQkk7RUFDRSxvQ0FBQTtFQUNBLDZDQUFBO0FBN0JOOztBQStCTTtFQUNFLHlCQUFBO0FBN0JSOztBQStCUTtFQUVFLHlCQUFBO0VBQ0YsZUFBQTtFQUNBLGlDQUFBO0FBOUJSOztBQWtDTTtFQUVFLG1DQUFBO0VBQ0EsaUNBQUE7RUFDQSx3QkFBQTtBQWpDUjs7QUFtQ1E7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxxQkFBQTtFQUNBLDhCQUFBO0FBakNWOztBQXNDUTtFQUNFLHNCQUFBO0FBcENWOztBQXdDTTtFQUNFLG9DQUFBO0FBdENSOztBQXdDUTtFQUNFLG9DQUFBO0VBRUEsb0JBQUE7RUFDQSx3QkFBQTtFQUVBLDJCQUFBO0VBQ0EsOEJBQUE7RUFDQSx5REFBQTtBQXhDVjs7QUEwQ1U7RUFFRSw4QkFBQTtFQUVBLFdBQUE7RUFDQSxtQkFBQTtBQTFDWjs7QUE2Q1U7RUFDRSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSw2QkFBQTtFQUNBLGdDQUFBO0FBM0NaOztBQTZDWTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLHFCQUFBO0VBQ0EsaUNBQUE7QUEzQ2Q7O0FBOENZO0VBQ0UsZUFBQTtFQUNBLFdBQUE7QUE1Q2Q7O0FBZ0RVO0VBQ0Usc0JBQUE7QUE5Q1o7O0FBZ0RZO0VBQ0UsV0FBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0FBOUNkOztBQWlEWTtFQUNFLFdBQUE7RUFDQSxnQ0FBQTtFQUNBLHVDQUFBO0VBQ0Esa0VBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFFQSw0Q0FBQTtBQWhEZDs7QUEyRUk7RUFDRSx3RkFBQTtFQzVPSiwwQkFBQTtFQUNBLCtCQUFBO0VBQ0EsaUNBQUE7RUFDQSxzQ0FBQTtBRG9LRjs7QUNsS0M7RUFHQyxvQkFBQTtFQUNFLHdCQUFBO0VBQ0YsMEJBQUE7RUFDQSxxREFBQTtFQUNFLDJDQUFBO0FEa0tKOztBQ2hLSTtFQUNELHVCQUFBO0FEa0tIOztBQy9KRTtFQUNJLDREQUFBO0VBQ0Esa0RBQUE7QURpS047O0FDOUpJO0VBQ0UsWUFBQTtBRGdLTjs7QUM5Sk07RUFFRSxVQUFBO0FEK0pSOztBQzNKRTtFQUNDLFdBQUE7RUFDRyxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0FENkpOOztBQzFKRTtFQUNDLFdBQUE7RUFFQSxVQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0VBRUEsNEJBQUE7QUQwSkg7O0FBdUNNO0VBQ0Usb0NBQUE7RUFDQSxtQ0FBQTtBQXJDUjs7QUF5Q007RUFDRSx3Q0FBQTtBQXZDUjs7QUF5Q1E7RUFDRSw2Q0FBQTtFQUNBLG9EQUFBO0VBQ0Esc0RBQUE7RUFDQSw0REFBQTtBQXZDVjs7QUFpREE7RUV2UUUsMEJBQUE7RUFDQSwrQkFBQTtFQUNBLDJCQUFBO0VGeVFBLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSwyQkFBQTtBQTlDRjs7QUUzTkU7RUFDRSx1REFBQTtFQUNBLDBEQUFBO0VBQ0EsZ0RBQUE7RUFDQSw4Q0FBQTtBRjZOSjs7QUUxTkU7RUFDRSxnQ0FBQTtBRjROSjs7QUV6TkU7O0VBRUUsZ0RBQUE7QUYyTko7O0FFdE5JO0VBQ0UsV0FBQTtBRndOTjs7QUVsTkk7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7QUZvTk47O0FFak5JO0VBRUUsZ0JBQUE7RUFDQSxzQkFBQTtFQUNBLG9CQUFBO0VBQ0EsbUJBQUE7RUFFQSxhQUFBO0VBQ0EsZUFBQTtBRmlOTjs7QUFvQkU7RUFDRSxhQUFBO0FBbEJKOztBQXVCRTs7RUFFRSxnQkFBQTtFQUNBLG1CQUFBO0FBcEJKOztBQXlCRTtFQUNFLDJDQUFBO0FBdEJKIiwiZmlsZSI6ImhvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGltcG9ydCBcIi4uLy4uLy4uLy4uL3RoZW1lL21peGlucy9pbnB1dHMvc2VsZWN0LWFsZXJ0XCI7XG5AaW1wb3J0IFwiLi4vLi4vLi4vLi4vdGhlbWUvbWl4aW5zL2lucHV0cy9jaGVja2JveC10YWdcIjtcblxuLy8gQ3VzdG9tIHZhcmlhYmxlc1xuLy8gTm90ZTogIFRoZXNlIG9uZXMgd2VyZSBhZGRlZCBieSB1cyBhbmQgaGF2ZSBub3RoaW5nIHRvIGRvIHdpdGggSW9uaWMgQ1NTIEN1c3RvbSBQcm9wZXJ0aWVzXG46aG9zdCB7XG4gIC0tcGFnZS1tYXJnaW46IHZhcigtLWFwcC1mYWlyLW1hcmdpbik7XG4gIC0tcGFnZS1iYWNrZ3JvdW5kOiB2YXIoLS1hcHAtYmFja2dyb3VuZC1zaGFkZSk7XG5cbiAgLS1wYWdlLXJhdGluZy01LWNvbG9yOiAjN2NlMTk4O1xuICAtLXBhZ2UtcmF0aW5nLTQtY29sb3I6ICNhOGUwN2M7XG4gIC0tcGFnZS1yYXRpbmctMy1jb2xvcjogI2NlZTA3YztcbiAgLS1wYWdlLXJhdGluZy0yLWNvbG9yOiAjZTBjNzdjO1xuICAtLXBhZ2UtcmF0aW5nLTEtY29sb3I6ICNlMDdjN2M7XG59XG5cbi8vIFVzZSBhIGNvbG9yZWQgYm9yZGVyLXRvcCB0byBmaXggd2VpcmQgdHJhbnNpdGlvbnMgYmV0d2VlbiB0b29sYmFycyB0aGF0IGhhdmUgZGlmZmVyZW50IGJhY2tncm91bmQgY29sb3JzXG5pb24taGVhZGVyIHtcbiAgaW9uLXRvb2xiYXIge1xuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIH1cbn1cbmlvbi1jb250ZW50IHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDA7XG4gIGJvcmRlci10b3A6IGNhbGModmFyKC0tYXBwLWhlYWRlci1oZWlnaHQpICsgdmFyKC0taW9uLXNhZmUtYXJlYS10b3ApKTtcbiAgYm9yZGVyLXRvcC1zdHlsZTogc29saWQ7XG4gIGJvcmRlci10b3AtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cblxuLy8gTm90ZTogIEFsbCB0aGUgQ1NTIHZhcmlhYmxlcyBkZWZpbmVkIGJlbG93IGFyZSBvdmVycmlkZXMgb2YgSW9uaWMgZWxlbWVudHMgQ1NTIEN1c3RvbSBQcm9wZXJ0aWVzXG4uZm9ybXMtdmFsaWRhdGlvbnMtY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogdmFyKC0tcGFnZS1iYWNrZ3JvdW5kKTtcblxuICAudmFsaWRhdGlvbnMtZm9ybSB7XG4gICAgbWFyZ2luLWJvdHRvbTogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgKiAyKTtcblxuICAgIC5pbnB1dHMtbGlzdCB7XG4gICAgICAtLWlvbi1pdGVtLWJhY2tncm91bmQ6IHZhcigtLXBhZ2UtYmFja2dyb3VuZCk7XG5cbiAgICAgIC8vIHBhZGRpbmc6IHZhcigtLXBhZ2UtbWFyZ2luKSB2YXIoLS1wYWdlLW1hcmdpbikgY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgKiAyKTtcblxuICAgICAgcGFkZGluZzogdmFyKC0tcGFnZS1tYXJnaW4pIHZhcigtLXBhZ2UtbWFyZ2luKSAwO1xuXG4gICAgICBpb24tbGlzdC1oZWFkZXIge1xuICAgICAgICBwYWRkaW5nLWlubGluZS1zdGFydDogMHB4O1xuXG4gICAgICAgIC5oZWFkZXItdGl0bGUge1xuICAgICAgICAgIFxuICAgICAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gICAgICBcdFx0Zm9udC1zaXplOiAxMnB4O1xuICAgICAgXHRcdGNvbG9yOiB2YXIoLS1wYWdlLXJhdGluZy0xLWNvbG9yKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAuaW5wdXQtaXRlbSB7XG4gICAgICAgIC0tcGFkZGluZy1zdGFydDogMHB4O1xuICAgICAgICAtLXBhZGRpbmctZW5kOiAwcHg7XG4gICAgICAgIC0taW5uZXItcGFkZGluZy1lbmQ6IDBweDtcbiAgICAgIH1cblxuICAgICAgLnRlcm1zLWl0ZW0ge1xuICAgICAgICAtLWJvcmRlci13aWR0aDogMHB4O1xuICAgICAgICAtLWlubmVyLXBhZGRpbmctZW5kOiAwcHg7XG4gICAgICB9XG5cbiAgICAgIC5lcnJvci1jb250YWluZXIge1xuICAgICAgICAuZXJyb3ItbWVzc2FnZSB7XG4gICAgICAgICAgbWFyZ2luOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDIpIDBweDtcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYW5nZXIpO1xuICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcblxuICAgICAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgICAgIHBhZGRpbmctaW5saW5lLWVuZDogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcbiAgICAgICAgICAgIGZsZXgtc2hyaW5rOiAwO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIFx0fVxuXG4gICAgICAuY291bnRlci1pdGVtIHtcbiAgICAgICAgYXBwLWNvdW50ZXItaW5wdXQge1xuICAgICAgICAgIC0tY291bnRlci1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICAgICAgICAtLWNvdW50ZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgICAtLWNvdW50ZXItYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgICAgIH1cblxuICAgICAgICAuY291bnRlci12YWx1ZSB7XG4gICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgLnN1Ym1pdC1idG4ge1xuICAgICAgbWFyZ2luOiB2YXIoLS1wYWdlLW1hcmdpbik7XG4gICAgfVxuXG4gICAgaW9uLWl0ZW0tZGl2aWRlciB7XG4gICAgICAtLWJhY2tncm91bmQ6IHZhcigtLXBhZ2UtYmFja2dyb3VuZCk7XG4gICAgICAtLXBhZGRpbmctYm90dG9tOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDIpO1xuICAgICAgLS1wYWRkaW5nLXRvcDogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgKiAyKTtcbiAgICAgIC0tcGFkZGluZy1zdGFydDogdmFyKC0tcGFnZS1tYXJnaW4pO1xuICAgICAgLS1wYWRkaW5nLWVuZDogdmFyKC0tcGFnZS1tYXJnaW4pO1xuICBcbiAgICAgIGJvcmRlcjogbm9uZTtcblxuICAgICAgLm5vLXRyYW5ja3tcbiAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICBjb2xvcjogdmFyKC0tcGFnZS1yYXRpbmctMS1jb2xvcik7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLmNoZWNrYm94LWxpc3Qge1xuICAgICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1wYWdlLWJhY2tncm91bmQpO1xuICAgICAgLS1pb24taXRlbS1iYWNrZ3JvdW5kOiB2YXIoLS1wYWdlLWJhY2tncm91bmQpO1xuXG4gICAgICBpb24tbGlzdC1oZWFkZXIge1xuICAgICAgICBwYWRkaW5nLWlubGluZS1zdGFydDogMHB4O1xuXG4gICAgICAgIC5oZWFkZXItdGl0bGUge1xuICAgICAgICAgIFxuICAgICAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gICAgICBcdFx0Zm9udC1zaXplOiAxMnB4O1xuICAgICAgXHRcdGNvbG9yOiB2YXIoLS1wYWdlLXJhdGluZy0xLWNvbG9yKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAuY2hlY2tib3gtaXRlbSB7XG4gICAgICAgIFxuICAgICAgICAtLXBhZGRpbmctc3RhcnQ6IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgICAgICAgLS1wYWRkaW5nLWVuZDogdmFyKC0tcGFnZS1tYXJnaW4pO1xuICAgICAgICAtLWlubmVyLXBhZGRpbmctZW5kOiAwcHg7XG4gIFxuICAgICAgICAuY2hlY2tib3gtbGFiZWwge1xuICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICAgIGxldHRlci1zcGFjaW5nOiAwLjJweDtcbiAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG4gICAgICAgIH1cblxuXG4gIFxuICAgICAgICBpb24tY2hlY2tib3gge1xuICAgICAgICAgIG1hcmdpbi1pbmxpbmUtZW5kOiAwcHg7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLmNoZWNrYm94LWZvcm0ge1xuICAgICAgICAtLWJhY2tncm91bmQ6IHZhcigtLXBhZ2UtYmFja2dyb3VuZCk7XG5cbiAgICAgICAgLm5vdGlmaWNhdGlvbi1pdGVtIHtcbiAgICAgICAgICAtLWJhY2tncm91bmQ6IHZhcigtLXBhZ2UtYmFja2dyb3VuZCk7XG4gIFxuICAgICAgICAgIC0tcGFkZGluZy1zdGFydDogMHB4O1xuICAgICAgICAgIC0taW5uZXItcGFkZGluZy1lbmQ6IDBweDtcbiAgICAgIFxuICAgICAgICAgIHBhZGRpbmc6IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG4gICAgICAgICAgYm94LXNoYWRvdzogaW5zZXQgMCA4cHggMnB4IC05cHggdmFyKC0taW9uLWNvbG9yLWRhcmtlc3QpO1xuICAgICAgXG4gICAgICAgICAgLm5vdGlmaWNhdGlvbi1pdGVtLXdyYXBwZXIge1xuICAgICAgICAgICAgXG4gICAgICAgICAgICAtLWlvbi1ncmlkLWNvbHVtbi1wYWRkaW5nOiAwcHg7XG4gICAgICBcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICB9XG4gICAgICBcbiAgICAgICAgICAuZGV0YWlscy13cmFwcGVyIHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XG4gICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgICAgIFxuICAgICAgICAgICAgLmRldGFpbHMtbmFtZSB7XG4gICAgICAgICAgICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICAgICAgICAgICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgICAgICAgICAgIGxldHRlci1zcGFjaW5nOiAwLjJweDtcbiAgICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xuICAgICAgICAgICAgfVxuICAgICAgXG4gICAgICAgICAgICAuZGV0YWlscy1kZXNjcmlwdGlvbiB7XG4gICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgICAgICAgbWFyZ2luOiAwcHg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgXG4gICAgICAgICAgLmRhdGUtd3JhcHBlciB7XG4gICAgICAgICAgICBhbGlnbi1zZWxmOiBmbGV4LXN0YXJ0O1xuICAgICAgXG4gICAgICAgICAgICAuYXZlcmFnZS1wcmljZSB7XG4gICAgICAgICAgICAgIG1hcmdpbjogMHB4O1xuICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgICAgICAgIHRleHQtYWxpZ246IGVuZDtcbiAgICAgICAgICAgIH1cbiAgXG4gICAgICAgICAgICAuY29tbWlzc2lvbi1yYXRpbmcge1xuICAgICAgICAgICAgICB3aWR0aDogNTZweDtcbiAgICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodGVzdCk7XG4gICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IHZhcigtLWFwcC1uYXJyb3ctcmFkaXVzKTtcbiAgICAgICAgICAgICAgcGFkZGluZzogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyA4KSBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDQpO1xuICAgICAgICAgICAgICBmb250LXNpemU6IDEwcHg7XG4gICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgICAgICAgIC8vIERlZmF1bHQgY29sb3JcbiAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tcGFnZS1yYXRpbmctMS1jb2xvcik7XG4gIFxuICAgICAgICAgICAgICAvLyAmW3JhdGluZ0Jhc2U9XCIxXCJdIHtcbiAgICAgICAgICAgICAgLy8gICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1wYWdlLXJhdGluZy0xLWNvbG9yKTtcbiAgICAgICAgICAgICAgLy8gfVxuICAgICAgICAgICAgICAvLyAmW3JhdGluZ0Jhc2U9XCIyXCJdIHtcbiAgICAgICAgICAgICAgLy8gICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1wYWdlLXJhdGluZy0yLWNvbG9yKTtcbiAgICAgICAgICAgICAgLy8gfVxuICAgICAgICAgICAgICAvLyAmW3JhdGluZ0Jhc2U9XCIzXCJdIHtcbiAgICAgICAgICAgICAgLy8gICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1wYWdlLXJhdGluZy0zLWNvbG9yKTtcbiAgICAgICAgICAgICAgLy8gfVxuICAgICAgICAgICAgICAvLyAmW3JhdGluZ0Jhc2U9XCI0XCJdIHtcbiAgICAgICAgICAgICAgLy8gICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1wYWdlLXJhdGluZy00LWNvbG9yKTtcbiAgICAgICAgICAgICAgLy8gfVxuICAgICAgICAgICAgICAvLyAmW3JhdGluZ0Jhc2U9XCI1XCJdIHtcbiAgICAgICAgICAgICAgLy8gICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1wYWdlLXJhdGluZy01LWNvbG9yKTtcbiAgICAgICAgICAgICAgLy8gfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICB9XG5cbiAgICAgIFxuICAgIH1cblxuXG4gICAgLmNoZWNrYm94LXRhZ3Mge1xuICAgICAgcGFkZGluZzogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKSBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAtIHZhcigtLXBhZ2UtdGFncy1ndXR0ZXIpKTtcbiAgXG4gICAgICBAaW5jbHVkZSBjaGVja2JveC10YWcoKTtcbiAgXG4gICAgICAuY2hlY2tib3gtdGFnIHtcbiAgICAgICAgcGFkZGluZzogMHB4IHZhcigtLXBhZ2UtdGFncy1ndXR0ZXIpO1xuICAgICAgICBtYXJnaW46IHZhcigtLXBhZ2UtdGFncy1ndXR0ZXIpIDBweDtcbiAgICAgIH1cbiAgXG4gICAgICAvLyBBZGQgYSBkZWVwZXIgc2VsZWN0b3IgdG8gb3ZlcnJpZGUgZGVmYXVsdCBjb2xvcnNcbiAgICAgICYuc3F1YXJlLWNoZWNrYm94LXRhZ3Mge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1wYWdlLWJhY2tncm91bmQpO1xuICBcbiAgICAgICAgLmNoZWNrYm94LXRhZyB7XG4gICAgICAgICAgLS1jaGVja2JveC10YWctY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xuICAgICAgICAgIC0tY2hlY2tib3gtdGFnLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1saWdodGVzdCk7XG4gICAgICAgICAgLS1jaGVja2JveC10YWctYWN0aXZlLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHRlc3QpO1xuICAgICAgICAgIC0tY2hlY2tib3gtdGFnLWFjdGl2ZS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kYXJ5KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICB9XG59XG5cbi8vIEFsZXJ0cyBhbmQgaW4gZ2VuZXJhbCBhbGwgb3ZlcmxheXMgYXJlIGF0dGFjaGVkIHRvIHRoZSBib2R5IG9yIGlvbi1hcHAgZGlyZWN0bHlcbi8vIFdlIG5lZWQgdG8gdXNlIDo6bmctZGVlcCB0byBhY2Nlc3MgaXQgZnJvbSBoZXJlXG46Om5nLWRlZXAgLnNlbGVjdC1hbGVydCB7XG4gIEBpbmNsdWRlIHNlbGVjdC1hbGVydCgpO1xuXG4gIC8vIFZhcmlhYmxlcyBzaG91bGQgYmUgaW4gYSBkZWVwZXIgc2VsZWN0b3Igb3IgYWZ0ZXIgdGhlIG1peGluIGluY2x1ZGUgdG8gb3ZlcnJpZGUgZGVmYXVsdCB2YWx1ZXNcbiAgLS1zZWxlY3QtYWxlcnQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodGVzdCk7XG4gIC0tc2VsZWN0LWFsZXJ0LWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgLS1zZWxlY3QtYWxlcnQtbWFyZ2luOiAxNnB4O1xuXG4gIC5hbGVydC1tZXNzYWdlIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9XG59XG5cbjpob3N0LWNvbnRleHQoLm1kKSB7XG4gIC5jaGVja2JveC1saXN0LFxuICAucmFuZ2UtbGlzdCB7XG4gICAgcGFkZGluZy10b3A6IDBweDtcbiAgICBwYWRkaW5nLWJvdHRvbTogMHB4O1xuICB9XG59XG5cbjpob3N0LWNvbnRleHQoLmlvcykge1xuICAuY2hlY2tib3gtdGFncyB7XG4gICAgbWFyZ2luLWJvdHRvbTogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgKiAyKTtcbiAgfVxufSIsIkBtaXhpbiBjaGVja2JveC10YWcoKSB7XG4gIC8vIERlZmF1bHQgdmFsdWVzXG4gIC0tY2hlY2tib3gtdGFnLWNvbG9yOiAjMDAwO1xuICAtLWNoZWNrYm94LXRhZy1iYWNrZ3JvdW5kOiAjRkZGO1xuICAtLWNoZWNrYm94LXRhZy1hY3RpdmUtY29sb3I6ICNGRkY7XG4gIC0tY2hlY2tib3gtdGFnLWFjdGl2ZS1iYWNrZ3JvdW5kOiAjMDAwO1xuXG5cdC5jaGVja2JveC10YWcge1xuXG4gICAgLy8gUmVzZXQgdmFsdWVzIGZyb20gSW9uaWMgKGlvbi1pdGVtKSBzdHlsZXNcblx0XHQtLXBhZGRpbmctc3RhcnQ6IDBweDtcbiAgICAtLWlubmVyLXBhZGRpbmctZW5kOiA4cHg7XG5cdFx0LS1pbm5lci1wYWRkaW5nLXN0YXJ0OiA4cHg7XG5cdFx0LS1pb24taXRlbS1iYWNrZ3JvdW5kOiB2YXIoLS1jaGVja2JveC10YWctYmFja2dyb3VuZCk7XG4gICAgLS1pb24taXRlbS1jb2xvcjogdmFyKC0tY2hlY2tib3gtdGFnLWNvbG9yKTtcblxuICAgICYucm91bmRlZC10YWcge1xuXHRcdFx0LS1ib3JkZXItcmFkaXVzOiAyLjJyZW07XG5cdFx0fVxuXG5cdFx0Ji5pdGVtLWNoZWNrYm94LWNoZWNrZWQge1xuICAgICAgLS1pb24taXRlbS1iYWNrZ3JvdW5kOiB2YXIoLS1jaGVja2JveC10YWctYWN0aXZlLWJhY2tncm91bmQpO1xuICAgICAgLS1pb24taXRlbS1jb2xvcjogdmFyKC0tY2hlY2tib3gtdGFnLWFjdGl2ZS1jb2xvcik7XG5cdFx0fVxuXG4gICAgJi5pdGVtLWludGVyYWN0aXZlLWRpc2FibGVkIHtcbiAgICAgIG9wYWNpdHk6IDAuNTtcblxuICAgICAgLnRhZy1sYWJlbCB7XG4gICAgICAgIC8vIE92ZXJyaWRlIElvbmljIGRlZmF1bHQgc3R5bGVcbiAgICAgICAgb3BhY2l0eTogMTtcbiAgICAgIH1cbiAgICB9XG5cblx0XHQudGFnLWxhYmVsIHtcblx0XHRcdG1hcmdpbjogNXB4O1xuICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgIGxldHRlci1zcGFjaW5nOiAwLjJweDtcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcblx0XHR9XG5cblx0XHRpb24tY2hlY2tib3gge1xuXHRcdFx0bWFyZ2luOiAwcHg7XG5cdFx0XHQvLyBUbyBoaWRlIHRoZSAuY2hlY2tib3gtaWNvblxuXHRcdFx0d2lkdGg6IDBweDtcblx0XHRcdC0tYm9yZGVyLXdpZHRoOiAwcHg7XG5cdFx0XHRoZWlnaHQ6IDBweDtcblx0XHRcdC8vIFdlIGNhbnQgc2V0IHdpZHRoIGFuZCBoZWlnaHQgZm9yIC5jaGVja2JveC1pY29uIC5jaGVja2JveC1pbm5lciwgc28gbGV0cyBoaWRlIGl0IGNoYW5naW5nIGl0cyBjb2xvclxuXHRcdFx0LS1jb2xvci1jaGVja2VkOiB0cmFuc3BhcmVudDtcblx0XHR9XG5cdH1cbn1cbiIsIkBtaXhpbiBzZWxlY3QtYWxlcnQoKSB7XG4gIC8vIERlZmF1bHQgdmFsdWVzXG4gIC0tc2VsZWN0LWFsZXJ0LWNvbG9yOiAjMDAwO1xuICAtLXNlbGVjdC1hbGVydC1iYWNrZ3JvdW5kOiAjRkZGO1xuICAtLXNlbGVjdC1hbGVydC1tYXJnaW46IDE2cHg7XG5cbiAgLmFsZXJ0LWhlYWQge1xuICAgIHBhZGRpbmctdG9wOiBjYWxjKCh2YXIoLS1zZWxlY3QtYWxlcnQtbWFyZ2luKSAvIDQpICogMyk7XG4gICAgcGFkZGluZy1ib3R0b206IGNhbGMoKHZhcigtLXNlbGVjdC1hbGVydC1tYXJnaW4pIC8gNCkgKiAzKTtcbiAgICBwYWRkaW5nLWlubGluZS1zdGFydDogdmFyKC0tc2VsZWN0LWFsZXJ0LW1hcmdpbik7XG4gICAgcGFkZGluZy1pbmxpbmUtZW5kOiB2YXIoLS1zZWxlY3QtYWxlcnQtbWFyZ2luKTtcbiAgfVxuXG4gIC5hbGVydC10aXRsZSB7XG4gICAgY29sb3I6IHZhcigtLXNlbGVjdC1hbGVydC1jb2xvcik7XG4gIH1cblxuICAuYWxlcnQtaGVhZCxcbiAgLmFsZXJ0LW1lc3NhZ2Uge1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLXNlbGVjdC1hbGVydC1iYWNrZ3JvdW5kKTtcbiAgfVxuXG4gIC8vIGlPUyBzdHlsZXNcbiAgLmFsZXJ0LXdyYXBwZXIuc2MtaW9uLWFsZXJ0LWlvcyB7XG4gICAgLmFsZXJ0LXRpdGxlIHtcbiAgICAgIG1hcmdpbjogMHB4O1xuICAgIH1cbiAgfVxuXG4gIC8vIE1hdGVyaWFsIHN0eWxlc1xuICAuYWxlcnQtd3JhcHBlci5zYy1pb24tYWxlcnQtbWQge1xuICAgIC5hbGVydC10aXRsZSB7XG4gICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICBmb250LXdlaWdodDogNDAwO1xuICAgIH1cblxuICAgIC5hbGVydC1idXR0b24ge1xuICAgICAgLy8gVmFsdWVzIHRha2VuIGZyb20gSW9uaWMgc21hbGwgYnV0dG9uIHByZXNldFxuICAgICAgLS1wYWRkaW5nLXRvcDogMDtcbiAgICAgIC0tcGFkZGluZy1zdGFydDogMC45ZW07XG4gICAgICAtLXBhZGRpbmctZW5kOiAwLjllbTtcbiAgICAgIC0tcGFkZGluZy1ib3R0b206IDA7XG5cbiAgICAgIGhlaWdodDogMi4xZW07XG4gICAgICBmb250LXNpemU6IDEzcHg7XG4gICAgfVxuICB9XG59XG4iXX0= */");

/***/ }),

/***/ "eUf4":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-title>\n      首页推荐\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"forms-validations-content\">\n  <!-- <ion-row class=\"slider-row\">\n    <ion-slides class=\"details-slides\" pager=\"true\" [options]=\"slidesOptions\">\n      <ion-slide class=\"\" *ngFor=\"let slide of data?.slides\">\n        <ion-row class=\"slide-inner-row\">\n          <app-aspect-ratio [ratio]=\"{w: 56, h: 20}\">\n            <app-image-shell [src]=\"slide?.src\" [alt]=\"'deals details'\" class=\"showcase-image\" animation=\"spinner\">\n            </app-image-shell>\n          </app-aspect-ratio>\n        </ion-row>\n      </ion-slide>\n    </ion-slides>\n  </ion-row>  -->\n\n  <form class=\"validations-form\" [formGroup]=\"validationsForm\" (ngSubmit)=\"onSubmit(validationsForm.value)\">\n\n    <ion-list class=\"inputs-list\" lines=\"full\">\n      <!-- <ion-list-header>\n        <ion-label class=\"header-title\">推荐信息</ion-label>\n      </ion-list-header> -->\n\n      <ion-item class=\"input-item item-label-floating\">\n        <ion-label position=\"floating\">推荐方式</ion-label>\n        <ion-select formControlName=\"all_no\" cancelText=\"取消\" okText=\"确认\" (ionChange)=\"noChange()\">\n          <ion-select-option *ngFor=\"let allNo of allNos\" [value]=\"allNo\">{{ allNo }}</ion-select-option>\n        </ion-select>\n      </ion-item>\n\n      <ion-item class=\"input-item item-label-floating\">\n        <ion-label position=\"floating\">带看方式</ion-label>\n        <ion-select formControlName=\"take_way\" cancelText=\"取消\" okText=\"确认\" [disabled]=\"!f.all_no.value\">\n          <ion-select-option *ngFor=\"let takeWay of takeWays\" [value]=\"takeWay\" [disabled]=\"f.all_no.value==='隐号推荐'&& takeWay==='需带看'\">{{ takeWay }}</ion-select-option>\n        </ion-select>\n      </ion-item>\n\n      <ion-item class=\"input-item item-label-floating\">\n        <ion-label position=\"floating\">客户姓名</ion-label>\n        <ion-input type=\"text\" formControlName=\"customer_name\" clearInput required></ion-input>\n      </ion-item>\n      <div class=\"error-container\">\n        <ng-container *ngFor=\"let validation of validations.customer_name\">\n          <div class=\"error-message\"\n            *ngIf=\"validationsForm.get('customer_name').hasError(validation.type) && (validationsForm.get('customer_name').dirty || validationsForm.get('customer_name').touched)\">\n            <ion-icon name=\"information-circle-outline\"></ion-icon>\n            <span>{{ validation.message }}</span>\n          </div>\n        </ng-container>\n      </div>\n\n      <ion-item class=\"input-item item-label-floating\">\n        <ion-label position=\"floating\">电话</ion-label>\n        <ion-input clearInput type=\"text\" maxlength=\"11\" formControlName=\"phone\" (ionInput)=\"inputEvent($event)\" ></ion-input>\n      </ion-item>\n      <div class=\"error-container\">\n        <ng-container *ngFor=\"let validation of validations.phone\">\n          <div class=\"error-message\"\n            *ngIf=\"validationsForm.get('phone').hasError(validation.type) && (validationsForm.get('phone').dirty || validationsForm.get('phone').touched)\">\n            <ion-icon name=\"information-circle-outline\"></ion-icon>\n            <span>{{ validation.message }}</span>\n          </div>\n        </ng-container>\n      </div>\n\n    </ion-list>\n\n    <ion-item-divider>\n      <ion-label>楼盘选择：<span class=\"no-tranck\">{{disappeared?'(无可推荐楼盘，建议全号推荐)':''}}</span></ion-label>\n    </ion-item-divider>\n\n    <ion-list class=\"checkbox-list\" lines=\"full\" >\n      <!-- <ion-list-header>\n        <ion-label class=\"header-title\" *ngIf=\"disappeared\">无可推荐楼盘!</ion-label>\n      </ion-list-header> -->\n\n      <!-- <ion-item class=\"checkbox-item\">\n        <ion-label class=\"checkbox-label\">Sophia Martin</ion-label>\n        <ion-checkbox color=\"secondary\" formControlName=\"person_1\"></ion-checkbox>\n      </ion-item> -->\n      <!-- <ion-row class=\"notification-item-wrapper\" *ngIf=\"aff.delFlag!='1'\"> -->\n      <form [formGroup]=\"checkboxAffsForm\" class=\"checkbox-form\">\n        <ion-item class=\"notification-item\" lines=\"none\" *ngFor=\"let aff of affList;let i = index\">\n            <ion-row class=\"notification-item-wrapper\">\n            <ion-col size=\"1.3\" class=\"date-wrapper\" >\n              <ion-checkbox color=\"secondary\" [formControlName]=\"'aff_' + i\" [disabled]=\"aff.delFlag=='1'\"></ion-checkbox>\n            </ion-col>\n            <ion-col size=\"2\">\n              <app-aspect-ratio [ratio]=\"{w: 1, h: 1}\">\n                <app-image-shell class=\"notification-image\"\n                  [src]=\"aff.firstFigure\" [alt]=\"'aff image'\">\n                </app-image-shell>\n              </app-aspect-ratio>\n            </ion-col>\n            <ion-col class=\"details-wrapper\">\n              <h2 class=\"details-name\">{{aff.projectName}}</h2>\n              <p class=\"details-description\">客户有效期：{{aff.validity}}天</p>\n            </ion-col>\n            <ion-col size=\"3.5\" class=\"date-wrapper\">\n              <h3 class=\"average-price\">均价：{{aff.price}}元/㎡</h3>\n              <p class=\"commission-rating\" (click)=\"presentCommissionConfirm(aff?.commission)\">佣金标准</p>\n            </ion-col>\n          </ion-row>\n        </ion-item>\n      </form>\n      \n\n      <!-- <ion-item class=\"notification-item\" lines=\"none\">\n        <ion-row class=\"notification-item-wrapper\">\n          <ion-col size=\"1.3\" class=\"date-wrapper\">\n            <ion-checkbox color=\"secondary\" formControlName=\"person_2\"></ion-checkbox>\n          </ion-col>\n          <ion-col size=\"2\">\n            <app-aspect-ratio [ratio]=\"{w: 1, h: 1}\">\n              <app-image-shell class=\"notification-image\"\n                [src]=\"'./assets/sample-images/notifications/100x100Notification1.jpg'\" [alt]=\"'aff image'\">\n              </app-image-shell>\n            </app-aspect-ratio>\n          </ion-col>\n          <ion-col class=\"details-wrapper\">\n            <h2 class=\"details-name\">天门小楼盘</h2>\n            <p class=\"details-description\">客户有效期：30天</p>\n          </ion-col>\n          <ion-col size=\"3.5\" class=\"date-wrapper\">\n            <h3 class=\"average-price\">均价：5000元/㎡</h3>\n            <p class=\"commission-rating\">佣金标准</p>\n          </ion-col>\n        </ion-row>\n      </ion-item> -->\n\n      <!-- <ion-item class=\"notification-item\" lines=\"none\">\n        <ion-row class=\"notification-item-wrapper\">\n          <ion-col size=\"2\">\n            <app-aspect-ratio [ratio]=\"{w: 1, h: 1}\">\n              <app-image-shell class=\"notification-image\"\n                [src]=\"'./assets/sample-images/notifications/100x100Notification1.jpg'\" [alt]=\"'aff image'\">\n              </app-image-shell>\n            </app-aspect-ratio>\n          </ion-col>\n          <ion-col class=\"details-wrapper\">\n            <h2 class=\"details-name\">天门大楼盘</h2>\n            <p class=\"details-description\">大楼盘全民营销火热进行中</p>\n          </ion-col>\n          <ion-col size=\"2\" class=\"date-wrapper\">\n            <h3 class=\"notification-date\">佣金标准</h3>\n            <ion-checkbox color=\"secondary\" formControlName=\"person_2\"></ion-checkbox>\n          </ion-col>\n        </ion-row>\n      </ion-item> -->\n    </ion-list>\n\n    <ion-button class=\"submit-btn\" type=\"submit\" expand=\"block\" fill=\"outline\" [disabled]=\"!validationsForm.valid && completed\">提交\n    </ion-button>\n  </form>\n</ion-content>");

/***/ }),

/***/ "hsj+":
/*!*****************************************!*\
  !*** ./src/app/pages/home/home.page.ts ***!
  \*****************************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./home.page.html */ "eUf4");
/* harmony import */ var _styles_home_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/home.page.scss */ "WXXZ");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _home_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./home.service */ "FdWk");
/* harmony import */ var _core_service_toast_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @core/_service/toast.service */ "4Jqp");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ "tyNb");











let HomePage = class HomePage {
    constructor(homeService, toastService, alertController, router) {
        this.homeService = homeService;
        this.toastService = toastService;
        this.alertController = alertController;
        this.router = router;
        this.completed = true;
        this.disappeared = false;
        this.takeWayDis = true;
        this.validations = {
            'customer_name': [
                { type: 'required', message: '需输入客户姓名。' },
                { type: 'minlength', message: '客户姓名长度不能少于2位。' },
                { type: 'maxlength', message: '客户姓名长度不能大于10位。' },
            ],
            'all_no': [
                { type: 'required', message: '需选择一项.' }
            ],
            'take_way': [
                { type: 'required', message: '需选择带看方式.' }
            ],
            'phone': [
                { type: 'required', message: '必须输入手机号码！' },
            ],
        };
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        // this.platform.keyboardDidShow.subscribe(ev => {
        //   const { keyboardHeight } = ev;
        //   // Do something with the keyboard height such as translating an input above the keyboard.
        //   this.commentInput.nativeElement.style.setProperty(
        //     'transform',
        //     `translate3d(0, ${keyboardHeight}px, 0)`
        //   );
        // });
        // this.platform.keyboardDidHide.subscribe(() => {
        //   // Move input back to original location
        //   this.commentInput.nativeElement.style.removeProperty('transform');
        // });
    }
    ngOnInit() {
        this.genders = [
            '其他',
            '先生',
            '女士'
        ];
        this.allNos = [
            '全号推荐',
            '隐号推荐',
        ];
        this.takeWays = [
            '需带看',
            '自行带看',
            '陪同前往'
        ];
        this.validationsForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
            'all_no': new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required),
            'take_way': new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]({ value: '', disabled: this.takeWayDis }, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required),
            'customer_name': new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].maxLength(10),
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].minLength(2),
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required
            ])),
            'gender': new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.genders[0], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required),
            'phone': new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].maxLength(11),
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].minLength(10),
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required,
            ])),
        });
        this.checkboxAffsForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({});
        if (this.affList) {
            for (let s = 0; s < this.affList.length; s++) {
                this.checkboxAffsForm.removeControl('aff_' + s);
            }
        }
        this.affList = [];
        this.homeService.getAll().subscribe(res => {
            if (res.ok) {
                this.affList = res.data || [];
                for (let i = 0; i < this.affList.length; i++) {
                    this.checkboxAffsForm.addControl('aff_' + i, new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]());
                }
            }
        });
    }
    get f() { return this.validationsForm.controls; }
    onSubmit(values) {
        if (localStorage.getItem('userRole') && localStorage.getItem('userRole') != '') {
            this.toastService.presentToast('您的角色不允许推荐！');
            return;
        }
        this.currentAffids = [];
        for (let i = 0; i < this.affList.length; i++) {
            const t = 'aff_' + i;
            if (this.checkboxAffsForm.controls[t].value) {
                this.currentAffids.push(this.affList[i]['id']);
            }
        }
        if (this.currentAffids.length <= 0) {
            this.toastService.presentToast('至少选择一个楼盘！');
            return;
        }
        this.completed = false;
        this.recommendRequest().subscribe(res => {
            // let aff = [];
            // if (this.currentAffids.length > 0) {
            //   aff = (this.currentAffids.filter((p) => {
            //     return p.id === true;
            //   }));
            // }
            // let feedback = false;
            // let txt = '';
            this.alertsDocs = [];
            for (let i = 0; i < res.length; i++) {
                const tina = this.affList.filter((p) => {
                    return p['id'] === this.currentAffids[i];
                });
                const index = this.affList.indexOf(tina[0]);
                if (index > -1) {
                    let aff = this.affList[index];
                    if (res[i].ended == false && res[i].suspended == false) {
                        // feedback = true;
                        if (this.currentAffids.length <= 0) {
                            // txt = '推荐客户成功' + '\n';
                            this.alertsDocs.push({ 'status': 'success', 'txt': '推荐客户成功' });
                        }
                        else {
                            // txt = txt + (ml[i].merchant_name ? ml[i].merchant_name : '') + '推荐客户成功' + '\n';
                            this.alertsDocs.push({ 'status': 'success', 'txt': '「' + (aff['projectName'] ? aff['projectName'] : '') + '」推荐客户成功' });
                        }
                    }
                    else {
                        // feedback = false;
                        if (this.currentAffids.length <= 0) {
                            // txt = res[i].errmsg + '\n';
                            this.alertsDocs.push({ status: 'warning', txt: res[i].errmsg });
                        }
                        else {
                            // txt = txt + (ml[i].merchant_name ? ml[i].merchant_name : '') + res[i].errmsg + '\n';
                            this.alertsDocs.push({ status: 'warning', txt:  true ? aff['projectName'] : undefined });
                        }
                    }
                }
            }
            // feedback ? this.toastService.success(txt) : this.toastService.warning(txt);
            // this.feedbackModal.show();
            let str = '';
            this.alertsDocs.forEach(p => {
                let s = (p.status == 'success' ? '<strong>' : '') + p.txt + (p.status == 'success' ? '<strong>' : '');
                str = str + s;
            });
            this.presentAlertConfirm('推荐反馈', str);
            this.f.phone.setValue('');
            this.completed = true;
        });
    }
    inputEvent(e) {
        var _a;
        console.log(e.target.value);
        let num = e.target.value;
        if (this.f.all_no.value == '隐号推荐') {
            if (num.length >= 3) {
                let prefix = num.substr(0, 3);
                let suffix = num.substr(7, 11);
                this.f.phone.setValue(prefix + '****' + suffix);
            }
        }
        this.disappeared = false;
        if (num.length >= 11) {
            this.homeService.verification(num, (_a = this.currentUser) === null || _a === void 0 ? void 0 : _a.mktUserId).subscribe(res => {
                if (res.ok) {
                    if (!res.data || res.data.length <= 0) {
                        //
                        for (var i = 0; i < this.affList.length; ++i) {
                            this.affList[i].delFlag = '0';
                        }
                    }
                    else {
                        const ids = Array();
                        Object.assign(ids, res.data);
                        const tina = this.affList.filter((p) => {
                            // return ids.contains(p['id']);
                            return ids.indexOf(p['id']) != -1;
                        });
                        if (tina.length > 0) {
                            for (var i = 0; i < tina.length; ++i) {
                                const index = this.affList.indexOf(tina[i]);
                                if (index > -1) {
                                    this.affList[index].delFlag = '1';
                                }
                                console.log(this.affList[index]);
                            }
                            if (tina.length === res.data.length) {
                                this.disappeared = true;
                            }
                        }
                    }
                }
                else {
                    //
                }
            });
        }
    }
    changeEvent(e) {
        console.log(e);
    }
    recommendRequest() {
        let counter = 0;
        let size = this.currentAffids.length;
        // if (this.aggregation.info.merchant && this.efficacious === 1) {
        //   const merchantList = (this.aggregation.info.merchant.filter((p) => {
        //     return p.checked === true;
        //   }));
        //   size = merchantList.length;
        // }
        // scan and reduce are the same in the principle of merging, the only different time to emit.
        //
        // After each reduction merge, the subscription is not triggered immediately, but the message
        // is sent after the final merge
        //
        // Trigger the subscription immediately after each scan merge
        return this.getPostsChunk(counter++, size).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["expand"])(() => (counter < size) ? this.getPostsChunk(counter++, size) : Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["empty"])()), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["reduce"])((acc, x) => acc.concat(x), []));
    }
    getPostsChunk(counter, size) {
        const tina = this.affList.filter((p) => {
            return p['id'] === this.currentAffids[counter];
        });
        const index = this.affList.indexOf(tina[0]);
        if (index > -1) {
            let aff = this.affList[index];
            var params = {
                'processDefinitionId': aff['marktingDefineId'],
                'businessKey': 'marketing',
                'returnVariables': true,
                'variables': {
                    'phone': {
                        'value': this.f.phone.value,
                        'type': 'String'
                    },
                    'customerName': {
                        'value': this.f.customer_name.value,
                        'type': 'String'
                    },
                    'gender': {
                        'value': this.genders.indexOf(this.f.gender.value) || 0,
                        'type': 'String'
                    },
                    'description': {
                        'value': '',
                        'type': 'String'
                    },
                    'affiliationId': {
                        'value': aff['id'],
                        'type': 'String'
                    },
                    'tenantId': {
                        'value': aff['tenantId'],
                        'type': 'String'
                    },
                    'brokerId': {
                        'value': this.currentUser.mktUserId,
                        'type': 'String'
                    },
                    'suppression': {
                        'value': this.allNos.indexOf(this.f.all_no.value) || 0,
                        'type': 'String'
                    },
                    'helpShow': {
                        'value': this.takeWays.indexOf(this.f.take_way.value) || 0,
                        'type': 'String'
                    }
                }
            };
            return this.homeService.start(params);
        }
        // const validId = (size === 0) ? this.aggregation.info.id : this.currentAffids[counter]['id'];
        // if (!validId) {
        //   return;
        // }
        // return this.portalService.recommendCustom(this.f.customName.value, this.f.customMobile.value,
        //   this.f.customIntent.value, validId, this.efficacious, this.userId);
    }
    presentAlertConfirm(header, message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: header,
                message: message,
                backdropDismiss: false,
                buttons: [
                    {
                        text: '关闭页面',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: () => {
                            // console.log('Confirm Cancel: blah');
                            WeixinJSBridge.call('closeWindow');
                        }
                    },
                    {
                        text: '继续推荐',
                        handler: () => {
                            // console.log('Confirm Okay');
                            // this.router.navigate(['/app/referrals']);
                            this.f.all_no.setValue('');
                            this.f.take_way.setValue('');
                            this.f.customer_name.setValue('');
                            this.f.phone.setValue('');
                            for (var i = 0; i < this.affList.length; ++i) {
                                this.affList[i].delFlag = '0';
                            }
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    presentCommissionConfirm(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: '佣金标准',
                message: message,
                backdropDismiss: false,
                buttons: [
                    {
                        text: '确认',
                        handler: () => {
                            console.log('Confirm Okay');
                        }
                    },
                ]
            });
            yield alert.present();
        });
    }
    noChange() {
        this.f.take_way.setValue('');
        this.f.phone.setValue('');
    }
};
HomePage.ctorParameters = () => [
    { type: _home_service__WEBPACK_IMPORTED_MODULE_5__["HomeService"] },
    { type: _core_service_toast_service__WEBPACK_IMPORTED_MODULE_6__["ToastService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__["AlertController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__["Router"] }
];
HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        template: _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_styles_home_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], HomePage);



/***/ })

}]);
//# sourceMappingURL=home-home-module.js.map