(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-docking-docking-module"],{

/***/ "1jC2":
/*!*********************************************************!*\
  !*** ./src/app/pages/docking/styles/docking.shell.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("app-image-shell.user-avatar {\n  --image-shell-loading-background: rgba(var(--ion-color-light-rgb), 0.25);\n  --image-shell-border-radius: 50%;\n  --image-shell-spinner-color: var(--ion-color-light);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2RvY2tpbmcuc2hlbGwuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHdFQUFBO0VBQ0EsZ0NBQUE7RUFDQSxtREFBQTtBQUNGIiwiZmlsZSI6ImRvY2tpbmcuc2hlbGwuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImFwcC1pbWFnZS1zaGVsbC51c2VyLWF2YXRhciB7XG4gIC0taW1hZ2Utc2hlbGwtbG9hZGluZy1iYWNrZ3JvdW5kOiByZ2JhKHZhcigtLWlvbi1jb2xvci1saWdodC1yZ2IpLCAwLjI1KTtcbiAgLS1pbWFnZS1zaGVsbC1ib3JkZXItcmFkaXVzOiA1MCU7XG4gIC0taW1hZ2Utc2hlbGwtc3Bpbm5lci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbn1cbiJdfQ== */");

/***/ }),

/***/ "2lTV":
/*!********************************************************!*\
  !*** ./src/app/pages/docking/styles/docking.page.scss ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host {\n  --page-background: var(--app-background-shade);\n  --page-highlighted-background: #00AFFF;\n  --page-margin: var(--app-fair-margin);\n  --page-tags-gutter: 5px;\n}\n\nion-header ion-toolbar {\n  --background: transparent;\n}\n\nion-content {\n  position: absolute;\n  top: 0;\n  border-top-style: solid;\n  border-top-color: var(--page-highlighted-background);\n}\n\n.transact-details-content {\n  --background: var(--page-background);\n  transform: translateZ(0);\n  /* Works - pass \"my-custom-class\" in cssClass to increase specificity */\n}\n\n.transact-details-content ion-item-divider {\n  --background: var(--page-background);\n  --padding-bottom: calc(var(--page-margin) / 2);\n  --padding-top: calc(var(--page-margin) / 2);\n  --padding-start: var(--page-margin);\n  --padding-end: var(--page-margin);\n  border: none;\n}\n\n.transact-details-content .user-details-wrapper {\n  --ion-grid-column-padding: 0px;\n  padding: 0px var(--page-margin) var(--page-margin);\n  background-color: var(--page-highlighted-background);\n  color: var(--ion-color-light);\n  align-items: center;\n}\n\n.transact-details-content .user-details-wrapper .user-avatar {\n  border: solid 3px var(--ion-color-light);\n}\n\n.transact-details-content .user-details-wrapper .user-info-wrapper {\n  padding-left: calc(var(--page-margin) / 2);\n}\n\n.transact-details-content .user-details-wrapper .user-info-wrapper .user-name {\n  margin: 0px 0px 5px;\n}\n\n.transact-details-content .user-details-wrapper .user-info-wrapper .user-handle {\n  margin: 0px;\n  font-weight: 400;\n}\n\n.transact-details-content .user-preferences-wrapper {\n  --ion-grid-column-padding: 0px;\n  padding: var(--page-margin);\n}\n\n.transact-details-content .user-preferences-wrapper .preference-name {\n  margin: 0px 0px 5px;\n  font-size: 16px;\n}\n\n.transact-details-content .user-preferences-wrapper .preference-value {\n  margin: 0px 0px calc(var(--page-margin) / 2);\n  font-size: 14px;\n  line-height: 1.4;\n  color: var(--ion-color-dark-tint);\n}\n\n.transact-details-content .radio-tags {\n  padding: 0px calc(var(--page-margin) - var(--page-tags-gutter));\n  background-color: var(--page-background);\n  justify-content: space-between;\n  --radio-tag-color: #000;\n  --radio-tag-background: #FFF;\n  --radio-tag-active-color: #FFF;\n  --radio-tag-active-background: #000;\n}\n\n.transact-details-content .radio-tags .radio-tag {\n  --padding-start: 0px;\n  --inner-padding-end: 8px;\n  --inner-padding-start: 8px;\n  --min-height: 18px;\n  --border-radius: 8px;\n  --border-width: 1px;\n  --border-style: solid;\n  --border-color: var(--radio-tag-color);\n  --ion-item-background: var(--radio-tag-background);\n  --ion-item-color: var(--radio-tag-color);\n  flex: 1;\n}\n\n.transact-details-content .radio-tags .radio-tag.item-radio-checked {\n  --ion-item-background: var(--radio-tag-active-background);\n  --ion-item-color: var(--radio-tag-active-color);\n}\n\n.transact-details-content .radio-tags .radio-tag.item-interactive-disabled {\n  opacity: 0.5;\n}\n\n.transact-details-content .radio-tags .radio-tag.item-interactive-disabled .tag-label {\n  opacity: 1;\n}\n\n.transact-details-content .radio-tags .radio-tag .tag-label {\n  margin: 5px;\n  font-size: 12px;\n  font-weight: 500;\n  letter-spacing: 0.2px;\n  text-align: center;\n}\n\n.transact-details-content .radio-tags .radio-tag ion-radio {\n  margin: 0px;\n  width: 0px;\n  --border-width: 0px;\n  height: 0px;\n  --color-checked: transparent;\n}\n\n.transact-details-content .radio-tags .radio-tag {\n  --radio-tag-color: var(--ion-color-secondary);\n  --radio-tag-background: var(--ion-color-lightest);\n  --radio-tag-active-color: var(--ion-color-lightest);\n  --radio-tag-active-background: var(--ion-color-secondary);\n  padding: 0px var(--page-tags-gutter);\n  margin: var(--page-tags-gutter) 0px;\n}\n\n.transact-details-content .submit-btn,\n.transact-details-content .tip-label {\n  margin: var(--page-margin);\n}\n\n.transact-details-content .user-bio {\n  padding: 0px var(--page-margin) var(--page-margin);\n  line-height: 1.2;\n  font-size: 14px;\n}\n\n.transact-details-content .user-stats-wrapper {\n  color: var(--ion-color-tertiary-tint);\n  text-align: center;\n  padding-top: calc(var(--page-margin) / 2);\n}\n\n.transact-details-content .user-stats-wrapper .user-stat-value {\n  margin-right: 5px;\n  font-weight: 500;\n  font-size: 14px;\n}\n\n.transact-details-content .user-stats-wrapper .user-stat-name {\n  font-size: 14px;\n  text-decoration: underline;\n}\n\n.transact-details-content .alert-wrapper {\n  background: #e5e5e5;\n}\n\n.transact-details-content .my-custom-class .alert-wrapper {\n  background: #e5e5e5;\n}\n\n.transact-details-content .input-item {\n  --background: var(--page-background);\n  --padding-start: var(--page-margin);\n  --padding-end: var(--page-margin);\n  --inner-padding-end: 0px;\n}\n\n:host-context(.ios) .radio-tags,\n:host-context(.ios) .checkbox-tags {\n  margin-bottom: calc(var(--page-margin) * 2);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2RvY2tpbmcucGFnZS5zY3NzIiwiLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vdGhlbWUvbWl4aW5zL2lucHV0cy9yYWRpby10YWcuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHQTtFQUVFLDhDQUFBO0VBRUEsc0NBQUE7RUFHQSxxQ0FBQTtFQUVBLHVCQUFBO0FBUEY7O0FBY0U7RUFDRSx5QkFBQTtBQVhKOztBQWNBO0VBQ0Usa0JBQUE7RUFDQSxNQUFBO0VBRUEsdUJBQUE7RUFDQSxvREFBQTtBQVpGOztBQWlCQTtFQUNFLG9DQUFBO0VBRUEsd0JBQUE7RUFzSUEsdUVBQUE7QUFwSkY7O0FBZ0JFO0VBQ0Esb0NBQUE7RUFDQSw4Q0FBQTtFQUNBLDJDQUFBO0VBQ0EsbUNBQUE7RUFDQSxpQ0FBQTtFQUVBLFlBQUE7QUFmRjs7QUFrQkU7RUFDRSw4QkFBQTtFQUVBLGtEQUFBO0VBQ0Esb0RBQUE7RUFDQSw2QkFBQTtFQUNBLG1CQUFBO0FBakJKOztBQW1CSTtFQUNFLHdDQUFBO0FBakJOOztBQW9CSTtFQUNFLDBDQUFBO0FBbEJOOztBQW9CTTtFQUNFLG1CQUFBO0FBbEJSOztBQXFCTTtFQUNFLFdBQUE7RUFDQSxnQkFBQTtBQW5CUjs7QUE2Q0U7RUFDRSw4QkFBQTtFQUVBLDJCQUFBO0FBNUNKOztBQThDSTtFQUNFLG1CQUFBO0VBQ0EsZUFBQTtBQTVDTjs7QUErQ0k7RUFDRSw0Q0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGlDQUFBO0FBN0NOOztBQW1ERTtFQUNFLCtEQUFBO0VBQ0Ysd0NBQUE7RUFDRSw4QkFBQTtFQ3BIRix1QkFBQTtFQUNBLDRCQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQ0FBQTtBRG9FRjs7QUNsRUM7RUFFRyxvQkFBQTtFQUNBLHdCQUFBO0VBQ0YsMEJBQUE7RUFDRSxrQkFBQTtFQUVGLG9CQUFBO0VBQ0UsbUJBQUE7RUFDRixxQkFBQTtFQUNBLHNDQUFBO0VBQ0Esa0RBQUE7RUFDQSx3Q0FBQTtFQUVFLE9BQUE7QURpRUo7O0FDL0RFO0VBQ0kseURBQUE7RUFDQSwrQ0FBQTtBRGlFTjs7QUM5REk7RUFDRSxZQUFBO0FEZ0VOOztBQzlETTtFQUVFLFVBQUE7QUQrRFI7O0FDM0RJO0VBQ0QsV0FBQTtFQUNHLGVBQUE7RUFDQSxnQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QUQ2RE47O0FDMURFO0VBQ0MsV0FBQTtFQUVBLFVBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7RUFFQSw0QkFBQTtBRDBESDs7QUFhSTtFQUNFLDZDQUFBO0VBQ0EsaURBQUE7RUFDQSxtREFBQTtFQUNBLHlEQUFBO0VBRUEsb0NBQUE7RUFDQSxtQ0FBQTtBQVpOOztBQWlCRTs7RUFFRSwwQkFBQTtBQWZKOztBQWtCRTtFQUNFLGtEQUFBO0VBRUEsZ0JBQUE7RUFDQSxlQUFBO0FBakJKOztBQW9CRTtFQUNFLHFDQUFBO0VBRUEsa0JBQUE7RUFDQSx5Q0FBQTtBQW5CSjs7QUFxQkk7RUFDRSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQW5CTjs7QUFzQkk7RUFDRSxlQUFBO0VBQ0EsMEJBQUE7QUFwQk47O0FBeUJFO0VBQ0UsbUJBQUE7QUF2Qko7O0FBMkJFO0VBQ0UsbUJBQUE7QUF6Qko7O0FBNEJFO0VBQ0Usb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0JBQUE7QUExQko7O0FBZ0NFOztFQUVFLDJDQUFBO0FBN0JKIiwiZmlsZSI6ImRvY2tpbmcucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGltcG9ydCBcIi4uLy4uLy4uLy4uL3RoZW1lL21peGlucy9pbnB1dHMvcmFkaW8tdGFnXCI7XG4vLyBDdXN0b20gdmFyaWFibGVzXG4vLyBOb3RlOiAgVGhlc2Ugb25lcyB3ZXJlIGFkZGVkIGJ5IHVzIGFuZCBoYXZlIG5vdGhpbmcgdG8gZG8gd2l0aCBJb25pYyBDU1MgQ3VzdG9tIFByb3BlcnRpZXNcbjpob3N0IHtcbiAgLy8gLS1wYWdlLW1hcmdpbjogdmFyKC0tYXBwLWJyb2FkLW1hcmdpbik7XG4gIC0tcGFnZS1iYWNrZ3JvdW5kOiB2YXIoLS1hcHAtYmFja2dyb3VuZC1zaGFkZSk7XG5cbiAgLS1wYWdlLWhpZ2hsaWdodGVkLWJhY2tncm91bmQ6ICMwMEFGRkY7XG5cblxuICAtLXBhZ2UtbWFyZ2luOiB2YXIoLS1hcHAtZmFpci1tYXJnaW4pO1xuXG4gIC0tcGFnZS10YWdzLWd1dHRlcjogNXB4O1xufVxuXG4vLyBOb3RlOiAgQWxsIHRoZSBDU1MgdmFyaWFibGVzIGRlZmluZWQgYmVsb3cgYXJlIG92ZXJyaWRlcyBvZiBJb25pYyBlbGVtZW50cyBDU1MgQ3VzdG9tIFByb3BlcnRpZXNcblxuLy8gVXNlIGEgY29sb3JlZCBib3JkZXItdG9wIHRvIGZpeCB3ZWlyZCB0cmFuc2l0aW9ucyBiZXR3ZWVuIHRvb2xiYXJzIHRoYXQgaGF2ZSBkaWZmZXJlbnQgYmFja2dyb3VuZCBjb2xvcnNcbmlvbi1oZWFkZXIge1xuICBpb24tdG9vbGJhciB7XG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgfVxufVxuaW9uLWNvbnRlbnQge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMDtcbiAgLy8gYm9yZGVyLXRvcDogY2FsYyh2YXIoLS1hcHAtaGVhZGVyLWhlaWdodCkgKyB2YXIoLS1pb24tc2FmZS1hcmVhLXRvcCkpO1xuICBib3JkZXItdG9wLXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLXRvcC1jb2xvcjogdmFyKC0tcGFnZS1oaWdobGlnaHRlZC1iYWNrZ3JvdW5kKTtcbn1cblxuXG5cbi50cmFuc2FjdC1kZXRhaWxzLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHZhcigtLXBhZ2UtYmFja2dyb3VuZCk7XG4gIC8vIFRvIGZpeCBoYWxmIHBpeGVsIGxpbmUgYmV0d2VlbiBpb24taGVhZGVyIGFuZCAgaW9uLWNvbnRlbnRcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVaKDApO1xuXG4gIGlvbi1pdGVtLWRpdmlkZXIge1xuXHRcdC0tYmFja2dyb3VuZDogdmFyKC0tcGFnZS1iYWNrZ3JvdW5kKTtcblx0XHQtLXBhZGRpbmctYm90dG9tOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDIpO1xuXHRcdC0tcGFkZGluZy10b3A6IGNhbGModmFyKC0tcGFnZS1tYXJnaW4pIC8gMik7XG5cdFx0LS1wYWRkaW5nLXN0YXJ0OiB2YXIoLS1wYWdlLW1hcmdpbik7XG5cdFx0LS1wYWRkaW5nLWVuZDogdmFyKC0tcGFnZS1tYXJnaW4pO1xuXG5cdFx0Ym9yZGVyOiBub25lO1xuXHR9XG5cbiAgLnVzZXItZGV0YWlscy13cmFwcGVyIHtcbiAgICAtLWlvbi1ncmlkLWNvbHVtbi1wYWRkaW5nOiAwcHg7XG5cbiAgICBwYWRkaW5nOiAwcHggdmFyKC0tcGFnZS1tYXJnaW4pIHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1wYWdlLWhpZ2hsaWdodGVkLWJhY2tncm91bmQpO1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cbiAgICAudXNlci1hdmF0YXIge1xuICAgICAgYm9yZGVyOiBzb2xpZCAzcHggdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbiAgICB9XG5cbiAgICAudXNlci1pbmZvLXdyYXBwZXIge1xuICAgICAgcGFkZGluZy1sZWZ0OiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDIpO1xuXG4gICAgICAudXNlci1uYW1lIHtcbiAgICAgICAgbWFyZ2luOiAwcHggMHB4IDVweDtcbiAgICAgIH1cblxuICAgICAgLnVzZXItaGFuZGxlIHtcbiAgICAgICAgbWFyZ2luOiAwcHg7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gLnVzZXItc3RhdHMtd3JhcHBlciB7XG4gICAgLy8gICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgLy8gICBwYWRkaW5nLXRvcDogY2FsYyh2YXIoLS1wYWdlLW1hcmdpbikgLyAyKTtcblxuICAgIC8vICAgLnVzZXItc3RhdC12YWx1ZSB7XG4gICAgLy8gICAgIG1hcmdpbi1yaWdodDogNXB4O1xuICAgIC8vICAgICBmb250LXdlaWdodDogNTAwO1xuICAgIC8vICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgLy8gICB9XG5cbiAgICAvLyAgIC51c2VyLXN0YXQtbmFtZSB7XG4gICAgLy8gICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAvLyAgIH1cbiAgICAvLyB9XG5cbiAgICAvLyAudXNlci1iaW8ge1xuICAgIC8vICAgbWFyZ2luOiB2YXIoLS1wYWdlLW1hcmdpbikgMHB4IDBweDtcbiAgICAvLyAgIGxpbmUtaGVpZ2h0OiAxLjI7XG4gICAgLy8gICBmb250LXNpemU6IDE0cHg7XG4gICAgLy8gfVxuICB9XG5cbiAgLnVzZXItcHJlZmVyZW5jZXMtd3JhcHBlciB7XG4gICAgLS1pb24tZ3JpZC1jb2x1bW4tcGFkZGluZzogMHB4O1xuXG4gICAgcGFkZGluZzogdmFyKC0tcGFnZS1tYXJnaW4pO1xuXG4gICAgLnByZWZlcmVuY2UtbmFtZSB7XG4gICAgICBtYXJnaW46IDBweCAwcHggNXB4O1xuICAgICAgZm9udC1zaXplOiAxNnB4O1xuICAgIH1cblxuICAgIC5wcmVmZXJlbmNlLXZhbHVlIHtcbiAgICAgIG1hcmdpbjogMHB4IDBweCBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDIpO1xuICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgbGluZS1oZWlnaHQ6IDEuNDtcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyay10aW50KTtcbiAgICB9XG5cblxuICB9XG5cbiAgLnJhZGlvLXRhZ3Mge1xuICAgIHBhZGRpbmc6IDBweCBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAtIHZhcigtLXBhZ2UtdGFncy1ndXR0ZXIpKTtcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1wYWdlLWJhY2tncm91bmQpO1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcblxuXHRcdEBpbmNsdWRlIHJhZGlvLXRhZygpO1xuXG4gICAgLy8gQWRkIGEgZGVlcGVyIHNlbGVjdG9yIHRvIG92ZXJyaWRlIGRlZmF1bHQgY29sb3JzXG4gICAgLnJhZGlvLXRhZyB7XG4gICAgICAtLXJhZGlvLXRhZy1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeSk7XG4gICAgICAtLXJhZGlvLXRhZy1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItbGlnaHRlc3QpO1xuICAgICAgLS1yYWRpby10YWctYWN0aXZlLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHRlc3QpO1xuICAgICAgLS1yYWRpby10YWctYWN0aXZlLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xuXG4gICAgICBwYWRkaW5nOiAwcHggdmFyKC0tcGFnZS10YWdzLWd1dHRlcik7XG4gICAgICBtYXJnaW46IHZhcigtLXBhZ2UtdGFncy1ndXR0ZXIpIDBweDtcbiAgICB9XG5cblx0fVxuXG4gIC5zdWJtaXQtYnRuLFxuICAudGlwLWxhYmVsIHtcbiAgICBtYXJnaW46IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgfVxuXG4gIC51c2VyLWJpbyB7XG4gICAgcGFkZGluZzogMHB4IHZhcigtLXBhZ2UtbWFyZ2luKSB2YXIoLS1wYWdlLW1hcmdpbik7XG4gICAgLy8gbWFyZ2luOiB2YXIoLS1wYWdlLW1hcmdpbikgMHB4IDBweDtcbiAgICBsaW5lLWhlaWdodDogMS4yO1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgfVxuXG4gIC51c2VyLXN0YXRzLXdyYXBwZXIge1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItdGVydGlhcnktdGludCk7XG4gICAgXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHBhZGRpbmctdG9wOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAvIDIpO1xuXG4gICAgLnVzZXItc3RhdC12YWx1ZSB7XG4gICAgICBtYXJnaW4tcmlnaHQ6IDVweDtcbiAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgfVxuXG4gICAgLnVzZXItc3RhdC1uYW1lIHtcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICAgIH1cbiAgfVxuXG5cbiAgLmFsZXJ0LXdyYXBwZXIge1xuICAgIGJhY2tncm91bmQ6ICNlNWU1ZTU7XG4gIH1cbiAgXG4gIC8qIFdvcmtzIC0gcGFzcyBcIm15LWN1c3RvbS1jbGFzc1wiIGluIGNzc0NsYXNzIHRvIGluY3JlYXNlIHNwZWNpZmljaXR5ICovXG4gIC5teS1jdXN0b20tY2xhc3MgLmFsZXJ0LXdyYXBwZXIge1xuICAgIGJhY2tncm91bmQ6ICNlNWU1ZTU7XG4gIH1cblxuICAuaW5wdXQtaXRlbSB7XG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1wYWdlLWJhY2tncm91bmQpO1xuICAgIC0tcGFkZGluZy1zdGFydDogdmFyKC0tcGFnZS1tYXJnaW4pO1xuICAgIC0tcGFkZGluZy1lbmQ6IHZhcigtLXBhZ2UtbWFyZ2luKTtcbiAgICAtLWlubmVyLXBhZGRpbmctZW5kOiAwcHg7XG5cbiAgfVxufVxuXG46aG9zdC1jb250ZXh0KC5pb3MpIHtcbiAgLnJhZGlvLXRhZ3MsXG4gIC5jaGVja2JveC10YWdzIHtcbiAgICBtYXJnaW4tYm90dG9tOiBjYWxjKHZhcigtLXBhZ2UtbWFyZ2luKSAqIDIpO1xuICB9XG59XG4iLCJAbWl4aW4gcmFkaW8tdGFnKCkge1xuICAvLyBEZWZhdWx0IHZhbHVlc1xuICAtLXJhZGlvLXRhZy1jb2xvcjogIzAwMDtcbiAgLS1yYWRpby10YWctYmFja2dyb3VuZDogI0ZGRjtcbiAgLS1yYWRpby10YWctYWN0aXZlLWNvbG9yOiAjRkZGO1xuICAtLXJhZGlvLXRhZy1hY3RpdmUtYmFja2dyb3VuZDogIzAwMDtcblxuXHQucmFkaW8tdGFnIHtcbiAgICAvLyBSZXNldCB2YWx1ZXMgZnJvbSBJb25pYyAoaW9uLWl0ZW0pIHN0eWxlc1xuICAgIC0tcGFkZGluZy1zdGFydDogMHB4O1xuICAgIC0taW5uZXItcGFkZGluZy1lbmQ6IDhweDtcblx0XHQtLWlubmVyLXBhZGRpbmctc3RhcnQ6IDhweDtcbiAgICAtLW1pbi1oZWlnaHQ6IDE4cHg7XG5cblx0XHQtLWJvcmRlci1yYWRpdXM6IDhweDtcbiAgICAtLWJvcmRlci13aWR0aDogMXB4O1xuXHRcdC0tYm9yZGVyLXN0eWxlOiBzb2xpZDtcblx0XHQtLWJvcmRlci1jb2xvcjogdmFyKC0tcmFkaW8tdGFnLWNvbG9yKTtcblx0XHQtLWlvbi1pdGVtLWJhY2tncm91bmQ6IHZhcigtLXJhZGlvLXRhZy1iYWNrZ3JvdW5kKTtcblx0XHQtLWlvbi1pdGVtLWNvbG9yOiB2YXIoLS1yYWRpby10YWctY29sb3IpO1xuXG4gICAgZmxleDogMTtcblxuXHRcdCYuaXRlbS1yYWRpby1jaGVja2VkIHtcbiAgICAgIC0taW9uLWl0ZW0tYmFja2dyb3VuZDogdmFyKC0tcmFkaW8tdGFnLWFjdGl2ZS1iYWNrZ3JvdW5kKTtcbiAgICAgIC0taW9uLWl0ZW0tY29sb3I6IHZhcigtLXJhZGlvLXRhZy1hY3RpdmUtY29sb3IpO1xuXHRcdH1cblxuICAgICYuaXRlbS1pbnRlcmFjdGl2ZS1kaXNhYmxlZCB7XG4gICAgICBvcGFjaXR5OiAwLjU7XG5cbiAgICAgIC50YWctbGFiZWwge1xuICAgICAgICAvLyBPdmVycmlkZSBJb25pYyBkZWZhdWx0IHN0eWxlXG4gICAgICAgIG9wYWNpdHk6IDE7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLnRhZy1sYWJlbCB7XG5cdFx0XHRtYXJnaW46IDVweDtcbiAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICBsZXR0ZXItc3BhY2luZzogMC4ycHg7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG5cdFx0fVxuXG5cdFx0aW9uLXJhZGlvIHtcblx0XHRcdG1hcmdpbjogMHB4O1xuXHRcdFx0Ly8gVG8gaGlkZSB0aGUgLnJhZGlvLWljb25cblx0XHRcdHdpZHRoOiAwcHg7XG5cdFx0XHQtLWJvcmRlci13aWR0aDogMHB4O1xuXHRcdFx0aGVpZ2h0OiAwcHg7XG5cdFx0XHQvLyBXZSBjYW50IHNldCB3aWR0aCBhbmQgaGVpZ2h0IGZvciAucmFkaW8taWNvbiAucmFkaW8taW5uZXIsIHNvIGxldHMgaGlkZSBpdCBjaGFuZ2luZyBpdHMgY29sb3Jcblx0XHRcdC0tY29sb3ItY2hlY2tlZDogdHJhbnNwYXJlbnQ7XG5cdFx0fVxuXHR9XG59XG4iXX0= */");

/***/ }),

/***/ "BqFa":
/*!***********************************************!*\
  !*** ./src/app/pages/docking/docking.page.ts ***!
  \***********************************************/
/*! exports provided: DockingPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DockingPage", function() { return DockingPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_docking_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./docking.page.html */ "tNvJ");
/* harmony import */ var _styles_docking_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/docking.page.scss */ "2lTV");
/* harmony import */ var _styles_docking_shell_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./styles/docking.shell.scss */ "1jC2");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var ngx_clipboard__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-clipboard */ "Dvla");
/* harmony import */ var _deal_deal_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../deal/deal.service */ "3cZy");









let DockingPage = class DockingPage {
    constructor(route, router, dealService, alertController, _clipboardService) {
        this.router = router;
        this.dealService = dealService;
        this.alertController = alertController;
        this._clipboardService = _clipboardService;
        this.referralId = route.snapshot.params['referralId'];
        this.userRole = localStorage.getItem('userRole');
        this.dealService.getReferrals(this.referralId).subscribe(data => {
            var _a, _b;
            if (data.data != null) {
                this.currentReferral = data.data;
                this.dockingName = (_a = this.currentReferral) === null || _a === void 0 ? void 0 : _a.dockingName;
                this.dockingPhone = (_b = this.currentReferral) === null || _b === void 0 ? void 0 : _b.dockingPhone;
            }
        });
    }
    ngOnInit() {
    }
    presentAlertConfirm() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: '录入成功',
                message: '您添加跟办信息录入成功！',
                backdropDismiss: false,
                buttons: [
                    {
                        text: '关闭页面',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: () => {
                            // console.log('Confirm Cancel: blah');
                            WeixinJSBridge.call('closeWindow');
                        }
                    }, {
                        text: '返回首页',
                        handler: () => {
                            // console.log('Confirm Okay');
                            this.router.navigate(['/app/referrals']);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    onSubmit() {
        //
        if (this.referralId == null)
            return;
        if (this.userRole !== 'access')
            return;
        this.dealService.updateReferralsDock(this.referralId, this.dockingName, this.dockingPhone).subscribe(res => {
            this.presentAlertConfirm();
        });
    }
    nameChange(ev) {
        this.dockingName = ev.detail.value;
    }
    phoneChange(ev) {
        this.dockingPhone = ev.detail.value;
    }
    //   【项目名称】世纪城
    // 【客户】胡女士
    // 【电话 】186 xxx9711
    // 【报备人】  刘小姐
    // 【电话】17707283180
    // 【公司】0728房网
    // 【客户情况】贷款
    // 【报备时间】2021.7.20
    // 【到访时间 】 今天
    copy() {
        var _a, _b, _c, _d, _e, _f;
        this._clipboardService.copy("【项目名称】" + ((_b = (_a = this.currentReferral) === null || _a === void 0 ? void 0 : _a.basicInfo) === null || _b === void 0 ? void 0 : _b.projectName) + "\n" +
            "【客户】" + ((_c = this.currentReferral) === null || _c === void 0 ? void 0 : _c.customerName) + "\n" +
            "【电话 】" + ((_d = this.currentReferral) === null || _d === void 0 ? void 0 : _d.phone) + "\n" +
            "【公司】" + "湖北昭鸿地产" + "\n" +
            "【客户情况】" + ((_e = this.currentReferral) === null || _e === void 0 ? void 0 : _e.description) + "\n" +
            "【报备时间】" + ((_f = this.currentReferral) === null || _f === void 0 ? void 0 : _f.createTime));
    }
};
DockingPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _deal_deal_service__WEBPACK_IMPORTED_MODULE_8__["DealService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] },
    { type: ngx_clipboard__WEBPACK_IMPORTED_MODULE_7__["ClipboardService"] }
];
DockingPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-docking',
        template: _raw_loader_docking_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_styles_docking_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"], _styles_docking_shell_scss__WEBPACK_IMPORTED_MODULE_3__["default"]]
    })
], DockingPage);



/***/ }),

/***/ "RO7i":
/*!*************************************************!*\
  !*** ./src/app/pages/docking/docking.module.ts ***!
  \*************************************************/
/*! exports provided: DockingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DockingModule", function() { return DockingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _app_components_components_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @app/components/components.module */ "j1ZV");
/* harmony import */ var _docking_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./docking.page */ "BqFa");








let DockingModule = class DockingModule {
};
DockingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
            _app_components_components_module__WEBPACK_IMPORTED_MODULE_6__["ComponentsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ReactiveFormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{ path: '', component: _docking_page__WEBPACK_IMPORTED_MODULE_7__["DockingPage"] }])
        ],
        declarations: [_docking_page__WEBPACK_IMPORTED_MODULE_7__["DockingPage"]]
    })
], DockingModule);



/***/ }),

/***/ "tNvJ":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/docking/docking.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- <ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header> -->\n\n<ion-content class=\"transact-details-content\">\n  \n  \n  <ion-row class=\"user-preferences-wrapper\">\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">客户：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.customerName}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">电话：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.phone}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">咨询楼盘：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.basicInfo?.projectName}}\n      </p>\n    </ion-col>\n    <ion-col size=\"12\">\n      <h4 class=\"preference-name\">客户意向：</h4>\n      <p class=\"preference-value\">\n        {{currentReferral?.description}}\n      </p>\n    </ion-col>\n    <ion-button color=\"primary\" size=\"small\" (click)=\"copy()\">复制报备信息</ion-button>\n\n  </ion-row>\n\n  <ion-item-divider>\n    <ion-label>录入跟办人员</ion-label>\n  </ion-item-divider>\n\n  <ion-item class=\"input-item\">\n    <ion-label position=\"floating\">跟办置业顾问</ion-label>\n    <ion-input type=\"text\" [value]=\"dockingName\" clearInput (ionChange)=\"nameChange($event)\"></ion-input>\n  </ion-item>\n\n  <ion-item class=\"input-item\">\n    <ion-label position=\"floating\">联系电话</ion-label>\n    <ion-input type=\"number\" [value]=\"dockingPhone\" clearInput (ionChange)=\"phoneChange($event)\"></ion-input>\n  </ion-item>\n  \n  <ion-button class=\"submit-btn\" type=\"submit\" expand=\"block\" fill=\"outline\"  [disabled]=\"userRole !== 'access'\" (click)=\"onSubmit()\">提交</ion-button>\n    \n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=pages-docking-docking-module.js.map